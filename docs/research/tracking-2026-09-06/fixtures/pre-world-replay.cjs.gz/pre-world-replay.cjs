"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/lib/physics/evaluator.ts
function prepareHermiteTrack(track, velocities) {
  const n = track.length >> 1;
  const out = track;
  delete out.hermite;
  if (n < 2 || velocities.length !== n) return track;
  const coefficients = new Float64Array((n - 1) * 3);
  coefficients.fill(Number.NaN);
  let eligible = false;
  for (let i = 0; i < n - 1; i++) {
    const dt = (track[(i + 1) * 2] - track[i * 2]) / 1e3;
    const ds = track[(i + 1) * 2 + 1] - track[i * 2 + 1];
    const v0 = velocities[i], v1 = velocities[i + 1];
    if (!Number.isFinite(dt) || dt <= 0 || !Number.isFinite(ds) || ds < 0 || !Number.isFinite(v0) || !Number.isFinite(v1) || v0 < 0 || v1 < 0 || v0 > TRACK_MAX_SPEED_MS || v1 > TRACK_MAX_SPEED_MS)
      continue;
    if (ds === 0 && (v0 !== 0 || v1 !== 0)) continue;
    const a = dt * v0;
    const b = 3 * ds - dt * (2 * v0 + v1);
    const c = -2 * ds + dt * (v0 + v1);
    const accel0 = 2 * b / (dt * dt), accel1 = (2 * b + 6 * c) / (dt * dt);
    if (accel0 < -TRACK_MAX_BRAKE_MS2 - 1e-8 || accel0 > TRACK_MAX_ACCEL_MS2 + 1e-8 || accel1 < -TRACK_MAX_BRAKE_MS2 - 1e-8 || accel1 > TRACK_MAX_ACCEL_MS2 + 1e-8)
      continue;
    const vertex = c !== 0 ? -b / (3 * c) : -1;
    if (vertex > 0 && vertex < 1) {
      const v2 = (a + vertex * (2 * b + 3 * c * vertex)) / dt;
      if (v2 < -1e-8 || v2 > TRACK_MAX_SPEED_MS + 1e-8) continue;
    }
    const j = i * 3;
    coefficients[j] = a;
    coefficients[j + 1] = b;
    coefficients[j + 2] = c;
    eligible = true;
  }
  if (eligible) out.hermite = coefficients;
  return track;
}
function trackStartMs(track) {
  return track.length >= 2 ? track[0] : Number.NaN;
}
function trackEndMs(track) {
  const n = track.length >> 1;
  return n > 0 ? track[n - 1 << 1] : Number.NaN;
}
function evalTrajectory(track, tMs) {
  const n = track.length >> 1;
  if (n === 0) return Number.NaN;
  if (tMs <= track[0]) return track[1];
  const lastBase = n - 1 << 1;
  if (tMs >= track[lastBase]) return track[lastBase + 1];
  let lo = 0;
  let hi = n - 2;
  while (lo < hi) {
    const mid = lo + hi + 1 >> 1;
    if (track[mid << 1] <= tMs) lo = mid;
    else hi = mid - 1;
  }
  const a = lo << 1;
  const b = a + 2;
  const t0 = track[a];
  const span = track[b] - t0;
  if (span <= 0) return track[b + 1];
  const s0 = track[a + 1];
  const u = (tMs - t0) / span;
  const h = track.hermite;
  const j = lo * 3;
  return h && Number.isFinite(h[j]) ? s0 + u * (h[j] + u * (h[j + 1] + u * h[j + 2])) : s0 + (track[b + 1] - s0) * u;
}
function crossingTimeMs(track, sTarget) {
  const n = track.length >> 1;
  if (n === 0) return Number.NaN;
  if (sTarget <= track[1]) return track[0];
  const lastBase = n - 1 << 1;
  if (sTarget > track[lastBase + 1]) return Number.NaN;
  let lo = 1;
  let hi = n - 1;
  while (lo < hi) {
    const mid = lo + hi >> 1;
    if (track[(mid << 1) + 1] >= sTarget) hi = mid;
    else lo = mid + 1;
  }
  const b = hi << 1;
  const a = b - 2;
  const s0 = track[a + 1];
  const ds = track[b + 1] - s0;
  const t0 = track[a];
  if (ds <= 0) return track[b];
  const h = track.hermite;
  const j = (hi - 1) * 3;
  if (h && Number.isFinite(h[j])) {
    let left = 0, right = 1;
    const target = sTarget - s0;
    for (let iteration = 0; iteration < 24; iteration++) {
      const mid = (left + right) / 2;
      const value = mid * (h[j] + mid * (h[j + 1] + mid * h[j + 2]));
      if (value < target) left = mid;
      else right = mid;
    }
    return t0 + (track[b] - t0) * (left + right) / 2;
  }
  return t0 + (track[b] - t0) * (sTarget - s0) / ds;
}
function evalSpeedMs(track, tMs, halfWindowMs = SPEED_HALF_WINDOW_MS) {
  const n = track.length >> 1;
  if (n === 0) return 0;
  const before = evalTrajectory(track, tMs - halfWindowMs);
  const after = evalTrajectory(track, tMs + halfWindowMs);
  const v2 = (after - before) * 500 / halfWindowMs;
  return v2 > 0 ? v2 : 0;
}
var TRACK_MAX_SPEED_MS, TRACK_MAX_ACCEL_MS2, TRACK_MAX_BRAKE_MS2, SPEED_HALF_WINDOW_MS;
var init_evaluator = __esm({
  "src/lib/physics/evaluator.ts"() {
    "use strict";
    TRACK_MAX_SPEED_MS = 16.7;
    TRACK_MAX_ACCEL_MS2 = 1.3;
    TRACK_MAX_BRAKE_MS2 = 1.4;
    SPEED_HALF_WINDOW_MS = 500;
  }
});

// src/lib/physics/bundle.ts
function num(v2) {
  return typeof v2 === "number" && Number.isFinite(v2) ? v2 : Number.NaN;
}
function packTrack(points) {
  if (!Array.isArray(points) || points.length === 0) return EMPTY_TRACK;
  const limit = Math.min(points.length, MAX_KNOTS);
  const buf = new Float64Array(limit * 2);
  const velocities = new Float64Array(limit);
  velocities.fill(Number.NaN);
  let hasVelocity = false;
  let n = 0;
  let lastT = Number.NEGATIVE_INFINITY;
  for (let i = 0; i < limit; i++) {
    const p = points[i];
    if (p == null) continue;
    const t = num(p.t);
    const s = num(p.s);
    if (Number.isNaN(t) || Number.isNaN(s) || t <= lastT) continue;
    buf[n << 1] = t;
    buf[(n << 1) + 1] = s;
    const velocity = num(p.v);
    velocities[n] = velocity;
    if (Number.isFinite(velocity)) hasVelocity = true;
    lastT = t;
    n += 1;
  }
  if (n === 0) return EMPTY_TRACK;
  const packed = n * 2 === buf.length ? buf : buf.subarray(0, n * 2);
  return hasVelocity ? prepareHermiteTrack(packed, velocities.subarray(0, n)) : packed;
}
function parseVehicle(raw) {
  const v2 = raw;
  if (v2 == null || typeof v2.key !== "string" || v2.key.length === 0) return null;
  if (typeof v2.tripId !== "string") return null;
  const opinion = packTrack(v2.opinion);
  const smooth = packTrack(v2.smooth);
  if (opinion.length === 0 && smooth.length === 0) return null;
  return {
    key: v2.key,
    tripId: v2.tripId,
    line: typeof v2.line === "string" ? v2.line : "",
    anchorMs: num(v2.anchorMs),
    emittedAtMs: num(v2.emittedAtMs),
    discontinuity: v2.discontinuity === true,
    motionPolicy: v2.motionPolicy === "continuous-v1" ? "continuous-v1" : void 0,
    opinion,
    smooth,
    source: v2.source === "ml" || v2.source === "naive" ? v2.source : null,
    anchorS: num(v2.anchorS)
  };
}
function parseBundle(payload, receivedAtMs) {
  const body = payload;
  if (body == null || typeof body !== "object") return null;
  const serverNowMs = num(body.serverNowMs);
  if (Number.isNaN(serverNowMs)) return null;
  if (!Array.isArray(body.vehicles)) return null;
  const atMsRaw = num(body.atMs);
  const vehicles = /* @__PURE__ */ new Map();
  for (const raw of body.vehicles) {
    const parsed = parseVehicle(raw);
    if (parsed) vehicles.set(parsed.key, parsed);
  }
  return {
    protocolVersion: Number.isNaN(num(body.protocolVersion)) ? PROTOCOL_VERSION : body.protocolVersion,
    serverNowMs,
    atMs: Number.isNaN(atMsRaw) ? serverNowMs : atMsRaw,
    horizonS: Number.isNaN(num(body.horizonS)) ? 0 : body.horizonS,
    vehicles,
    generator: typeof body.generator === "string" && body.generator.length > 0 ? body.generator : null,
    receivedAtMs
  };
}
var PROTOCOL_VERSION, MAX_KNOTS, EMPTY_TRACK;
var init_bundle = __esm({
  "src/lib/physics/bundle.ts"() {
    "use strict";
    init_evaluator();
    PROTOCOL_VERSION = 2;
    MAX_KNOTS = 24;
    EMPTY_TRACK = new Float64Array(0);
  }
});

// node_modules/convex/dist/esm/index.js
var version;
var init_esm = __esm({
  "node_modules/convex/dist/esm/index.js"() {
    "use strict";
    version = "1.43.0";
  }
});

// node_modules/convex/dist/esm/values/base64.js
var base64_exports = {};
__export(base64_exports, {
  byteLength: () => byteLength,
  fromByteArray: () => fromByteArray,
  fromByteArrayUrlSafeNoPadding: () => fromByteArrayUrlSafeNoPadding,
  toByteArray: () => toByteArray
});
function getLens(b64) {
  var len = b64.length;
  if (len % 4 > 0) {
    throw new Error("Invalid string. Length must be a multiple of 4");
  }
  var validLen = b64.indexOf("=");
  if (validLen === -1) validLen = len;
  var placeHoldersLen = validLen === len ? 0 : 4 - validLen % 4;
  return [validLen, placeHoldersLen];
}
function byteLength(b64) {
  var lens = getLens(b64);
  var validLen = lens[0];
  var placeHoldersLen = lens[1];
  return (validLen + placeHoldersLen) * 3 / 4 - placeHoldersLen;
}
function _byteLength(_b64, validLen, placeHoldersLen) {
  return (validLen + placeHoldersLen) * 3 / 4 - placeHoldersLen;
}
function toByteArray(b64) {
  var tmp;
  var lens = getLens(b64);
  var validLen = lens[0];
  var placeHoldersLen = lens[1];
  var arr2 = new Arr(_byteLength(b64, validLen, placeHoldersLen));
  var curByte = 0;
  var len = placeHoldersLen > 0 ? validLen - 4 : validLen;
  var i;
  for (i = 0; i < len; i += 4) {
    tmp = revLookup[b64.charCodeAt(i)] << 18 | revLookup[b64.charCodeAt(i + 1)] << 12 | revLookup[b64.charCodeAt(i + 2)] << 6 | revLookup[b64.charCodeAt(i + 3)];
    arr2[curByte++] = tmp >> 16 & 255;
    arr2[curByte++] = tmp >> 8 & 255;
    arr2[curByte++] = tmp & 255;
  }
  if (placeHoldersLen === 2) {
    tmp = revLookup[b64.charCodeAt(i)] << 2 | revLookup[b64.charCodeAt(i + 1)] >> 4;
    arr2[curByte++] = tmp & 255;
  }
  if (placeHoldersLen === 1) {
    tmp = revLookup[b64.charCodeAt(i)] << 10 | revLookup[b64.charCodeAt(i + 1)] << 4 | revLookup[b64.charCodeAt(i + 2)] >> 2;
    arr2[curByte++] = tmp >> 8 & 255;
    arr2[curByte++] = tmp & 255;
  }
  return arr2;
}
function tripletToBase64(num2) {
  return lookup[num2 >> 18 & 63] + lookup[num2 >> 12 & 63] + lookup[num2 >> 6 & 63] + lookup[num2 & 63];
}
function encodeChunk(uint8, start, end) {
  var tmp;
  var output = [];
  for (var i = start; i < end; i += 3) {
    tmp = (uint8[i] << 16 & 16711680) + (uint8[i + 1] << 8 & 65280) + (uint8[i + 2] & 255);
    output.push(tripletToBase64(tmp));
  }
  return output.join("");
}
function fromByteArray(uint8) {
  var tmp;
  var len = uint8.length;
  var extraBytes = len % 3;
  var parts = [];
  var maxChunkLength = 16383;
  for (var i = 0, len2 = len - extraBytes; i < len2; i += maxChunkLength) {
    parts.push(
      encodeChunk(
        uint8,
        i,
        i + maxChunkLength > len2 ? len2 : i + maxChunkLength
      )
    );
  }
  if (extraBytes === 1) {
    tmp = uint8[len - 1];
    parts.push(lookup[tmp >> 2] + lookup[tmp << 4 & 63] + "==");
  } else if (extraBytes === 2) {
    tmp = (uint8[len - 2] << 8) + uint8[len - 1];
    parts.push(
      lookup[tmp >> 10] + lookup[tmp >> 4 & 63] + lookup[tmp << 2 & 63] + "="
    );
  }
  return parts.join("");
}
function fromByteArrayUrlSafeNoPadding(uint8) {
  return fromByteArray(uint8).replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "");
}
var lookup, revLookup, Arr, code, i, len;
var init_base64 = __esm({
  "node_modules/convex/dist/esm/values/base64.js"() {
    "use strict";
    lookup = [];
    revLookup = [];
    Arr = Uint8Array;
    code = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    for (i = 0, len = code.length; i < len; ++i) {
      lookup[i] = code[i];
      revLookup[code.charCodeAt(i)] = i;
    }
    revLookup["-".charCodeAt(0)] = 62;
    revLookup["_".charCodeAt(0)] = 63;
  }
});

// node_modules/convex/dist/esm/common/index.js
function parseArgs(args) {
  if (args === void 0) {
    return {};
  }
  if (!isSimpleObject(args)) {
    throw new Error(
      `The arguments to a Convex function must be an object. Received: ${args}`
    );
  }
  return args;
}
function validateDeploymentUrl(deploymentUrl) {
  if (typeof deploymentUrl === "undefined") {
    throw new Error(
      `Client created with undefined deployment address. If you used an environment variable, check that it's set.`
    );
  }
  if (typeof deploymentUrl !== "string") {
    throw new Error(
      `Invalid deployment address: found ${deploymentUrl}".`
    );
  }
  if (!(deploymentUrl.startsWith("http:") || deploymentUrl.startsWith("https:"))) {
    throw new Error(
      `Invalid deployment address: Must start with "https://" or "http://". Found "${deploymentUrl}".`
    );
  }
  try {
    new URL(deploymentUrl);
  } catch {
    throw new Error(
      `Invalid deployment address: "${deploymentUrl}" is not a valid URL. If you believe this URL is correct, use the \`skipConvexDeploymentUrlCheck\` option to bypass this.`
    );
  }
  if (deploymentUrl.endsWith(".convex.site")) {
    throw new Error(
      `Invalid deployment address: "${deploymentUrl}" ends with .convex.site, which is used for HTTP Actions. Convex deployment URLs typically end with .convex.cloud? If you believe this URL is correct, use the \`skipConvexDeploymentUrlCheck\` option to bypass this.`
    );
  }
}
function isSimpleObject(value) {
  const isObject = typeof value === "object";
  const prototype2 = Object.getPrototypeOf(value);
  const isSimple = prototype2 === null || prototype2 === Object.prototype || // Objects generated from other contexts (e.g. across Node.js `vm` modules) will not satisfy the previous
  // conditions but are still simple objects.
  prototype2?.constructor?.name === "Object";
  return isObject && isSimple;
}
var init_common = __esm({
  "node_modules/convex/dist/esm/common/index.js"() {
    "use strict";
  }
});

// node_modules/convex/dist/esm/values/value.js
function isSpecial(n) {
  return Number.isNaN(n) || !Number.isFinite(n) || Object.is(n, -0);
}
function slowBigIntToBase64(value) {
  if (value < ZERO) {
    value -= MIN_INT64 + MIN_INT64;
  }
  let hex = value.toString(16);
  if (hex.length % 2 === 1) hex = "0" + hex;
  const bytes = new Uint8Array(new ArrayBuffer(8));
  let i = 0;
  for (const hexByte of hex.match(/.{2}/g).reverse()) {
    bytes.set([parseInt(hexByte, 16)], i++);
    value >>= EIGHT;
  }
  return fromByteArray(bytes);
}
function slowBase64ToBigInt(encoded) {
  const integerBytes = toByteArray(encoded);
  if (integerBytes.byteLength !== 8) {
    throw new Error(
      `Received ${integerBytes.byteLength} bytes, expected 8 for $integer`
    );
  }
  let value = ZERO;
  let power = ZERO;
  for (const byte of integerBytes) {
    value += BigInt(byte) * TWOFIFTYSIX ** power;
    power++;
  }
  if (value > MAX_INT64) {
    value += MIN_INT64 + MIN_INT64;
  }
  return value;
}
function modernBigIntToBase64(value) {
  if (value < MIN_INT64 || MAX_INT64 < value) {
    throw new Error(
      `BigInt ${value} does not fit into a 64-bit signed integer.`
    );
  }
  const buffer = new ArrayBuffer(8);
  new DataView(buffer).setBigInt64(0, value, true);
  return fromByteArray(new Uint8Array(buffer));
}
function modernBase64ToBigInt(encoded) {
  const integerBytes = toByteArray(encoded);
  if (integerBytes.byteLength !== 8) {
    throw new Error(
      `Received ${integerBytes.byteLength} bytes, expected 8 for $integer`
    );
  }
  const intBytesView = new DataView(integerBytes.buffer);
  return intBytesView.getBigInt64(0, true);
}
function validateObjectField(k) {
  if (k.length > MAX_IDENTIFIER_LEN) {
    throw new Error(
      `Field name ${k} exceeds maximum field name length ${MAX_IDENTIFIER_LEN}.`
    );
  }
  if (k.startsWith("$")) {
    throw new Error(`Field name ${k} starts with a '$', which is reserved.`);
  }
  for (let i = 0; i < k.length; i += 1) {
    const charCode = k.charCodeAt(i);
    if (charCode < 32 || charCode >= 127) {
      throw new Error(
        `Field name ${k} has invalid character '${k[i]}': Field names can only contain non-control ASCII characters`
      );
    }
  }
}
function jsonToConvex(value) {
  if (value === null) {
    return value;
  }
  if (typeof value === "boolean") {
    return value;
  }
  if (typeof value === "number") {
    return value;
  }
  if (typeof value === "string") {
    return value;
  }
  if (Array.isArray(value)) {
    return value.map((value2) => jsonToConvex(value2));
  }
  if (typeof value !== "object") {
    throw new Error(`Unexpected type of ${value}`);
  }
  const entries = Object.entries(value);
  if (entries.length === 1) {
    const key = entries[0][0];
    if (key === "$bytes") {
      if (typeof value.$bytes !== "string") {
        throw new Error(`Malformed $bytes field on ${value}`);
      }
      return toByteArray(value.$bytes).buffer;
    }
    if (key === "$integer") {
      if (typeof value.$integer !== "string") {
        throw new Error(`Malformed $integer field on ${value}`);
      }
      return base64ToBigInt(value.$integer);
    }
    if (key === "$float") {
      if (typeof value.$float !== "string") {
        throw new Error(`Malformed $float field on ${value}`);
      }
      const floatBytes = toByteArray(value.$float);
      if (floatBytes.byteLength !== 8) {
        throw new Error(
          `Received ${floatBytes.byteLength} bytes, expected 8 for $float`
        );
      }
      const floatBytesView = new DataView(floatBytes.buffer);
      const float = floatBytesView.getFloat64(0, LITTLE_ENDIAN);
      if (!isSpecial(float)) {
        throw new Error(`Float ${float} should be encoded as a number`);
      }
      return float;
    }
    if (key === "$commitTs") {
      if (value.$commitTs !== null) {
        throw new Error(`Malformed $commitTs field on ${value}`);
      }
      return commitTsPlaceholder;
    }
    if (key === "$set") {
      throw new Error(
        `Received a Set which is no longer supported as a Convex type.`
      );
    }
    if (key === "$map") {
      throw new Error(
        `Received a Map which is no longer supported as a Convex type.`
      );
    }
  }
  const out = {};
  for (const [k, v2] of Object.entries(value)) {
    validateObjectField(k);
    out[k] = jsonToConvex(v2);
  }
  return out;
}
function stringifyValueForError(value) {
  const str = JSON.stringify(value, (_key, value2) => {
    if (value2 === void 0) {
      return "undefined";
    }
    if (typeof value2 === "bigint") {
      return `${value2.toString()}n`;
    }
    return value2;
  });
  if (str.length > MAX_VALUE_FOR_ERROR_LEN) {
    const rest = "[...truncated]";
    let truncateAt = MAX_VALUE_FOR_ERROR_LEN - rest.length;
    const codePoint = str.codePointAt(truncateAt - 1);
    if (codePoint !== void 0 && codePoint > 65535) {
      truncateAt -= 1;
    }
    return str.substring(0, truncateAt) + rest;
  }
  return str;
}
function convexToJsonInternal(value, originalValue, context, includeTopLevelUndefined) {
  if (value === void 0) {
    const contextText = context && ` (present at path ${context} in original object ${stringifyValueForError(
      originalValue
    )})`;
    throw new Error(
      `undefined is not a valid Convex value${contextText}. To learn about Convex's supported types, see https://docs.convex.dev/using/types.`
    );
  }
  if (value === null) {
    return value;
  }
  if (typeof value === "bigint") {
    if (value < MIN_INT64 || MAX_INT64 < value) {
      throw new Error(
        `BigInt ${value} does not fit into a 64-bit signed integer.`
      );
    }
    return { $integer: bigIntToBase64(value) };
  }
  if (typeof value === "number") {
    if (isSpecial(value)) {
      const buffer = new ArrayBuffer(8);
      new DataView(buffer).setFloat64(0, value, LITTLE_ENDIAN);
      return { $float: fromByteArray(new Uint8Array(buffer)) };
    } else {
      return value;
    }
  }
  if (typeof value === "boolean") {
    return value;
  }
  if (typeof value === "string") {
    return value;
  }
  if (value instanceof ArrayBuffer) {
    return { $bytes: fromByteArray(new Uint8Array(value)) };
  }
  if (value instanceof CommitTsPlaceholder) {
    return { $commitTs: null };
  }
  if (Array.isArray(value)) {
    return value.map(
      (value2, i) => convexToJsonInternal(value2, originalValue, context + `[${i}]`, false)
    );
  }
  if (value instanceof Set) {
    throw new Error(
      errorMessageForUnsupportedType(context, "Set", [...value], originalValue)
    );
  }
  if (value instanceof Map) {
    throw new Error(
      errorMessageForUnsupportedType(context, "Map", [...value], originalValue)
    );
  }
  if (!isSimpleObject(value)) {
    const theType = value?.constructor?.name;
    const typeName = theType ? `${theType} ` : "";
    throw new Error(
      errorMessageForUnsupportedType(context, typeName, value, originalValue)
    );
  }
  const out = {};
  const entries = Object.entries(value);
  entries.sort(([k1, _v1], [k2, _v2]) => k1 === k2 ? 0 : k1 < k2 ? -1 : 1);
  for (const [k, v2] of entries) {
    if (v2 !== void 0) {
      validateObjectField(k);
      out[k] = convexToJsonInternal(v2, originalValue, context + `.${k}`, false);
    } else if (includeTopLevelUndefined) {
      validateObjectField(k);
      out[k] = convexOrUndefinedToJsonInternal(
        v2,
        originalValue,
        context + `.${k}`
      );
    }
  }
  return out;
}
function errorMessageForUnsupportedType(context, typeName, value, originalValue) {
  if (context) {
    return `${typeName}${stringifyValueForError(
      value
    )} is not a supported Convex type (present at path ${context} in original object ${stringifyValueForError(
      originalValue
    )}). To learn about Convex's supported types, see https://docs.convex.dev/using/types.`;
  } else {
    return `${typeName}${stringifyValueForError(
      value
    )} is not a supported Convex type.`;
  }
}
function convexOrUndefinedToJsonInternal(value, originalValue, context) {
  if (value === void 0) {
    return { $undefined: null };
  } else {
    if (originalValue === void 0) {
      throw new Error(
        `Programming error. Current value is ${stringifyValueForError(
          value
        )} but original value is undefined`
      );
    }
    return convexToJsonInternal(value, originalValue, context, false);
  }
}
function convexToJson(value) {
  return convexToJsonInternal(value, value, "", false);
}
var LITTLE_ENDIAN, MIN_INT64, MAX_INT64, ZERO, EIGHT, TWOFIFTYSIX, COMMIT_TS_UNRESOLVED, CommitTsPlaceholder, commitTsPlaceholder, bigIntToBase64, base64ToBigInt, MAX_IDENTIFIER_LEN, MAX_VALUE_FOR_ERROR_LEN;
var init_value = __esm({
  "node_modules/convex/dist/esm/values/value.js"() {
    "use strict";
    init_base64();
    init_common();
    LITTLE_ENDIAN = true;
    MIN_INT64 = BigInt("-9223372036854775808");
    MAX_INT64 = BigInt("9223372036854775807");
    ZERO = BigInt("0");
    EIGHT = BigInt("8");
    TWOFIFTYSIX = BigInt("256");
    COMMIT_TS_UNRESOLVED = "This commit timestamp is unresolved: its value is assigned when the mutation commits. Read the document after the mutation completes to get its value.";
    CommitTsPlaceholder = class {
      [Symbol.toPrimitive](hint) {
        if (hint === "string") {
          return this.toString();
        }
        throw new Error(COMMIT_TS_UNRESOLVED);
      }
      valueOf() {
        throw new Error(COMMIT_TS_UNRESOLVED);
      }
      toJSON() {
        throw new Error(COMMIT_TS_UNRESOLVED);
      }
      toString() {
        return "[unresolved commit timestamp]";
      }
    };
    commitTsPlaceholder = new CommitTsPlaceholder();
    bigIntToBase64 = DataView.prototype.setBigInt64 ? modernBigIntToBase64 : slowBigIntToBase64;
    base64ToBigInt = DataView.prototype.getBigInt64 ? modernBase64ToBigInt : slowBase64ToBigInt;
    MAX_IDENTIFIER_LEN = 1024;
    MAX_VALUE_FOR_ERROR_LEN = 16384;
  }
});

// node_modules/convex/dist/esm/values/validators.js
function throwUndefinedValidatorError(context, fieldName) {
  const fieldInfo = fieldName !== void 0 ? ` for field "${fieldName}"` : "";
  throw new Error(
    `A validator is undefined${fieldInfo} in ${context}. This is often caused by circular imports. See ${UNDEFINED_VALIDATOR_ERROR_URL} for details.`
  );
}
var __defProp2, __defNormalProp, __publicField, UNDEFINED_VALIDATOR_ERROR_URL, BaseValidator, VId, VFloat64, VInt64, VCommitTs, VBoolean, VBytes, VString, VNull, VAny, VObject, VLiteral, VArray, VRecord, VUnion;
var init_validators = __esm({
  "node_modules/convex/dist/esm/values/validators.js"() {
    "use strict";
    init_value();
    __defProp2 = Object.defineProperty;
    __defNormalProp = (obj, key, value) => key in obj ? __defProp2(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
    __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
    UNDEFINED_VALIDATOR_ERROR_URL = "https://docs.convex.dev/error#undefined-validator";
    BaseValidator = class {
      constructor({ isOptional }) {
        __publicField(this, "type");
        __publicField(this, "fieldPaths");
        __publicField(this, "isOptional");
        __publicField(this, "isConvexValidator");
        this.isOptional = isOptional;
        this.isConvexValidator = true;
      }
    };
    VId = class _VId extends BaseValidator {
      /**
       * Usually you'd use `v.id(tableName)` instead.
       */
      constructor({
        isOptional,
        tableName
      }) {
        super({ isOptional });
        __publicField(this, "tableName");
        __publicField(this, "kind", "id");
        if (typeof tableName !== "string") {
          throw new Error("v.id(tableName) requires a string");
        }
        this.tableName = tableName;
      }
      /** @internal */
      get json() {
        return { type: "id", tableName: this.tableName };
      }
      /** @internal */
      asOptional() {
        return new _VId({
          isOptional: "optional",
          tableName: this.tableName
        });
      }
    };
    VFloat64 = class _VFloat64 extends BaseValidator {
      constructor() {
        super(...arguments);
        __publicField(this, "kind", "float64");
      }
      /** @internal */
      get json() {
        return { type: "number" };
      }
      /** @internal */
      asOptional() {
        return new _VFloat64({
          isOptional: "optional"
        });
      }
    };
    VInt64 = class _VInt64 extends BaseValidator {
      constructor() {
        super(...arguments);
        __publicField(this, "kind", "int64");
      }
      /** @internal */
      get json() {
        return { type: "bigint" };
      }
      /** @internal */
      asOptional() {
        return new _VInt64({ isOptional: "optional" });
      }
    };
    VCommitTs = class _VCommitTs extends BaseValidator {
      constructor() {
        super(...arguments);
        __publicField(this, "kind", "commitTs");
      }
      /** @internal */
      get json() {
        return { type: this.kind };
      }
      /** @internal */
      asOptional() {
        return new _VCommitTs({
          isOptional: "optional"
        });
      }
    };
    VBoolean = class _VBoolean extends BaseValidator {
      constructor() {
        super(...arguments);
        __publicField(this, "kind", "boolean");
      }
      /** @internal */
      get json() {
        return { type: this.kind };
      }
      /** @internal */
      asOptional() {
        return new _VBoolean({
          isOptional: "optional"
        });
      }
    };
    VBytes = class _VBytes extends BaseValidator {
      constructor() {
        super(...arguments);
        __publicField(this, "kind", "bytes");
      }
      /** @internal */
      get json() {
        return { type: this.kind };
      }
      /** @internal */
      asOptional() {
        return new _VBytes({ isOptional: "optional" });
      }
    };
    VString = class _VString extends BaseValidator {
      constructor() {
        super(...arguments);
        __publicField(this, "kind", "string");
      }
      /** @internal */
      get json() {
        return { type: this.kind };
      }
      /** @internal */
      asOptional() {
        return new _VString({
          isOptional: "optional"
        });
      }
    };
    VNull = class _VNull extends BaseValidator {
      constructor() {
        super(...arguments);
        __publicField(this, "kind", "null");
      }
      /** @internal */
      get json() {
        return { type: this.kind };
      }
      /** @internal */
      asOptional() {
        return new _VNull({ isOptional: "optional" });
      }
    };
    VAny = class _VAny extends BaseValidator {
      constructor() {
        super(...arguments);
        __publicField(this, "kind", "any");
      }
      /** @internal */
      get json() {
        return {
          type: this.kind
        };
      }
      /** @internal */
      asOptional() {
        return new _VAny({
          isOptional: "optional"
        });
      }
    };
    VObject = class _VObject extends BaseValidator {
      /**
       * Usually you'd use `v.object({ ... })` instead.
       */
      constructor({
        isOptional,
        fields
      }) {
        super({ isOptional });
        __publicField(this, "fields");
        __publicField(this, "kind", "object");
        globalThis.Object.entries(fields).forEach(([fieldName, validator]) => {
          if (validator === void 0) {
            throwUndefinedValidatorError("v.object()", fieldName);
          }
          if (!validator.isConvexValidator) {
            throw new Error("v.object() entries must be validators");
          }
        });
        this.fields = fields;
      }
      /** @internal */
      get json() {
        return {
          type: this.kind,
          value: globalThis.Object.fromEntries(
            globalThis.Object.entries(this.fields).map(([k, v2]) => [
              k,
              {
                fieldType: v2.json,
                optional: v2.isOptional === "optional" ? true : false
              }
            ])
          )
        };
      }
      /** @internal */
      asOptional() {
        return new _VObject({
          isOptional: "optional",
          fields: this.fields
        });
      }
      /**
       * Create a new VObject with the specified fields omitted.
       * @param fields The field names to omit from this VObject.
       */
      omit(...fields) {
        const newFields = { ...this.fields };
        for (const field of fields) {
          delete newFields[field];
        }
        return new _VObject({
          isOptional: this.isOptional,
          fields: newFields
        });
      }
      /**
       * Create a new VObject with only the specified fields.
       * @param fields The field names to pick from this VObject.
       */
      pick(...fields) {
        const newFields = {};
        for (const field of fields) {
          newFields[field] = this.fields[field];
        }
        return new _VObject({
          isOptional: this.isOptional,
          fields: newFields
        });
      }
      /**
       * Create a new VObject with all fields marked as optional.
       */
      partial() {
        const newFields = {};
        for (const [key, validator] of globalThis.Object.entries(this.fields)) {
          newFields[key] = validator.asOptional();
        }
        return new _VObject({
          isOptional: this.isOptional,
          fields: newFields
        });
      }
      /**
       * Create a new VObject with additional fields merged in.
       * @param fields An object with additional validators to merge into this VObject.
       */
      extend(fields) {
        return new _VObject({
          isOptional: this.isOptional,
          fields: { ...this.fields, ...fields }
        });
      }
    };
    VLiteral = class _VLiteral extends BaseValidator {
      /**
       * Usually you'd use `v.literal(value)` instead.
       */
      constructor({ isOptional, value }) {
        super({ isOptional });
        __publicField(this, "value");
        __publicField(this, "kind", "literal");
        if (typeof value !== "string" && typeof value !== "boolean" && typeof value !== "number" && typeof value !== "bigint") {
          throw new Error("v.literal(value) must be a string, number, or boolean");
        }
        this.value = value;
      }
      /** @internal */
      get json() {
        return {
          type: this.kind,
          value: convexToJson(this.value)
        };
      }
      /** @internal */
      asOptional() {
        return new _VLiteral({
          isOptional: "optional",
          value: this.value
        });
      }
    };
    VArray = class _VArray extends BaseValidator {
      /**
       * Usually you'd use `v.array(element)` instead.
       */
      constructor({
        isOptional,
        element
      }) {
        super({ isOptional });
        __publicField(this, "element");
        __publicField(this, "kind", "array");
        if (element === void 0) {
          throwUndefinedValidatorError("v.array()");
        }
        this.element = element;
      }
      /** @internal */
      get json() {
        return {
          type: this.kind,
          value: this.element.json
        };
      }
      /** @internal */
      asOptional() {
        return new _VArray({
          isOptional: "optional",
          element: this.element
        });
      }
    };
    VRecord = class _VRecord extends BaseValidator {
      /**
       * Usually you'd use `v.record(key, value)` instead.
       */
      constructor({
        isOptional,
        key,
        value
      }) {
        super({ isOptional });
        __publicField(this, "key");
        __publicField(this, "value");
        __publicField(this, "kind", "record");
        if (key === void 0) {
          throwUndefinedValidatorError("v.record()", "key");
        }
        if (value === void 0) {
          throwUndefinedValidatorError("v.record()", "value");
        }
        if (key.isOptional === "optional") {
          throw new Error("Record validator cannot have optional keys");
        }
        if (value.isOptional === "optional") {
          throw new Error("Record validator cannot have optional values");
        }
        if (!key.isConvexValidator || !value.isConvexValidator) {
          throw new Error("Key and value of v.record() but be validators");
        }
        this.key = key;
        this.value = value;
      }
      /** @internal */
      get json() {
        return {
          type: this.kind,
          // This cast is needed because TypeScript thinks the key type is too wide
          keys: this.key.json,
          values: {
            fieldType: this.value.json,
            optional: false
          }
        };
      }
      /** @internal */
      asOptional() {
        return new _VRecord({
          isOptional: "optional",
          key: this.key,
          value: this.value
        });
      }
    };
    VUnion = class _VUnion extends BaseValidator {
      /**
       * Usually you'd use `v.union(...members)` instead.
       */
      constructor({ isOptional, members }) {
        super({ isOptional });
        __publicField(this, "members");
        __publicField(this, "kind", "union");
        members.forEach((member, index2) => {
          if (member === void 0) {
            throwUndefinedValidatorError("v.union()", `member at index ${index2}`);
          }
          if (!member.isConvexValidator) {
            throw new Error("All members of v.union() must be validators");
          }
        });
        this.members = members;
      }
      /** @internal */
      get json() {
        return {
          type: this.kind,
          value: this.members.map((v2) => v2.json)
        };
      }
      /** @internal */
      asOptional() {
        return new _VUnion({
          isOptional: "optional",
          members: this.members
        });
      }
    };
  }
});

// node_modules/convex/dist/esm/values/validator.js
function isValidator(v2) {
  return !!v2.isConvexValidator;
}
var v;
var init_validator = __esm({
  "node_modules/convex/dist/esm/values/validator.js"() {
    "use strict";
    init_validators();
    v = {
      /**
       * Validates that the value is a document ID for the given table.
       *
       * IDs are strings at runtime but are typed as `Id<"tableName">` in
       * TypeScript for type safety.
       *
       * @example
       * ```typescript
       * args: { userId: v.id("users") }
       * ```
       *
       * @param tableName The name of the table.
       */
      id: (tableName) => {
        return new VId({
          isOptional: "required",
          tableName
        });
      },
      /**
       * Validates that the value is `null`.
       *
       * Use `returns: v.null()` for functions that don't return a meaningful value.
       * JavaScript `undefined` is not a valid Convex value, it is automatically
       * converted to `null`.
       */
      null: () => {
        return new VNull({ isOptional: "required" });
      },
      /**
       * Validates that the value is a JavaScript `number` (Convex Float64).
       *
       * Supports all IEEE-754 double-precision floating point numbers including
       * NaN and Infinity.
       *
       * Alias for `v.float64()`.
       */
      number: () => {
        return new VFloat64({ isOptional: "required" });
      },
      /**
       * Validates that the value is a JavaScript `number` (Convex Float64).
       *
       * Supports all IEEE-754 double-precision floating point numbers.
       */
      float64: () => {
        return new VFloat64({ isOptional: "required" });
      },
      /**
       * @deprecated Use `v.int64()` instead.
       */
      bigint: () => {
        return new VInt64({ isOptional: "required" });
      },
      /**
       * Validates that the value is a JavaScript `bigint` (Convex Int64).
       *
       * Supports BigInts between -2^63 and 2^63-1.
       *
       * @example
       * ```typescript
       * args: { timestamp: v.int64() }
       * // Usage: createDoc({ timestamp: 1234567890n })
       * ```
       */
      int64: () => {
        return new VInt64({ isOptional: "required" });
      },
      /**
       * Validates that the value is a commit timestamp: an int64 (`bigint`)
       * assigned from the transaction's commit timestamp.
       *
       * An index on a field with this validator orders documents by commit order.
       * Accepts any int64 value; write `db.vars.commitTs` to have the field
       * resolve to the commit timestamp when the mutation commits.
       */
      commitTs: () => {
        return new VCommitTs({ isOptional: "required" });
      },
      /**
       * Validates that the value is a `boolean`.
       */
      boolean: () => {
        return new VBoolean({ isOptional: "required" });
      },
      /**
       * Validates that the value is a `string`.
       *
       * Strings are stored as UTF-8 and their storage size is calculated as their
       * UTF-8 encoded size.
       */
      string: () => {
        return new VString({ isOptional: "required" });
      },
      /**
       * Validates that the value is an `ArrayBuffer` (Convex Bytes).
       *
       * Use for binary data.
       */
      bytes: () => {
        return new VBytes({ isOptional: "required" });
      },
      /**
       * Validates that the value is exactly equal to the given literal.
       *
       * Useful for discriminated unions and enum-like patterns.
       *
       * @example
       * ```typescript
       * // Discriminated union pattern:
       * v.union(
       *   v.object({ kind: v.literal("error"), message: v.string() }),
       *   v.object({ kind: v.literal("success"), value: v.number() }),
       * )
       * ```
       *
       * @param literal The literal value to compare against.
       */
      literal: (literal) => {
        return new VLiteral({ isOptional: "required", value: literal });
      },
      /**
       * Validates that the value is an `Array` where every element matches the
       * given validator.
       *
       * Arrays can have at most 8192 elements.
       *
       * @example
       * ```typescript
       * args: { tags: v.array(v.string()) }
       * args: { coordinates: v.array(v.number()) }
       * args: { items: v.array(v.object({ name: v.string(), qty: v.number() })) }
       * ```
       *
       * @param element The validator for the elements of the array.
       */
      array: (element) => {
        return new VArray({ isOptional: "required", element });
      },
      /**
       * Validates that the value is an `Object` with the specified properties.
       *
       * Objects can have at most 1024 entries. Field names must be non-empty and
       * must not start with `"$"` or `"_"` (`_` is reserved for system fields
       * like `_id` and `_creationTime`; `$` is reserved for Convex internal use).
       *
       * @example
       * ```typescript
       * args: {
       *   user: v.object({
       *     name: v.string(),
       *     email: v.string(),
       *     age: v.optional(v.number()),
       *   })
       * }
       * ```
       *
       * @param fields An object mapping property names to their validators.
       */
      object: (fields) => {
        return new VObject({ isOptional: "required", fields });
      },
      /**
       * Validates that the value is a `Record` (object with dynamic keys).
       *
       * Records are objects at runtime but allow dynamic keys, unlike `v.object()`
       * which requires known property names. Keys must be ASCII characters only,
       * non-empty, and not start with `"$"` or `"_"`.
       *
       * @example
       * ```typescript
       * // Map of user IDs to scores:
       * args: { scores: v.record(v.id("users"), v.number()) }
       *
       * // Map of string keys to string values:
       * args: { metadata: v.record(v.string(), v.string()) }
       * ```
       *
       * @param keys The validator for the keys of the record.
       * @param values The validator for the values of the record.
       */
      record: (keys, values) => {
        return new VRecord({
          isOptional: "required",
          key: keys,
          value: values
        });
      },
      /**
       * Validates that the value matches at least one of the given validators.
       *
       * @example
       * ```typescript
       * // Allow string or number:
       * args: { value: v.union(v.string(), v.number()) }
       *
       * // Discriminated union (recommended pattern):
       * v.union(
       *   v.object({ kind: v.literal("text"), body: v.string() }),
       *   v.object({ kind: v.literal("image"), url: v.string() }),
       * )
       *
       * // Nullable value:
       * returns: v.union(v.object({ ... }), v.null())
       * ```
       *
       * @param members The validators to match against.
       */
      union: (...members) => {
        return new VUnion({
          isOptional: "required",
          members
        });
      },
      /**
       * A validator that accepts any Convex value without validation.
       *
       * Prefer using specific validators when possible for better type safety
       * and runtime validation.
       */
      any: () => {
        return new VAny({ isOptional: "required" });
      },
      /**
       * Makes a property optional in an object validator.
       *
       * An optional property can be omitted entirely when creating a document or
       * calling a function. This is different from `v.nullable()` which requires
       * the property to be present but allows `null`.
       *
       * @example
       * ```typescript
       * v.object({
       *   name: v.string(),              // required
       *   nickname: v.optional(v.string()), // can be omitted
       * })
       *
       * // Valid: { name: "Alice" }
       * // Valid: { name: "Alice", nickname: "Ali" }
       * // Invalid: { name: "Alice", nickname: null }  - use v.nullable() for this
       * ```
       *
       * @param value The property value validator to make optional.
       */
      optional: (value) => {
        return value.asOptional();
      },
      /**
       * Allows a value to be either the given type or `null`.
       *
       * This is shorthand for `v.union(value, v.null())`. Unlike `v.optional()`,
       * the property must still be present, but may be `null`.
       *
       * @example
       * ```typescript
       * v.object({
       *   name: v.string(),
       *   deletedAt: v.nullable(v.number()), // must be present, can be null
       * })
       *
       * // Valid: { name: "Alice", deletedAt: null }
       * // Valid: { name: "Alice", deletedAt: 1234567890 }
       * // Invalid: { name: "Alice" }  - deletedAt is required
       * ```
       */
      nullable: (value) => {
        return v.union(value, v.null());
      }
    };
  }
});

// node_modules/convex/dist/esm/values/errors.js
var __defProp3, __defNormalProp2, __publicField2, _a, _b, IDENTIFYING_FIELD, ConvexError;
var init_errors = __esm({
  "node_modules/convex/dist/esm/values/errors.js"() {
    "use strict";
    init_value();
    __defProp3 = Object.defineProperty;
    __defNormalProp2 = (obj, key, value) => key in obj ? __defProp3(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
    __publicField2 = (obj, key, value) => __defNormalProp2(obj, typeof key !== "symbol" ? key + "" : key, value);
    IDENTIFYING_FIELD = Symbol.for("ConvexError");
    ConvexError = class extends (_b = Error, _a = IDENTIFYING_FIELD, _b) {
      constructor(data) {
        super(typeof data === "string" ? data : stringifyValueForError(data));
        __publicField2(this, "name", "ConvexError");
        __publicField2(this, "data");
        __publicField2(this, _a, true);
        this.data = data;
      }
    };
  }
});

// node_modules/convex/dist/esm/values/compare_utf8.js
var arr, aBytes, bBytes;
var init_compare_utf8 = __esm({
  "node_modules/convex/dist/esm/values/compare_utf8.js"() {
    "use strict";
    arr = () => Array.from({ length: 4 }, () => 0);
    aBytes = arr();
    bBytes = arr();
  }
});

// node_modules/convex/dist/esm/values/compare.js
var init_compare = __esm({
  "node_modules/convex/dist/esm/values/compare.js"() {
    "use strict";
    init_value();
    init_compare_utf8();
  }
});

// node_modules/convex/dist/esm/values/size.js
var init_size = __esm({
  "node_modules/convex/dist/esm/values/size.js"() {
    "use strict";
    init_value();
    init_common();
  }
});

// node_modules/convex/dist/esm/values/index.js
var init_values = __esm({
  "node_modules/convex/dist/esm/values/index.js"() {
    "use strict";
    init_value();
    init_validator();
    init_base64();
    init_errors();
    init_compare();
    init_size();
  }
});

// node_modules/convex/dist/esm/browser/logging.js
function prefix_for_source(source) {
  switch (source) {
    case "query":
      return "Q";
    case "mutation":
      return "M";
    case "action":
      return "A";
    case "any":
      return "?";
  }
}
function instantiateDefaultLogger(options) {
  const logger = new DefaultLogger(options);
  logger.addLogLineListener((level, ...args) => {
    switch (level) {
      case "debug":
        console.debug(...args);
        break;
      case "info":
        console.log(...args);
        break;
      case "warn":
        console.warn(...args);
        break;
      case "error":
        console.error(...args);
        break;
      default: {
        level;
        console.log(...args);
      }
    }
  });
  return logger;
}
function instantiateNoopLogger(options) {
  return new DefaultLogger(options);
}
function logForFunction(logger, type, source, udfPath, message) {
  const prefix = prefix_for_source(source);
  if (typeof message === "object") {
    message = `ConvexError ${JSON.stringify(message.errorData, null, 2)}`;
  }
  if (type === "info") {
    const match = message.match(/^\[.*?\] /);
    if (match === null) {
      logger.error(
        `[CONVEX ${prefix}(${udfPath})] Could not parse console.log`
      );
      return;
    }
    const level = message.slice(1, match[0].length - 2);
    const args = message.slice(match[0].length);
    logger.log(`%c[CONVEX ${prefix}(${udfPath})] [${level}]`, INFO_COLOR, args);
  } else {
    logger.error(`[CONVEX ${prefix}(${udfPath})] ${message}`);
  }
}
function logFatalError(logger, message) {
  const errorMessage = `[CONVEX FATAL ERROR] ${message}`;
  logger.error(errorMessage);
  return new Error(errorMessage);
}
function createHybridErrorStacktrace(source, udfPath, result) {
  const prefix = prefix_for_source(source);
  return `[CONVEX ${prefix}(${udfPath})] ${result.errorMessage}
  Called by client`;
}
function forwardData(result, error) {
  error.data = result.errorData;
  return error;
}
var __defProp4, __defNormalProp3, __publicField3, INFO_COLOR, DefaultLogger;
var init_logging = __esm({
  "node_modules/convex/dist/esm/browser/logging.js"() {
    "use strict";
    __defProp4 = Object.defineProperty;
    __defNormalProp3 = (obj, key, value) => key in obj ? __defProp4(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
    __publicField3 = (obj, key, value) => __defNormalProp3(obj, typeof key !== "symbol" ? key + "" : key, value);
    INFO_COLOR = "color:rgb(0, 145, 255)";
    DefaultLogger = class {
      constructor(options) {
        __publicField3(this, "_onLogLineFuncs");
        __publicField3(this, "_verbose");
        this._onLogLineFuncs = {};
        this._verbose = options.verbose;
      }
      addLogLineListener(func) {
        let id = Math.random().toString(36).substring(2, 15);
        for (let i = 0; i < 10; i++) {
          if (this._onLogLineFuncs[id] === void 0) {
            break;
          }
          id = Math.random().toString(36).substring(2, 15);
        }
        this._onLogLineFuncs[id] = func;
        return () => {
          delete this._onLogLineFuncs[id];
        };
      }
      logVerbose(...args) {
        if (this._verbose) {
          for (const func of Object.values(this._onLogLineFuncs)) {
            func("debug", `${(/* @__PURE__ */ new Date()).toISOString()}`, ...args);
          }
        }
      }
      log(...args) {
        for (const func of Object.values(this._onLogLineFuncs)) {
          func("info", ...args);
        }
      }
      warn(...args) {
        for (const func of Object.values(this._onLogLineFuncs)) {
          func("warn", ...args);
        }
      }
      error(...args) {
        for (const func of Object.values(this._onLogLineFuncs)) {
          func("error", ...args);
        }
      }
    };
  }
});

// node_modules/convex/dist/esm/browser/sync/udf_path_utils.js
function canonicalizeUdfPath(udfPath) {
  const pieces = udfPath.split(":");
  let moduleName;
  let functionName2;
  if (pieces.length === 1) {
    moduleName = pieces[0];
    functionName2 = "default";
  } else {
    moduleName = pieces.slice(0, pieces.length - 1).join(":");
    functionName2 = pieces[pieces.length - 1];
  }
  if (moduleName.endsWith(".js")) {
    moduleName = moduleName.slice(0, -3);
  }
  return `${moduleName}:${functionName2}`;
}
function serializePathAndArgs(udfPath, args) {
  return JSON.stringify({
    udfPath: canonicalizeUdfPath(udfPath),
    args: convexToJson(args)
  });
}
function serializePaginatedPathAndArgs(udfPath, args, options) {
  const { initialNumItems, id } = options;
  const result = JSON.stringify({
    type: "paginated",
    udfPath: canonicalizeUdfPath(udfPath),
    args: convexToJson(args),
    options: convexToJson({ initialNumItems, id })
  });
  return result;
}
function serializedQueryTokenIsPaginated(token) {
  return JSON.parse(token).type === "paginated";
}
var init_udf_path_utils = __esm({
  "node_modules/convex/dist/esm/browser/sync/udf_path_utils.js"() {
    "use strict";
    init_values();
  }
});

// node_modules/convex/dist/esm/browser/sync/local_state.js
var __defProp5, __defNormalProp4, __publicField4, LocalSyncState;
var init_local_state = __esm({
  "node_modules/convex/dist/esm/browser/sync/local_state.js"() {
    "use strict";
    init_values();
    init_udf_path_utils();
    __defProp5 = Object.defineProperty;
    __defNormalProp4 = (obj, key, value) => key in obj ? __defProp5(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
    __publicField4 = (obj, key, value) => __defNormalProp4(obj, typeof key !== "symbol" ? key + "" : key, value);
    LocalSyncState = class {
      constructor() {
        __publicField4(this, "nextQueryId");
        __publicField4(this, "querySetVersion");
        __publicField4(this, "querySet");
        __publicField4(this, "queryIdToToken");
        __publicField4(this, "identityVersion");
        __publicField4(this, "auth");
        __publicField4(this, "outstandingQueriesOlderThanRestart");
        __publicField4(this, "outstandingAuthOlderThanRestart");
        __publicField4(this, "paused");
        __publicField4(this, "pendingQuerySetModifications");
        this.nextQueryId = 0;
        this.querySetVersion = 0;
        this.identityVersion = 0;
        this.querySet = /* @__PURE__ */ new Map();
        this.queryIdToToken = /* @__PURE__ */ new Map();
        this.outstandingQueriesOlderThanRestart = /* @__PURE__ */ new Set();
        this.outstandingAuthOlderThanRestart = false;
        this.paused = false;
        this.pendingQuerySetModifications = /* @__PURE__ */ new Map();
      }
      hasSyncedPastLastReconnect() {
        return this.outstandingQueriesOlderThanRestart.size === 0 && !this.outstandingAuthOlderThanRestart;
      }
      markAuthCompletion() {
        this.outstandingAuthOlderThanRestart = false;
      }
      subscribe(udfPath, args, journal, componentPath) {
        const canonicalizedUdfPath = canonicalizeUdfPath(udfPath);
        const queryToken = serializePathAndArgs(canonicalizedUdfPath, args);
        const existingEntry = this.querySet.get(queryToken);
        if (existingEntry !== void 0) {
          existingEntry.numSubscribers += 1;
          return {
            queryToken,
            modification: null,
            unsubscribe: () => this.removeSubscriber(queryToken)
          };
        } else {
          const queryId = this.nextQueryId++;
          const query = {
            id: queryId,
            canonicalizedUdfPath,
            args,
            numSubscribers: 1,
            journal,
            componentPath
          };
          this.querySet.set(queryToken, query);
          this.queryIdToToken.set(queryId, queryToken);
          const baseVersion = this.querySetVersion;
          const newVersion = this.querySetVersion + 1;
          const add = {
            type: "Add",
            queryId,
            udfPath: canonicalizedUdfPath,
            args: [convexToJson(args)],
            journal,
            componentPath
          };
          if (this.paused) {
            this.pendingQuerySetModifications.set(queryId, add);
          } else {
            this.querySetVersion = newVersion;
          }
          const modification = {
            type: "ModifyQuerySet",
            baseVersion,
            newVersion,
            modifications: [add]
          };
          return {
            queryToken,
            modification,
            unsubscribe: () => this.removeSubscriber(queryToken)
          };
        }
      }
      transition(transition) {
        for (const modification of transition.modifications) {
          switch (modification.type) {
            case "QueryUpdated":
            case "QueryFailed": {
              this.outstandingQueriesOlderThanRestart.delete(modification.queryId);
              const journal = modification.journal;
              if (journal !== void 0) {
                const queryToken = this.queryIdToToken.get(modification.queryId);
                if (queryToken !== void 0) {
                  this.querySet.get(queryToken).journal = journal;
                }
              }
              break;
            }
            case "QueryRemoved": {
              this.outstandingQueriesOlderThanRestart.delete(modification.queryId);
              break;
            }
            default: {
              modification;
              throw new Error(`Invalid modification ${modification.type}`);
            }
          }
        }
      }
      queryId(udfPath, args) {
        const canonicalizedUdfPath = canonicalizeUdfPath(udfPath);
        const queryToken = serializePathAndArgs(canonicalizedUdfPath, args);
        const existingEntry = this.querySet.get(queryToken);
        if (existingEntry !== void 0) {
          return existingEntry.id;
        }
        return null;
      }
      isCurrentOrNewerAuthVersion(version2) {
        return version2 >= this.identityVersion;
      }
      getAuth() {
        return this.auth;
      }
      setAuth(value) {
        this.auth = {
          tokenType: "User",
          value
        };
        const baseVersion = this.identityVersion;
        if (!this.paused) {
          this.identityVersion = baseVersion + 1;
        }
        return {
          type: "Authenticate",
          baseVersion,
          ...this.auth
        };
      }
      setAdminAuth(value, actingAs) {
        const auth = {
          tokenType: "Admin",
          value,
          impersonating: actingAs
        };
        this.auth = auth;
        const baseVersion = this.identityVersion;
        if (!this.paused) {
          this.identityVersion = baseVersion + 1;
        }
        return {
          type: "Authenticate",
          baseVersion,
          ...auth
        };
      }
      clearAuth() {
        this.auth = void 0;
        this.markAuthCompletion();
        const baseVersion = this.identityVersion;
        if (!this.paused) {
          this.identityVersion = baseVersion + 1;
        }
        return {
          type: "Authenticate",
          tokenType: "None",
          baseVersion
        };
      }
      hasAuth() {
        return !!this.auth;
      }
      isNewAuth(value) {
        return this.auth?.value !== value;
      }
      queryPath(queryId) {
        const pathAndArgs = this.queryIdToToken.get(queryId);
        if (pathAndArgs) {
          return this.querySet.get(pathAndArgs).canonicalizedUdfPath;
        }
        return null;
      }
      queryArgs(queryId) {
        const pathAndArgs = this.queryIdToToken.get(queryId);
        if (pathAndArgs) {
          return this.querySet.get(pathAndArgs).args;
        }
        return null;
      }
      queryToken(queryId) {
        return this.queryIdToToken.get(queryId) ?? null;
      }
      queryJournal(queryToken) {
        return this.querySet.get(queryToken)?.journal;
      }
      restart() {
        this.unpause();
        this.outstandingQueriesOlderThanRestart.clear();
        const modifications = [];
        for (const localQuery of this.querySet.values()) {
          const add = {
            type: "Add",
            queryId: localQuery.id,
            udfPath: localQuery.canonicalizedUdfPath,
            args: [convexToJson(localQuery.args)],
            journal: localQuery.journal,
            componentPath: localQuery.componentPath
          };
          modifications.push(add);
          this.outstandingQueriesOlderThanRestart.add(localQuery.id);
        }
        this.querySetVersion = 1;
        const querySet = {
          type: "ModifyQuerySet",
          baseVersion: 0,
          newVersion: 1,
          modifications
        };
        if (!this.auth) {
          this.identityVersion = 0;
          return [querySet, void 0];
        }
        this.outstandingAuthOlderThanRestart = true;
        const authenticate = {
          type: "Authenticate",
          baseVersion: 0,
          ...this.auth
        };
        this.identityVersion = 1;
        return [querySet, authenticate];
      }
      pause() {
        this.paused = true;
      }
      resume() {
        const querySet = this.pendingQuerySetModifications.size > 0 ? {
          type: "ModifyQuerySet",
          baseVersion: this.querySetVersion,
          newVersion: ++this.querySetVersion,
          modifications: Array.from(
            this.pendingQuerySetModifications.values()
          )
        } : void 0;
        const authenticate = this.auth !== void 0 ? {
          type: "Authenticate",
          baseVersion: this.identityVersion++,
          ...this.auth
        } : void 0;
        this.unpause();
        return [querySet, authenticate];
      }
      unpause() {
        this.paused = false;
        this.pendingQuerySetModifications.clear();
      }
      removeSubscriber(queryToken) {
        const localQuery = this.querySet.get(queryToken);
        if (localQuery.numSubscribers > 1) {
          localQuery.numSubscribers -= 1;
          return null;
        } else {
          this.querySet.delete(queryToken);
          this.queryIdToToken.delete(localQuery.id);
          this.outstandingQueriesOlderThanRestart.delete(localQuery.id);
          const baseVersion = this.querySetVersion;
          const newVersion = this.querySetVersion + 1;
          const remove = {
            type: "Remove",
            queryId: localQuery.id
          };
          if (this.paused) {
            if (this.pendingQuerySetModifications.has(localQuery.id)) {
              this.pendingQuerySetModifications.delete(localQuery.id);
            } else {
              this.pendingQuerySetModifications.set(localQuery.id, remove);
            }
          } else {
            this.querySetVersion = newVersion;
          }
          return {
            type: "ModifyQuerySet",
            baseVersion,
            newVersion,
            modifications: [remove]
          };
        }
      }
    };
  }
});

// node_modules/convex/dist/esm/browser/sync/request_manager.js
var __defProp6, __defNormalProp5, __publicField5, RequestManager;
var init_request_manager = __esm({
  "node_modules/convex/dist/esm/browser/sync/request_manager.js"() {
    "use strict";
    init_values();
    init_logging();
    __defProp6 = Object.defineProperty;
    __defNormalProp5 = (obj, key, value) => key in obj ? __defProp6(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
    __publicField5 = (obj, key, value) => __defNormalProp5(obj, typeof key !== "symbol" ? key + "" : key, value);
    RequestManager = class {
      constructor(logger, markConnectionStateDirty) {
        this.logger = logger;
        this.markConnectionStateDirty = markConnectionStateDirty;
        __publicField5(this, "inflightRequests");
        __publicField5(this, "requestsOlderThanRestart");
        __publicField5(this, "inflightMutationsCount", 0);
        __publicField5(this, "inflightActionsCount", 0);
        this.inflightRequests = /* @__PURE__ */ new Map();
        this.requestsOlderThanRestart = /* @__PURE__ */ new Set();
      }
      request(message, sent) {
        const result = new Promise((resolve) => {
          const status = sent ? "Requested" : "NotSent";
          this.inflightRequests.set(message.requestId, {
            message,
            status: { status, requestedAt: /* @__PURE__ */ new Date(), onResult: resolve }
          });
          if (message.type === "Mutation") {
            this.inflightMutationsCount++;
          } else if (message.type === "Action") {
            this.inflightActionsCount++;
          }
        });
        this.markConnectionStateDirty();
        return result;
      }
      /**
       * Update the state after receiving a response.
       *
       * @returns A RequestId if the request is complete and its optimistic update
       * can be dropped, null otherwise.
       */
      onResponse(response) {
        const requestInfo = this.inflightRequests.get(response.requestId);
        if (requestInfo === void 0) {
          return null;
        }
        if (requestInfo.status.status === "Completed") {
          return null;
        }
        const udfType = requestInfo.message.type === "Mutation" ? "mutation" : "action";
        const udfPath = requestInfo.message.udfPath;
        for (const line of response.logLines) {
          logForFunction(this.logger, "info", udfType, udfPath, line);
        }
        const status = requestInfo.status;
        let result;
        let onResolve;
        if (response.success) {
          result = {
            success: true,
            logLines: response.logLines,
            value: jsonToConvex(response.result)
          };
          onResolve = () => status.onResult(result);
        } else {
          const errorMessage = response.result;
          const { errorData } = response;
          logForFunction(this.logger, "error", udfType, udfPath, errorMessage);
          result = {
            success: false,
            errorMessage,
            errorData: errorData !== void 0 ? jsonToConvex(errorData) : void 0,
            logLines: response.logLines
          };
          onResolve = () => status.onResult(result);
        }
        if (response.type === "ActionResponse" || !response.success) {
          onResolve();
          this.inflightRequests.delete(response.requestId);
          this.requestsOlderThanRestart.delete(response.requestId);
          if (requestInfo.message.type === "Action") {
            this.inflightActionsCount--;
          } else if (requestInfo.message.type === "Mutation") {
            this.inflightMutationsCount--;
          }
          this.markConnectionStateDirty();
          return { requestId: response.requestId, result };
        }
        requestInfo.status = {
          status: "Completed",
          result,
          ts: response.ts,
          onResolve
        };
        return null;
      }
      // Remove and returns completed requests.
      removeCompleted(ts) {
        const completeRequests = /* @__PURE__ */ new Map();
        for (const [requestId, requestInfo] of this.inflightRequests.entries()) {
          const status = requestInfo.status;
          if (status.status === "Completed" && status.ts.lessThanOrEqual(ts)) {
            status.onResolve();
            completeRequests.set(requestId, status.result);
            if (requestInfo.message.type === "Mutation") {
              this.inflightMutationsCount--;
            } else if (requestInfo.message.type === "Action") {
              this.inflightActionsCount--;
            }
            this.inflightRequests.delete(requestId);
            this.requestsOlderThanRestart.delete(requestId);
          }
        }
        if (completeRequests.size > 0) {
          this.markConnectionStateDirty();
        }
        return completeRequests;
      }
      restart() {
        this.requestsOlderThanRestart = new Set(this.inflightRequests.keys());
        const allMessages = [];
        for (const [requestId, value] of this.inflightRequests) {
          if (value.status.status === "NotSent") {
            value.status.status = "Requested";
            allMessages.push(value.message);
            continue;
          }
          if (value.message.type === "Mutation") {
            allMessages.push(value.message);
          } else if (value.message.type === "Action") {
            this.inflightRequests.delete(requestId);
            this.requestsOlderThanRestart.delete(requestId);
            this.inflightActionsCount--;
            if (value.status.status === "Completed") {
              throw new Error("Action should never be in 'Completed' state");
            }
            value.status.onResult({
              success: false,
              errorMessage: "Connection lost while action was in flight",
              logLines: []
            });
          }
        }
        this.markConnectionStateDirty();
        return allMessages;
      }
      resume() {
        const allMessages = [];
        for (const [, value] of this.inflightRequests) {
          if (value.status.status === "NotSent") {
            value.status.status = "Requested";
            allMessages.push(value.message);
            continue;
          }
        }
        return allMessages;
      }
      /**
       * @returns true if there are any requests that have been requested but have
       * not be completed yet.
       */
      hasIncompleteRequests() {
        for (const requestInfo of this.inflightRequests.values()) {
          if (requestInfo.status.status === "Requested") {
            return true;
          }
        }
        return false;
      }
      /**
       * @returns true if there are any inflight requests, including ones that have
       * completed on the server, but have not been applied.
       */
      hasInflightRequests() {
        return this.inflightRequests.size > 0;
      }
      /**
       * @returns true if there are any inflight requests, that have been hanging around
       * since prior to the most recent restart.
       */
      hasSyncedPastLastReconnect() {
        return this.requestsOlderThanRestart.size === 0;
      }
      timeOfOldestInflightRequest() {
        if (this.inflightRequests.size === 0) {
          return null;
        }
        let oldestInflightRequest = Date.now();
        for (const request of this.inflightRequests.values()) {
          if (request.status.status !== "Completed") {
            if (request.status.requestedAt.getTime() < oldestInflightRequest) {
              oldestInflightRequest = request.status.requestedAt.getTime();
            }
          }
        }
        return new Date(oldestInflightRequest);
      }
      /**
       * @returns The number of mutations currently in flight.
       */
      inflightMutations() {
        return this.inflightMutationsCount;
      }
      /**
       * @returns The number of actions currently in flight.
       */
      inflightActions() {
        return this.inflightActionsCount;
      }
    };
  }
});

// node_modules/convex/dist/esm/server/functionName.js
var functionName;
var init_functionName = __esm({
  "node_modules/convex/dist/esm/server/functionName.js"() {
    "use strict";
    functionName = Symbol.for("functionName");
  }
});

// node_modules/convex/dist/esm/server/components/paths.js
function extractReferencePath(reference) {
  return reference[toReferencePath] ?? null;
}
function isFunctionHandle(s) {
  return s.startsWith("function://");
}
function getFunctionAddress(functionReference) {
  let functionAddress;
  if (typeof functionReference === "string") {
    if (isFunctionHandle(functionReference)) {
      functionAddress = { functionHandle: functionReference };
    } else {
      functionAddress = { name: functionReference };
    }
  } else if (functionReference[functionName]) {
    functionAddress = { name: functionReference[functionName] };
  } else {
    const referencePath = extractReferencePath(functionReference);
    if (!referencePath) {
      throw new Error(`${functionReference} is not a functionReference`);
    }
    functionAddress = { reference: referencePath };
  }
  return functionAddress;
}
var toReferencePath;
var init_paths = __esm({
  "node_modules/convex/dist/esm/server/components/paths.js"() {
    "use strict";
    init_functionName();
    toReferencePath = Symbol.for("toReferencePath");
  }
});

// node_modules/convex/dist/esm/server/api.js
function getFunctionName(functionReference) {
  const address = getFunctionAddress(functionReference);
  if (address.name === void 0) {
    if (address.functionHandle !== void 0) {
      throw new Error(
        `Expected function reference like "api.file.func" or "internal.file.func", but received function handle ${address.functionHandle}`
      );
    } else if (address.reference !== void 0) {
      throw new Error(
        `Expected function reference in the current component like "api.file.func" or "internal.file.func", but received reference ${address.reference}`
      );
    }
    throw new Error(
      `Expected function reference like "api.file.func" or "internal.file.func", but received ${JSON.stringify(address)}`
    );
  }
  if (typeof functionReference === "string") return functionReference;
  const name = functionReference[functionName];
  if (!name) {
    throw new Error(`${functionReference} is not a functionReference`);
  }
  return name;
}
function makeFunctionReference(name) {
  return { [functionName]: name };
}
function createApi(pathParts = []) {
  const handler = {
    get(_, prop) {
      if (typeof prop === "string") {
        const newParts = [...pathParts, prop];
        return createApi(newParts);
      } else if (prop === functionName) {
        if (pathParts.length < 2) {
          const found = ["api", ...pathParts].join(".");
          throw new Error(
            `API path is expected to be of the form \`api.moduleName.functionName\`. Found: \`${found}\``
          );
        }
        const path = pathParts.slice(0, -1).join("/");
        const exportName = pathParts[pathParts.length - 1];
        if (exportName === "default") {
          return path;
        } else {
          return path + ":" + exportName;
        }
      } else if (prop === Symbol.toStringTag) {
        return "FunctionReference";
      } else {
        return void 0;
      }
    }
  };
  return new Proxy({}, handler);
}
var anyApi;
var init_api = __esm({
  "node_modules/convex/dist/esm/server/api.js"() {
    "use strict";
    init_functionName();
    init_paths();
    anyApi = createApi();
  }
});

// node_modules/convex/dist/esm/browser/sync/optimistic_updates_impl.js
var __defProp7, __defNormalProp6, __publicField6, OptimisticLocalStoreImpl, OptimisticQueryResults;
var init_optimistic_updates_impl = __esm({
  "node_modules/convex/dist/esm/browser/sync/optimistic_updates_impl.js"() {
    "use strict";
    init_api();
    init_common();
    init_logging();
    init_udf_path_utils();
    init_errors();
    __defProp7 = Object.defineProperty;
    __defNormalProp6 = (obj, key, value) => key in obj ? __defProp7(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
    __publicField6 = (obj, key, value) => __defNormalProp6(obj, typeof key !== "symbol" ? key + "" : key, value);
    OptimisticLocalStoreImpl = class _OptimisticLocalStoreImpl {
      constructor(queryResults) {
        __publicField6(this, "queryResults");
        __publicField6(this, "modifiedQueries");
        this.queryResults = queryResults;
        this.modifiedQueries = [];
      }
      getQuery(query, ...args) {
        const queryArgs = parseArgs(args[0]);
        const name = getFunctionName(query);
        const queryResult = this.queryResults.get(
          serializePathAndArgs(name, queryArgs)
        );
        if (queryResult === void 0) {
          return void 0;
        }
        return _OptimisticLocalStoreImpl.queryValue(queryResult.result);
      }
      getAllQueries(query) {
        const queriesWithName = [];
        const name = getFunctionName(query);
        for (const queryResult of this.queryResults.values()) {
          if (queryResult.udfPath === canonicalizeUdfPath(name)) {
            queriesWithName.push({
              args: queryResult.args,
              value: _OptimisticLocalStoreImpl.queryValue(queryResult.result)
            });
          }
        }
        return queriesWithName;
      }
      setQuery(queryReference, args, value) {
        const queryArgs = parseArgs(args);
        const name = getFunctionName(queryReference);
        const queryToken = serializePathAndArgs(name, queryArgs);
        let result;
        if (value === void 0) {
          result = void 0;
        } else {
          result = {
            success: true,
            value,
            // It's an optimistic update, so there are no function logs to show.
            logLines: []
          };
        }
        const query = {
          udfPath: name,
          args: queryArgs,
          result
        };
        this.queryResults.set(queryToken, query);
        this.modifiedQueries.push(queryToken);
      }
      static queryValue(result) {
        if (result === void 0) {
          return void 0;
        } else if (result.success) {
          return result.value;
        } else {
          return void 0;
        }
      }
    };
    OptimisticQueryResults = class {
      constructor() {
        __publicField6(this, "queryResults");
        __publicField6(this, "optimisticUpdates");
        this.queryResults = /* @__PURE__ */ new Map();
        this.optimisticUpdates = [];
      }
      /**
       * Apply all optimistic updates on top of server query results
       */
      ingestQueryResultsFromServer(serverQueryResults, optimisticUpdatesToDrop) {
        this.optimisticUpdates = this.optimisticUpdates.filter((updateAndId) => {
          return !optimisticUpdatesToDrop.has(updateAndId.mutationId);
        });
        const oldQueryResults = this.queryResults;
        this.queryResults = new Map(serverQueryResults);
        const localStore = new OptimisticLocalStoreImpl(this.queryResults);
        for (const updateAndId of this.optimisticUpdates) {
          updateAndId.update(localStore);
        }
        const changedQueries = [];
        for (const [queryToken, query] of this.queryResults) {
          const oldQuery = oldQueryResults.get(queryToken);
          if (oldQuery === void 0 || oldQuery.result !== query.result) {
            changedQueries.push(queryToken);
          }
        }
        return changedQueries;
      }
      applyOptimisticUpdate(update, mutationId) {
        this.optimisticUpdates.push({
          update,
          mutationId
        });
        const localStore = new OptimisticLocalStoreImpl(this.queryResults);
        update(localStore);
        return localStore.modifiedQueries;
      }
      /**
       * "Raw" with respect to errors vs values, but query results still have
       * optimistic updates applied.
       *
       * @internal
       */
      rawQueryResult(queryToken) {
        const query = this.queryResults.get(queryToken);
        if (query === void 0) {
          return void 0;
        }
        return query.result;
      }
      queryResult(queryToken) {
        const query = this.queryResults.get(queryToken);
        if (query === void 0) {
          return void 0;
        }
        const result = query.result;
        if (result === void 0) {
          return void 0;
        } else if (result.success) {
          return result.value;
        } else {
          if (result.errorData !== void 0) {
            throw forwardData(
              result,
              new ConvexError(
                createHybridErrorStacktrace("query", query.udfPath, result)
              )
            );
          }
          throw new Error(
            createHybridErrorStacktrace("query", query.udfPath, result)
          );
        }
      }
      hasQueryResult(queryToken) {
        return this.queryResults.get(queryToken) !== void 0;
      }
      /**
       * @internal
       */
      queryLogs(queryToken) {
        const query = this.queryResults.get(queryToken);
        return query?.result?.logLines;
      }
    };
  }
});

// node_modules/convex/dist/esm/vendor/long.js
var __defProp8, __defNormalProp7, __publicField7, Long, UZERO, TWO_PWR_16_DBL, TWO_PWR_32_DBL, TWO_PWR_64_DBL, MAX_UNSIGNED_VALUE;
var init_long = __esm({
  "node_modules/convex/dist/esm/vendor/long.js"() {
    "use strict";
    __defProp8 = Object.defineProperty;
    __defNormalProp7 = (obj, key, value) => key in obj ? __defProp8(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
    __publicField7 = (obj, key, value) => __defNormalProp7(obj, typeof key !== "symbol" ? key + "" : key, value);
    Long = class _Long {
      constructor(low, high) {
        __publicField7(this, "low");
        __publicField7(this, "high");
        __publicField7(this, "__isUnsignedLong__");
        this.low = low | 0;
        this.high = high | 0;
        this.__isUnsignedLong__ = true;
      }
      static isLong(obj) {
        return (obj && obj.__isUnsignedLong__) === true;
      }
      // prettier-ignore
      static fromBytesLE(bytes) {
        return new _Long(
          bytes[0] | bytes[1] << 8 | bytes[2] << 16 | bytes[3] << 24,
          bytes[4] | bytes[5] << 8 | bytes[6] << 16 | bytes[7] << 24
        );
      }
      // prettier-ignore
      toBytesLE() {
        const hi = this.high;
        const lo = this.low;
        return [
          lo & 255,
          lo >>> 8 & 255,
          lo >>> 16 & 255,
          lo >>> 24,
          hi & 255,
          hi >>> 8 & 255,
          hi >>> 16 & 255,
          hi >>> 24
        ];
      }
      static fromNumber(value) {
        if (isNaN(value)) return UZERO;
        if (value < 0) return UZERO;
        if (value >= TWO_PWR_64_DBL) return MAX_UNSIGNED_VALUE;
        return new _Long(value % TWO_PWR_32_DBL | 0, value / TWO_PWR_32_DBL | 0);
      }
      toString() {
        return (BigInt(this.high) * BigInt(TWO_PWR_32_DBL) + BigInt(this.low)).toString();
      }
      equals(other) {
        if (!_Long.isLong(other)) other = _Long.fromValue(other);
        if (this.high >>> 31 === 1 && other.high >>> 31 === 1) return false;
        return this.high === other.high && this.low === other.low;
      }
      notEquals(other) {
        return !this.equals(other);
      }
      comp(other) {
        if (!_Long.isLong(other)) other = _Long.fromValue(other);
        if (this.equals(other)) return 0;
        return other.high >>> 0 > this.high >>> 0 || other.high === this.high && other.low >>> 0 > this.low >>> 0 ? -1 : 1;
      }
      lessThanOrEqual(other) {
        return this.comp(
          /* validates */
          other
        ) <= 0;
      }
      static fromValue(val) {
        if (typeof val === "number") return _Long.fromNumber(val);
        return new _Long(val.low, val.high);
      }
    };
    UZERO = new Long(0, 0);
    TWO_PWR_16_DBL = 1 << 16;
    TWO_PWR_32_DBL = TWO_PWR_16_DBL * TWO_PWR_16_DBL;
    TWO_PWR_64_DBL = TWO_PWR_32_DBL * TWO_PWR_32_DBL;
    MAX_UNSIGNED_VALUE = new Long(4294967295 | 0, 4294967295 | 0);
  }
});

// node_modules/convex/dist/esm/browser/sync/remote_query_set.js
var __defProp9, __defNormalProp8, __publicField8, RemoteQuerySet;
var init_remote_query_set = __esm({
  "node_modules/convex/dist/esm/browser/sync/remote_query_set.js"() {
    "use strict";
    init_values();
    init_long();
    init_logging();
    __defProp9 = Object.defineProperty;
    __defNormalProp8 = (obj, key, value) => key in obj ? __defProp9(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
    __publicField8 = (obj, key, value) => __defNormalProp8(obj, typeof key !== "symbol" ? key + "" : key, value);
    RemoteQuerySet = class {
      constructor(queryPath, logger) {
        __publicField8(this, "version");
        __publicField8(this, "remoteQuerySet");
        __publicField8(this, "queryPath");
        __publicField8(this, "logger");
        this.version = { querySet: 0, ts: Long.fromNumber(0), identity: 0 };
        this.remoteQuerySet = /* @__PURE__ */ new Map();
        this.queryPath = queryPath;
        this.logger = logger;
      }
      transition(transition) {
        const start = transition.startVersion;
        if (this.version.querySet !== start.querySet || this.version.ts.notEquals(start.ts) || this.version.identity !== start.identity) {
          throw new Error(
            `Invalid start version: ${start.ts.toString()}:${start.querySet}:${start.identity}, transitioning from ${this.version.ts.toString()}:${this.version.querySet}:${this.version.identity}`
          );
        }
        for (const modification of transition.modifications) {
          switch (modification.type) {
            case "QueryUpdated": {
              const queryPath = this.queryPath(modification.queryId);
              if (queryPath) {
                for (const line of modification.logLines) {
                  logForFunction(this.logger, "info", "query", queryPath, line);
                }
              }
              const value = jsonToConvex(modification.value ?? null);
              this.remoteQuerySet.set(modification.queryId, {
                success: true,
                value,
                logLines: modification.logLines
              });
              break;
            }
            case "QueryFailed": {
              const queryPath = this.queryPath(modification.queryId);
              if (queryPath) {
                for (const line of modification.logLines) {
                  logForFunction(this.logger, "info", "query", queryPath, line);
                }
              }
              const { errorData } = modification;
              this.remoteQuerySet.set(modification.queryId, {
                success: false,
                errorMessage: modification.errorMessage,
                errorData: errorData !== void 0 ? jsonToConvex(errorData) : void 0,
                logLines: modification.logLines
              });
              break;
            }
            case "QueryRemoved": {
              this.remoteQuerySet.delete(modification.queryId);
              break;
            }
            default: {
              modification;
              throw new Error(`Invalid modification ${modification.type}`);
            }
          }
        }
        this.version = transition.endVersion;
      }
      remoteQueryResults() {
        return this.remoteQuerySet;
      }
      timestamp() {
        return this.version.ts;
      }
    };
  }
});

// node_modules/convex/dist/esm/browser/sync/protocol.js
function u64ToLong(encoded) {
  const integerBytes = base64_exports.toByteArray(encoded);
  return Long.fromBytesLE(Array.from(integerBytes));
}
function longToU64(raw) {
  const integerBytes = new Uint8Array(raw.toBytesLE());
  return base64_exports.fromByteArray(integerBytes);
}
function parseServerMessage(encoded) {
  switch (encoded.type) {
    case "FatalError":
    case "AuthError":
    case "ActionResponse":
    case "TransitionChunk":
    case "Ping": {
      return { ...encoded };
    }
    case "MutationResponse": {
      if (encoded.success) {
        return { ...encoded, ts: u64ToLong(encoded.ts) };
      } else {
        return { ...encoded };
      }
    }
    case "Transition": {
      return {
        ...encoded,
        startVersion: {
          ...encoded.startVersion,
          ts: u64ToLong(encoded.startVersion.ts)
        },
        endVersion: {
          ...encoded.endVersion,
          ts: u64ToLong(encoded.endVersion.ts)
        }
      };
    }
    default: {
      encoded;
    }
  }
  return void 0;
}
function encodeClientMessage(message) {
  switch (message.type) {
    case "Authenticate":
    case "ModifyQuerySet":
    case "Mutation":
    case "Action":
    case "Event": {
      return { ...message };
    }
    case "Connect": {
      if (message.maxObservedTimestamp !== void 0) {
        return {
          ...message,
          maxObservedTimestamp: longToU64(message.maxObservedTimestamp)
        };
      } else {
        return { ...message, maxObservedTimestamp: void 0 };
      }
    }
    default: {
      message;
    }
  }
  return void 0;
}
var init_protocol = __esm({
  "node_modules/convex/dist/esm/browser/sync/protocol.js"() {
    "use strict";
    init_values();
    init_long();
  }
});

// node_modules/convex/dist/esm/browser/sync/web_socket_manager.js
function monotonicMillis() {
  if (firstTime === void 0) {
    firstTime = Date.now();
  }
  if (typeof performance === "undefined" || !performance.now) {
    return Date.now();
  }
  return Math.round(firstTime + performance.now());
}
function prettyNow() {
  return `t=${Math.round((monotonicMillis() - firstTime) / 100) / 10}s`;
}
function classifyDisconnectError(s) {
  if (s === void 0) return "Unknown";
  for (const prefix of Object.keys(
    serverDisconnectErrors
  )) {
    if (s.startsWith(prefix)) {
      return prefix;
    }
  }
  return "Unknown";
}
var __defProp10, __defNormalProp9, __publicField9, CLOSE_NORMAL, CLOSE_GOING_AWAY, CLOSE_NO_STATUS, CLOSE_NOT_FOUND, firstTime, serverDisconnectErrors, WebSocketManager;
var init_web_socket_manager = __esm({
  "node_modules/convex/dist/esm/browser/sync/web_socket_manager.js"() {
    "use strict";
    init_protocol();
    __defProp10 = Object.defineProperty;
    __defNormalProp9 = (obj, key, value) => key in obj ? __defProp10(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
    __publicField9 = (obj, key, value) => __defNormalProp9(obj, typeof key !== "symbol" ? key + "" : key, value);
    CLOSE_NORMAL = 1e3;
    CLOSE_GOING_AWAY = 1001;
    CLOSE_NO_STATUS = 1005;
    CLOSE_NOT_FOUND = 4040;
    serverDisconnectErrors = {
      // A known error, e.g. during a restart or push
      InternalServerError: { timeout: 1e3 },
      // ErrorMetadata::overloaded() messages that we realy should back off
      SubscriptionsWorkerFullError: { timeout: 3e3 },
      TooManyConcurrentRequests: { timeout: 3e3 },
      CommitterFullError: { timeout: 3e3 },
      AwsTooManyRequestsException: { timeout: 3e3 },
      ExecuteFullError: { timeout: 3e3 },
      SystemTimeoutError: { timeout: 3e3 },
      ExpiredInQueue: { timeout: 3e3 },
      // ErrorMetadata::feature_temporarily_unavailable() that typically indicate a deploy just happened
      VectorIndexesUnavailable: { timeout: 1e3 },
      SearchIndexesUnavailable: { timeout: 1e3 },
      TableSummariesUnavailable: { timeout: 1e3 },
      // More ErrorMetadata::overloaded()
      VectorIndexTooLarge: { timeout: 3e3 },
      SearchIndexTooLarge: { timeout: 3e3 },
      TooManyWritesInTimePeriod: { timeout: 3e3 }
    };
    WebSocketManager = class {
      constructor(uri, callbacks, webSocketConstructor, logger, markConnectionStateDirty, debug) {
        this.markConnectionStateDirty = markConnectionStateDirty;
        this.debug = debug;
        __publicField9(this, "socket");
        __publicField9(this, "connectionCount");
        __publicField9(this, "_hasEverConnected", false);
        __publicField9(this, "lastCloseReason");
        __publicField9(this, "transitionChunkBuffer", null);
        __publicField9(this, "defaultInitialBackoff");
        __publicField9(this, "maxBackoff");
        __publicField9(this, "retries");
        __publicField9(this, "serverInactivityThreshold");
        __publicField9(this, "reconnectDueToServerInactivityTimeout");
        __publicField9(this, "scheduledReconnect", null);
        __publicField9(this, "networkOnlineHandler", null);
        __publicField9(this, "pendingNetworkRecoveryInfo", null);
        __publicField9(this, "uri");
        __publicField9(this, "onOpen");
        __publicField9(this, "onResume");
        __publicField9(this, "onMessage");
        __publicField9(this, "webSocketConstructor");
        __publicField9(this, "logger");
        __publicField9(this, "onServerDisconnectError");
        this.webSocketConstructor = webSocketConstructor;
        this.socket = { state: "disconnected" };
        this.connectionCount = 0;
        this.lastCloseReason = "InitialConnect";
        this.defaultInitialBackoff = 1e3;
        this.maxBackoff = 16e3;
        this.retries = 0;
        this.serverInactivityThreshold = 6e4;
        this.reconnectDueToServerInactivityTimeout = null;
        this.uri = uri;
        this.onOpen = callbacks.onOpen;
        this.onResume = callbacks.onResume;
        this.onMessage = callbacks.onMessage;
        this.onServerDisconnectError = callbacks.onServerDisconnectError;
        this.logger = logger;
        this.setupNetworkListener();
        this.connect();
      }
      setSocketState(state) {
        this.socket = state;
        this._logVerbose(
          `socket state changed: ${this.socket.state}, paused: ${"paused" in this.socket ? this.socket.paused : void 0}`
        );
        this.markConnectionStateDirty();
      }
      setupNetworkListener() {
        if (typeof window === "undefined" || typeof window.addEventListener !== "function") {
          return;
        }
        if (this.networkOnlineHandler !== null) {
          return;
        }
        this.networkOnlineHandler = () => {
          this._logVerbose("network online event detected");
          this.tryReconnectImmediately();
        };
        window.addEventListener("online", this.networkOnlineHandler);
        this._logVerbose("network online event listener registered");
      }
      cleanupNetworkListener() {
        if (this.networkOnlineHandler && typeof window !== "undefined" && typeof window.removeEventListener === "function") {
          window.removeEventListener("online", this.networkOnlineHandler);
          this.networkOnlineHandler = null;
          this._logVerbose("network online event listener removed");
        }
      }
      assembleTransition(chunk) {
        if (chunk.partNumber < 0 || chunk.partNumber >= chunk.totalParts || chunk.totalParts === 0 || this.transitionChunkBuffer && (this.transitionChunkBuffer.totalParts !== chunk.totalParts || this.transitionChunkBuffer.transitionId !== chunk.transitionId)) {
          this.transitionChunkBuffer = null;
          throw new Error("Invalid TransitionChunk");
        }
        if (this.transitionChunkBuffer === null) {
          this.transitionChunkBuffer = {
            chunks: [],
            totalParts: chunk.totalParts,
            transitionId: chunk.transitionId
          };
        }
        if (chunk.partNumber !== this.transitionChunkBuffer.chunks.length) {
          const expectedLength = this.transitionChunkBuffer.chunks.length;
          this.transitionChunkBuffer = null;
          throw new Error(
            `TransitionChunk received out of order: expected part ${expectedLength}, got ${chunk.partNumber}`
          );
        }
        this.transitionChunkBuffer.chunks.push(chunk.chunk);
        if (this.transitionChunkBuffer.chunks.length === chunk.totalParts) {
          const fullJson = this.transitionChunkBuffer.chunks.join("");
          this.transitionChunkBuffer = null;
          const transition = parseServerMessage(JSON.parse(fullJson));
          if (transition.type !== "Transition") {
            throw new Error(
              `Expected Transition, got ${transition.type} after assembling chunks`
            );
          }
          return transition;
        }
        return null;
      }
      connect() {
        if (this.socket.state === "terminated") {
          return;
        }
        if (this.socket.state !== "disconnected" && this.socket.state !== "stopped") {
          throw new Error(
            "Didn't start connection from disconnected state: " + this.socket.state
          );
        }
        const ws = new this.webSocketConstructor(this.uri);
        this._logVerbose("constructed WebSocket");
        this.setSocketState({
          state: "connecting",
          ws,
          paused: "no"
        });
        this.resetServerInactivityTimeout();
        ws.onopen = () => {
          this.logger.logVerbose("begin ws.onopen");
          if (this.socket.state !== "connecting") {
            throw new Error("onopen called with socket not in connecting state");
          }
          this.setSocketState({
            state: "ready",
            ws,
            paused: this.socket.paused === "yes" ? "uninitialized" : "no"
          });
          this.resetServerInactivityTimeout();
          if (this.socket.paused === "no") {
            this._hasEverConnected = true;
            this.onOpen({
              connectionCount: this.connectionCount,
              lastCloseReason: this.lastCloseReason,
              clientTs: monotonicMillis()
            });
          }
          if (this.lastCloseReason !== "InitialConnect") {
            if (this.lastCloseReason) {
              this.logger.log(
                "WebSocket reconnected at",
                prettyNow(),
                "after disconnect due to",
                this.lastCloseReason
              );
            } else {
              this.logger.log("WebSocket reconnected at", prettyNow());
            }
          }
          this.connectionCount += 1;
          this.lastCloseReason = null;
          if (this.pendingNetworkRecoveryInfo !== null) {
            const { timeSavedMs } = this.pendingNetworkRecoveryInfo;
            this.pendingNetworkRecoveryInfo = null;
            this.sendMessage({
              type: "Event",
              eventType: "NetworkRecoveryReconnect",
              event: { timeSavedMs }
            });
            this.logger.log(
              `Network recovery reconnect saved ~${Math.round(timeSavedMs / 1e3)}s of waiting`
            );
          }
        };
        ws.onerror = (error) => {
          this.transitionChunkBuffer = null;
          const message = error.message;
          if (message) {
            this.logger.log(`WebSocket error message: ${message}`);
          }
        };
        ws.onmessage = (message) => {
          this.resetServerInactivityTimeout();
          const messageLength = message.data.length;
          let serverMessage = parseServerMessage(JSON.parse(message.data));
          this._logVerbose(`received ws message with type ${serverMessage.type}`);
          if (serverMessage.type === "Ping") {
            return;
          }
          if (serverMessage.type === "TransitionChunk") {
            const transition = this.assembleTransition(serverMessage);
            if (!transition) {
              return;
            }
            serverMessage = transition;
            this._logVerbose(
              `assembled full ws message of type ${serverMessage.type}`
            );
          }
          if (this.transitionChunkBuffer !== null) {
            this.transitionChunkBuffer = null;
            this.logger.log(
              `Received unexpected ${serverMessage.type} while buffering TransitionChunks`
            );
          }
          if (serverMessage.type === "Transition") {
            this.reportLargeTransition({
              messageLength,
              transition: serverMessage
            });
          }
          const response = this.onMessage(serverMessage);
          if (response.hasSyncedPastLastReconnect) {
            this.retries = 0;
            this.markConnectionStateDirty();
          }
        };
        ws.onclose = (event) => {
          this._logVerbose("begin ws.onclose");
          this.transitionChunkBuffer = null;
          if (this.lastCloseReason === null) {
            this.lastCloseReason = event.reason || `closed with code ${event.code}`;
          }
          if (event.code !== CLOSE_NORMAL && event.code !== CLOSE_GOING_AWAY && // This commonly gets fired on mobile apps when the app is backgrounded
          event.code !== CLOSE_NO_STATUS && event.code !== CLOSE_NOT_FOUND) {
            let msg = `WebSocket closed with code ${event.code}`;
            if (event.reason) {
              msg += `: ${event.reason}`;
            }
            this.logger.log(msg);
            if (this.onServerDisconnectError && event.reason) {
              this.onServerDisconnectError(msg);
            }
          }
          const reason = classifyDisconnectError(event.reason);
          this.scheduleReconnect(reason);
          return;
        };
      }
      /**
       * @returns The state of the {@link Socket}.
       */
      socketState() {
        return this.socket.state;
      }
      /**
       * @param message - A ClientMessage to send.
       * @returns Whether the message (might have been) sent.
       */
      sendMessage(message) {
        const messageForLog = {
          type: message.type,
          ...message.type === "Authenticate" && message.tokenType === "User" ? {
            value: `...${message.value.slice(-7)}`
          } : {}
        };
        if (this.socket.state === "ready" && this.socket.paused === "no") {
          const encodedMessage = encodeClientMessage(message);
          const request = JSON.stringify(encodedMessage);
          let sent = false;
          try {
            this.socket.ws.send(request);
            sent = true;
          } catch (error) {
            this.logger.log(
              `Failed to send message on WebSocket, reconnecting: ${error}`
            );
            this.closeAndReconnect("FailedToSendMessage");
          }
          this._logVerbose(
            `${sent ? "sent" : "failed to send"} message with type ${message.type}: ${JSON.stringify(
              messageForLog
            )}`
          );
          return true;
        }
        this._logVerbose(
          `message not sent (socket state: ${this.socket.state}, paused: ${"paused" in this.socket ? this.socket.paused : void 0}): ${JSON.stringify(
            messageForLog
          )}`
        );
        return false;
      }
      resetServerInactivityTimeout() {
        if (this.socket.state === "terminated") {
          return;
        }
        if (this.reconnectDueToServerInactivityTimeout !== null) {
          clearTimeout(this.reconnectDueToServerInactivityTimeout);
          this.reconnectDueToServerInactivityTimeout = null;
        }
        this.reconnectDueToServerInactivityTimeout = setTimeout(() => {
          this.closeAndReconnect("InactiveServer");
        }, this.serverInactivityThreshold);
      }
      scheduleReconnect(reason) {
        if (this.scheduledReconnect) {
          clearTimeout(this.scheduledReconnect.timeout);
          this.scheduledReconnect = null;
        }
        this.socket = { state: "disconnected" };
        const backoff = this.nextBackoff(reason);
        this.markConnectionStateDirty();
        this.logger.log(`Attempting reconnect in ${Math.round(backoff)}ms`);
        const scheduledAt = monotonicMillis();
        const timeoutId = setTimeout(() => {
          if (this.scheduledReconnect?.timeout === timeoutId) {
            this.scheduledReconnect = null;
            this.connect();
          }
        }, backoff);
        this.scheduledReconnect = {
          timeout: timeoutId,
          scheduledAt,
          backoffMs: backoff
        };
      }
      /**
       * Close the WebSocket and schedule a reconnect.
       *
       * This should be used when we hit an error and would like to restart the session.
       */
      closeAndReconnect(closeReason) {
        this._logVerbose(`begin closeAndReconnect with reason ${closeReason}`);
        switch (this.socket.state) {
          case "disconnected":
          case "terminated":
          case "stopped":
            return;
          case "connecting":
          case "ready": {
            this.lastCloseReason = closeReason;
            void this.close();
            this.scheduleReconnect("client");
            return;
          }
          default: {
            this.socket;
          }
        }
      }
      /**
       * Close the WebSocket, being careful to clear the onclose handler to avoid re-entrant
       * calls. Use this instead of directly calling `ws.close()`
       *
       * It is the callers responsibility to update the state after this method is called so that the
       * closed socket is not accessible or used again after this method is called
       */
      close() {
        this.transitionChunkBuffer = null;
        switch (this.socket.state) {
          case "disconnected":
          case "terminated":
          case "stopped":
            return Promise.resolve();
          case "connecting": {
            const ws = this.socket.ws;
            ws.onmessage = (_message) => {
              this._logVerbose("Ignoring message received after close");
            };
            return new Promise((r) => {
              ws.onclose = () => {
                this._logVerbose("Closed after connecting");
                r();
              };
              ws.onopen = () => {
                this._logVerbose("Opened after connecting");
                ws.close();
              };
            });
          }
          case "ready": {
            this._logVerbose("ws.close called");
            const ws = this.socket.ws;
            ws.onmessage = (_message) => {
              this._logVerbose("Ignoring message received after close");
            };
            const result = new Promise((r) => {
              ws.onclose = () => {
                r();
              };
            });
            ws.close();
            return result;
          }
          default: {
            this.socket;
            return Promise.resolve();
          }
        }
      }
      /**
       * Close the WebSocket and do not reconnect.
       * @returns A Promise that resolves when the WebSocket `onClose` callback is called.
       */
      terminate() {
        if (this.reconnectDueToServerInactivityTimeout) {
          clearTimeout(this.reconnectDueToServerInactivityTimeout);
        }
        if (this.scheduledReconnect) {
          clearTimeout(this.scheduledReconnect.timeout);
          this.scheduledReconnect = null;
        }
        this.cleanupNetworkListener();
        switch (this.socket.state) {
          case "terminated":
          case "stopped":
          case "disconnected":
          case "connecting":
          case "ready": {
            const result = this.close();
            this.setSocketState({ state: "terminated" });
            return result;
          }
          default: {
            this.socket;
            throw new Error(
              `Invalid websocket state: ${this.socket.state}`
            );
          }
        }
      }
      stop() {
        switch (this.socket.state) {
          case "terminated":
            return Promise.resolve();
          case "connecting":
          case "stopped":
          case "disconnected":
          case "ready": {
            this.cleanupNetworkListener();
            const result = this.close();
            this.socket = { state: "stopped" };
            return result;
          }
          default: {
            this.socket;
            return Promise.resolve();
          }
        }
      }
      /**
       * Create a new WebSocket after a previous `stop()`, unless `terminate()` was
       * called before.
       */
      tryRestart() {
        switch (this.socket.state) {
          case "stopped":
            break;
          case "terminated":
          case "connecting":
          case "ready":
          case "disconnected":
            this.logger.logVerbose("Restart called without stopping first");
            return;
          default: {
            this.socket;
          }
        }
        this.setupNetworkListener();
        this.connect();
      }
      pause() {
        switch (this.socket.state) {
          case "disconnected":
          case "stopped":
          case "terminated":
            return;
          case "connecting":
          case "ready": {
            this.socket = { ...this.socket, paused: "yes" };
            return;
          }
          default: {
            this.socket;
            return;
          }
        }
      }
      /**
       * Try to reconnect immediately, canceling any scheduled reconnect.
       * This is useful when detecting network recovery.
       * Only takes action if we're in disconnected state (waiting to reconnect).
       */
      tryReconnectImmediately() {
        this._logVerbose("tryReconnectImmediately called");
        if (this.socket.state !== "disconnected") {
          this._logVerbose(
            `tryReconnectImmediately called but socket state is ${this.socket.state}, no action taken`
          );
          return;
        }
        let timeSavedMs = null;
        if (this.scheduledReconnect) {
          const elapsed = monotonicMillis() - this.scheduledReconnect.scheduledAt;
          timeSavedMs = Math.max(0, this.scheduledReconnect.backoffMs - elapsed);
          this._logVerbose(
            `would have waited ${Math.round(timeSavedMs)}ms more (backoff was ${Math.round(this.scheduledReconnect.backoffMs)}ms, elapsed ${Math.round(elapsed)}ms)`
          );
          clearTimeout(this.scheduledReconnect.timeout);
          this.scheduledReconnect = null;
          this._logVerbose("canceled scheduled reconnect");
        }
        this.logger.log("Network recovery detected, reconnecting immediately");
        this.pendingNetworkRecoveryInfo = timeSavedMs !== null ? { timeSavedMs } : null;
        this.connect();
      }
      /**
       * Resume the state machine if previously paused.
       */
      resume() {
        switch (this.socket.state) {
          case "connecting":
            this.socket = { ...this.socket, paused: "no" };
            return;
          case "ready":
            if (this.socket.paused === "uninitialized") {
              this.socket = { ...this.socket, paused: "no" };
              this._hasEverConnected = true;
              this.onOpen({
                connectionCount: this.connectionCount,
                lastCloseReason: this.lastCloseReason,
                clientTs: monotonicMillis()
              });
            } else if (this.socket.paused === "yes") {
              this.socket = { ...this.socket, paused: "no" };
              this.onResume();
            }
            return;
          case "terminated":
          case "stopped":
          case "disconnected":
            return;
          default: {
            this.socket;
          }
        }
        this.connect();
      }
      connectionState() {
        return {
          isConnected: this.socket.state === "ready",
          hasEverConnected: this._hasEverConnected,
          connectionCount: this.connectionCount,
          connectionRetries: this.retries
        };
      }
      _logVerbose(message) {
        this.logger.logVerbose(message);
      }
      nextBackoff(reason) {
        const initialBackoff = reason === "client" ? 100 : reason === "Unknown" ? this.defaultInitialBackoff : serverDisconnectErrors[reason].timeout;
        const baseBackoff = initialBackoff * Math.pow(2, this.retries);
        this.retries += 1;
        const actualBackoff = Math.min(baseBackoff, this.maxBackoff);
        const jitter = actualBackoff * (Math.random() - 0.5);
        return actualBackoff + jitter;
      }
      reportLargeTransition({
        transition,
        messageLength
      }) {
        if (transition.clientClockSkew === void 0 || transition.serverTs === void 0) {
          return;
        }
        const transitionTransitTime = monotonicMillis() - // client time now
        // clientClockSkew = (server time + upstream latency) - client time
        // clientClockSkew is "how many milliseconds behind (slow) is the client clock"
        // but the latency of the Connect message inflates this, making it appear further behind
        transition.clientClockSkew - transition.serverTs / 1e6;
        const prettyTransitionTime = `${Math.round(transitionTransitTime)}ms`;
        const prettyMessageMB = `${Math.round(messageLength / 1e4) / 100}MB`;
        const bytesPerSecond = messageLength / (transitionTransitTime / 1e3);
        const prettyBytesPerSecond = `${Math.round(bytesPerSecond / 1e4) / 100}MB per second`;
        this._logVerbose(
          `received ${prettyMessageMB} transition in ${prettyTransitionTime} at ${prettyBytesPerSecond}`
        );
        if (messageLength > 2e7) {
          this.logger.log(
            `received query results totaling more that 20MB (${prettyMessageMB}) which will take a long time to download on slower connections`
          );
        } else if (transitionTransitTime > 2e4) {
          this.logger.log(
            `received query results totaling ${prettyMessageMB} which took more than 20s to arrive (${prettyTransitionTime})`
          );
        }
        if (this.debug) {
          this.sendMessage({
            type: "Event",
            eventType: "ClientReceivedTransition",
            event: { transitionTransitTime, messageLength }
          });
        }
      }
    };
  }
});

// node_modules/convex/dist/esm/browser/sync/session.js
function newSessionId() {
  return uuidv4();
}
function uuidv4() {
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = Math.random() * 16 | 0, v2 = c === "x" ? r : r & 3 | 8;
    return v2.toString(16);
  });
}
var init_session = __esm({
  "node_modules/convex/dist/esm/browser/sync/session.js"() {
    "use strict";
  }
});

// node_modules/convex/dist/esm/vendor/jwt-decode/index.js
function b64DecodeUnicode(str) {
  return decodeURIComponent(
    atob(str).replace(/(.)/g, (_m, p) => {
      let code2 = p.charCodeAt(0).toString(16).toUpperCase();
      if (code2.length < 2) {
        code2 = "0" + code2;
      }
      return "%" + code2;
    })
  );
}
function base64UrlDecode(str) {
  let output = str.replace(/-/g, "+").replace(/_/g, "/");
  switch (output.length % 4) {
    case 0:
      break;
    case 2:
      output += "==";
      break;
    case 3:
      output += "=";
      break;
    default:
      throw new Error("base64 string is not of the correct length");
  }
  try {
    return b64DecodeUnicode(output);
  } catch {
    return atob(output);
  }
}
function jwtDecode(token, options) {
  if (typeof token !== "string") {
    throw new InvalidTokenError("Invalid token specified: must be a string");
  }
  options || (options = {});
  const pos = options.header === true ? 0 : 1;
  const part = token.split(".")[pos];
  if (typeof part !== "string") {
    throw new InvalidTokenError(
      `Invalid token specified: missing part #${pos + 1}`
    );
  }
  let decoded;
  try {
    decoded = base64UrlDecode(part);
  } catch (e) {
    throw new InvalidTokenError(
      `Invalid token specified: invalid base64 for part #${pos + 1} (${e.message})`
    );
  }
  try {
    return JSON.parse(decoded);
  } catch (e) {
    throw new InvalidTokenError(
      `Invalid token specified: invalid json for part #${pos + 1} (${e.message})`
    );
  }
}
var InvalidTokenError;
var init_jwt_decode = __esm({
  "node_modules/convex/dist/esm/vendor/jwt-decode/index.js"() {
    "use strict";
    InvalidTokenError = class extends Error {
    };
    InvalidTokenError.prototype.name = "InvalidTokenError";
  }
});

// node_modules/convex/dist/esm/browser/sync/authentication_manager.js
var __defProp11, __defNormalProp10, __publicField10, MAXIMUM_REFRESH_DELAY, MAX_TOKEN_CONFIRMATION_ATTEMPTS, AuthenticationManager;
var init_authentication_manager = __esm({
  "node_modules/convex/dist/esm/browser/sync/authentication_manager.js"() {
    "use strict";
    init_jwt_decode();
    __defProp11 = Object.defineProperty;
    __defNormalProp10 = (obj, key, value) => key in obj ? __defProp11(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
    __publicField10 = (obj, key, value) => __defNormalProp10(obj, typeof key !== "symbol" ? key + "" : key, value);
    MAXIMUM_REFRESH_DELAY = 20 * 24 * 60 * 60 * 1e3;
    MAX_TOKEN_CONFIRMATION_ATTEMPTS = 2;
    AuthenticationManager = class {
      constructor(syncState, callbacks, config) {
        __publicField10(this, "authState", { state: "noAuth" });
        __publicField10(this, "configVersion", 0);
        __publicField10(this, "syncState");
        __publicField10(this, "authenticate");
        __publicField10(this, "stopSocket");
        __publicField10(this, "tryRestartSocket");
        __publicField10(this, "pauseSocket");
        __publicField10(this, "resumeSocket");
        __publicField10(this, "clearAuth");
        __publicField10(this, "logger");
        __publicField10(this, "refreshTokenLeewaySeconds");
        __publicField10(this, "initialAuthTokenReuse");
        __publicField10(this, "lastRefreshChange");
        __publicField10(this, "tokenConfirmationAttempts", 0);
        this.syncState = syncState;
        this.authenticate = callbacks.authenticate;
        this.stopSocket = callbacks.stopSocket;
        this.tryRestartSocket = callbacks.tryRestartSocket;
        this.pauseSocket = callbacks.pauseSocket;
        this.resumeSocket = callbacks.resumeSocket;
        this.clearAuth = callbacks.clearAuth;
        this.logger = config.logger;
        this.refreshTokenLeewaySeconds = config.refreshTokenLeewaySeconds;
        this.initialAuthTokenReuse = config.initialAuthTokenReuse;
        this.lastRefreshChange = false;
      }
      notifyRefreshChange(isRefreshing) {
        if (this.authState.state !== "noAuth" && this.authState.state !== "initialRefetch" && this.authState.config.onRefreshChange && this.lastRefreshChange !== isRefreshing) {
          this.lastRefreshChange = isRefreshing;
          this.authState.config.onRefreshChange(isRefreshing);
        }
      }
      async setConfig(fetchToken, onChange, onRefreshChange) {
        this.resetAuthState();
        this._logVerbose("pausing WS for auth token fetch");
        this.pauseSocket();
        const token = await this.fetchTokenAndGuardAgainstRace(fetchToken, {
          forceRefreshToken: false
        });
        if (token.isFromOutdatedConfig) {
          return;
        }
        const config = {
          fetchToken,
          onAuthChange: onChange,
          onRefreshChange
        };
        if (token.value) {
          this.setAuthState({
            state: "waitingForServerConfirmationOfCachedToken",
            config,
            hasRetried: false
          });
          this.authenticate(token.value);
        } else {
          this.setAuthState({
            state: "initialRefetch",
            config
          });
          await this.refetchToken();
        }
        this._logVerbose("resuming WS after auth token fetch");
        this.resumeSocket();
      }
      onTransition(serverMessage) {
        if (!this.syncState.isCurrentOrNewerAuthVersion(
          serverMessage.endVersion.identity
        )) {
          return;
        }
        if (serverMessage.endVersion.identity <= serverMessage.startVersion.identity) {
          return;
        }
        this._logVerbose(
          `auth state is ${this.authState.state} when handling transition`
        );
        this.syncState.markAuthCompletion();
        if (this.authState.state === "waitingForServerConfirmationOfCachedToken") {
          this._logVerbose("server confirmed auth token is valid");
          const cachedToken = this.syncState.getAuth()?.value;
          if (this.initialAuthTokenReuse && cachedToken) {
            this.scheduleTokenRefetch(cachedToken, serverMessage.clientClockSkew);
          } else {
            void this.refetchToken();
          }
          this.authState.config.onAuthChange(true);
          return;
        }
        if (this.authState.state === "waitingForServerConfirmationOfFreshToken") {
          this._logVerbose("server confirmed new auth token is valid");
          this.notifyRefreshChange(false);
          this.scheduleTokenRefetch(this.authState.token);
          this.tokenConfirmationAttempts = 0;
          if (!this.authState.hadAuth) {
            this.authState.config.onAuthChange(true);
          }
        }
      }
      onAuthError(serverMessage) {
        if (serverMessage.authUpdateAttempted === false && (this.authState.state === "waitingForServerConfirmationOfFreshToken" || this.authState.state === "waitingForServerConfirmationOfCachedToken")) {
          this._logVerbose("ignoring non-auth token expired error");
          return;
        }
        const { baseVersion } = serverMessage;
        if (!this.syncState.isCurrentOrNewerAuthVersion(baseVersion + 1)) {
          this._logVerbose("ignoring auth error for previous auth attempt");
          return;
        }
        void this.tryToReauthenticate(serverMessage);
        return;
      }
      // This is similar to `refetchToken` defined below, in fact we
      // don't represent them as different states, but it is different
      // in that we pause the WebSocket so that mutations
      // don't retry with bad auth.
      async tryToReauthenticate(serverMessage) {
        this._logVerbose(`attempting to reauthenticate: ${serverMessage.error}`);
        if (
          // No way to fetch another token, kaboom
          this.authState.state === "noAuth" || // We failed on a fresh token. After a small number of retries, we give up
          // and clear the auth state to avoid infinite retries.
          this.authState.state === "waitingForServerConfirmationOfFreshToken" && this.tokenConfirmationAttempts >= MAX_TOKEN_CONFIRMATION_ATTEMPTS
        ) {
          this.logger.error(
            `Failed to authenticate: "${serverMessage.error}", check your server auth config`
          );
          if (this.syncState.hasAuth()) {
            this.syncState.clearAuth();
          }
          if (this.authState.state !== "noAuth") {
            this.setAndReportAuthFailed(this.authState.config.onAuthChange);
          }
          return;
        }
        if (this.authState.state === "waitingForServerConfirmationOfFreshToken") {
          this.tokenConfirmationAttempts++;
          this._logVerbose(
            `retrying reauthentication, ${MAX_TOKEN_CONFIRMATION_ATTEMPTS - this.tokenConfirmationAttempts} attempts remaining`
          );
        }
        this.notifyRefreshChange(true);
        await this.stopSocket();
        if (this.authState.state === "noAuth") {
          return;
        }
        const token = await this.fetchTokenAndGuardAgainstRace(
          this.authState.config.fetchToken,
          {
            forceRefreshToken: true
          }
        );
        if (token.isFromOutdatedConfig) {
          return;
        }
        if (token.value && this.syncState.isNewAuth(token.value)) {
          this.authenticate(token.value);
          this.setAuthState({
            state: "waitingForServerConfirmationOfFreshToken",
            config: this.authState.config,
            token: token.value,
            hadAuth: this.authState.state === "notRefetching" || this.authState.state === "waitingForScheduledRefetch"
          });
        } else {
          this._logVerbose("reauthentication failed, could not fetch a new token");
          if (this.syncState.hasAuth()) {
            this.syncState.clearAuth();
          }
          this.setAndReportAuthFailed(this.authState.config.onAuthChange);
        }
        this.tryRestartSocket();
      }
      // Force refetch the token and schedule another refetch
      // before the token expires - an active client should never
      // need to reauthenticate.
      async refetchToken() {
        if (this.authState.state === "noAuth") {
          return;
        }
        this._logVerbose("refetching auth token");
        const token = await this.fetchTokenAndGuardAgainstRace(
          this.authState.config.fetchToken,
          {
            forceRefreshToken: true
          }
        );
        if (token.isFromOutdatedConfig) {
          return;
        }
        if (token.value) {
          if (this.syncState.isNewAuth(token.value)) {
            this.setAuthState({
              state: "waitingForServerConfirmationOfFreshToken",
              hadAuth: this.syncState.hasAuth(),
              token: token.value,
              config: this.authState.config
            });
            this.authenticate(token.value);
          } else {
            this.setAuthState({
              state: "notRefetching",
              config: this.authState.config
            });
          }
        } else {
          this._logVerbose("refetching token failed");
          if (this.syncState.hasAuth()) {
            this.clearAuth();
          }
          this.setAndReportAuthFailed(this.authState.config.onAuthChange);
        }
        this._logVerbose(
          "restarting WS after auth token fetch (if currently stopped)"
        );
        this.tryRestartSocket();
      }
      scheduleTokenRefetch(token, clientClockSkewMs) {
        if (this.authState.state === "noAuth") {
          return;
        }
        const decodedToken = this.decodeToken(token);
        if (!decodedToken) {
          this.logger.error(
            "Auth token is not a valid JWT, cannot refetch the token"
          );
          return;
        }
        const { iat, exp } = decodedToken;
        if (!iat || !exp) {
          this.logger.error(
            "Auth token does not have required fields, cannot refetch the token"
          );
          return;
        }
        const fullLifetimeSeconds = exp - iat;
        if (fullLifetimeSeconds <= 2) {
          this.logger.error(
            "Auth token does not live long enough, cannot refetch the token"
          );
          return;
        }
        let tokenValiditySeconds;
        if (clientClockSkewMs !== void 0) {
          const estimatedServerNowSeconds = (Date.now() - clientClockSkewMs) / 1e3;
          tokenValiditySeconds = exp - estimatedServerNowSeconds;
          if (tokenValiditySeconds <= 0) {
            tokenValiditySeconds = 0;
          }
        } else {
          tokenValiditySeconds = fullLifetimeSeconds;
        }
        let delay = Math.min(
          MAXIMUM_REFRESH_DELAY,
          (tokenValiditySeconds - this.refreshTokenLeewaySeconds) * 1e3
        );
        if (delay <= 0) {
          this.logger.warn(
            `Refetching auth token immediately, configured leeway ${this.refreshTokenLeewaySeconds}s is larger than the token's lifetime ${tokenValiditySeconds}s`
          );
          delay = 0;
        }
        const refetchTokenTimeoutId = setTimeout(() => {
          this._logVerbose("running scheduled token refetch");
          void this.refetchToken();
        }, delay);
        this.setAuthState({
          state: "waitingForScheduledRefetch",
          refetchTokenTimeoutId,
          config: this.authState.config
        });
        this._logVerbose(
          `scheduled preemptive auth token refetching in ${delay}ms`
        );
      }
      // Protects against simultaneous calls to `setConfig`
      // while we're fetching a token
      async fetchTokenAndGuardAgainstRace(fetchToken, fetchArgs) {
        const originalConfigVersion = ++this.configVersion;
        this._logVerbose(
          `fetching token with config version ${originalConfigVersion}`
        );
        const token = await fetchToken(fetchArgs);
        if (this.configVersion !== originalConfigVersion) {
          this._logVerbose(
            `stale config version, expected ${originalConfigVersion}, got ${this.configVersion}`
          );
          return { isFromOutdatedConfig: true };
        }
        return { isFromOutdatedConfig: false, value: token };
      }
      stop() {
        this.resetAuthState();
        this.configVersion++;
        this._logVerbose(`config version bumped to ${this.configVersion}`);
      }
      setAndReportAuthFailed(onAuthChange) {
        onAuthChange(false);
        this.resetAuthState();
      }
      // The sole path to `state === "noAuth"`; consumers rely on this firing
      // `notifyRefreshChange(false)` to pair any in-flight `(true)`. May run
      // when refresh state is already false.
      resetAuthState() {
        this.notifyRefreshChange(false);
        this.setAuthState({ state: "noAuth" });
      }
      setAuthState(newAuth) {
        const authStateForLog = newAuth.state === "waitingForServerConfirmationOfFreshToken" ? {
          hadAuth: newAuth.hadAuth,
          state: newAuth.state,
          token: `...${newAuth.token.slice(-7)}`
        } : { state: newAuth.state };
        this._logVerbose(
          `setting auth state to ${JSON.stringify(authStateForLog)}`
        );
        switch (newAuth.state) {
          case "waitingForScheduledRefetch":
          case "notRefetching":
          case "noAuth":
            this.tokenConfirmationAttempts = 0;
            break;
          case "waitingForServerConfirmationOfFreshToken":
          case "waitingForServerConfirmationOfCachedToken":
          case "initialRefetch":
            break;
          default: {
            newAuth;
          }
        }
        if (this.authState.state === "waitingForScheduledRefetch") {
          clearTimeout(this.authState.refetchTokenTimeoutId);
        }
        this.authState = newAuth;
      }
      decodeToken(token) {
        try {
          return jwtDecode(token);
        } catch (e) {
          this._logVerbose(
            `Error decoding token: ${e instanceof Error ? e.message : "Unknown error"}`
          );
          return null;
        }
      }
      _logVerbose(message) {
        this.logger.logVerbose(`${message} [v${this.configVersion}]`);
      }
    };
  }
});

// node_modules/convex/dist/esm/browser/sync/metrics.js
function mark(name, sessionId) {
  const detail = { sessionId };
  if (typeof performance === "undefined" || !performance.mark) return;
  performance.mark(name, { detail });
}
function performanceMarkToJson(mark2) {
  let name = mark2.name.slice("convex".length);
  name = name.charAt(0).toLowerCase() + name.slice(1);
  return {
    name,
    startTime: mark2.startTime
  };
}
function getMarksReport(sessionId) {
  if (typeof performance === "undefined" || !performance.getEntriesByName) {
    return [];
  }
  const allMarks = [];
  for (const name of markNames) {
    const marks = performance.getEntriesByName(name).filter((entry) => entry.entryType === "mark").filter((mark2) => mark2.detail.sessionId === sessionId);
    allMarks.push(...marks);
  }
  return allMarks.map(performanceMarkToJson);
}
var markNames;
var init_metrics = __esm({
  "node_modules/convex/dist/esm/browser/sync/metrics.js"() {
    "use strict";
    markNames = [
      "convexClientConstructed",
      "convexWebSocketOpen",
      "convexFirstMessageReceived"
    ];
  }
});

// node_modules/convex/dist/esm/browser/sync/client.js
var __defProp12, __defNormalProp11, __publicField11, BaseConvexClient;
var init_client = __esm({
  "node_modules/convex/dist/esm/browser/sync/client.js"() {
    "use strict";
    init_esm();
    init_values();
    init_logging();
    init_local_state();
    init_request_manager();
    init_optimistic_updates_impl();
    init_remote_query_set();
    init_udf_path_utils();
    init_web_socket_manager();
    init_session();
    init_authentication_manager();
    init_metrics();
    init_common();
    init_errors();
    init_jwt_decode();
    __defProp12 = Object.defineProperty;
    __defNormalProp11 = (obj, key, value) => key in obj ? __defProp12(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
    __publicField11 = (obj, key, value) => __defNormalProp11(obj, typeof key !== "symbol" ? key + "" : key, value);
    BaseConvexClient = class {
      /**
       * @param address - The url of your Convex deployment, often provided
       * by an environment variable. E.g. `https://small-mouse-123.convex.cloud`.
       * @param onTransition - A callback receiving an array of query tokens
       * corresponding to query results that have changed -- additional handlers
       * can be added via `addOnTransitionHandler`.
       * @param options - See {@link BaseConvexClientOptions} for a full description.
       */
      constructor(address, onTransition, options) {
        __publicField11(this, "address");
        __publicField11(this, "state");
        __publicField11(this, "requestManager");
        __publicField11(this, "webSocketManager");
        __publicField11(this, "authenticationManager");
        __publicField11(this, "remoteQuerySet");
        __publicField11(this, "optimisticQueryResults");
        __publicField11(this, "_transitionHandlerCounter", 0);
        __publicField11(this, "_nextRequestId");
        __publicField11(this, "_onTransitionFns", /* @__PURE__ */ new Map());
        __publicField11(this, "_sessionId");
        __publicField11(this, "firstMessageReceived", false);
        __publicField11(this, "debug");
        __publicField11(this, "logger");
        __publicField11(this, "maxObservedTimestamp");
        __publicField11(this, "connectionStateSubscribers", /* @__PURE__ */ new Map());
        __publicField11(this, "nextConnectionStateSubscriberId", 0);
        __publicField11(this, "_lastPublishedConnectionState");
        __publicField11(this, "markConnectionStateDirty", () => {
          void Promise.resolve().then(() => {
            const curConnectionState = this.connectionState();
            if (JSON.stringify(curConnectionState) !== JSON.stringify(this._lastPublishedConnectionState)) {
              this._lastPublishedConnectionState = curConnectionState;
              for (const cb of this.connectionStateSubscribers.values()) {
                cb(curConnectionState);
              }
            }
          });
        });
        __publicField11(this, "mark", (name) => {
          if (this.debug) {
            mark(name, this.sessionId);
          }
        });
        if (typeof address === "object") {
          throw new Error(
            "Passing a ClientConfig object is no longer supported. Pass the URL of the Convex deployment as a string directly."
          );
        }
        if (options?.skipConvexDeploymentUrlCheck !== true) {
          validateDeploymentUrl(address);
        }
        options = { ...options };
        const authRefreshTokenLeewaySeconds = options.authRefreshTokenLeewaySeconds ?? 10;
        let webSocketConstructor = options.webSocketConstructor;
        if (!webSocketConstructor && typeof WebSocket === "undefined") {
          throw new Error(
            "No WebSocket global variable defined! To use Convex in an environment without WebSocket try the HTTP client: https://docs.convex.dev/api/classes/browser.ConvexHttpClient"
          );
        }
        webSocketConstructor = webSocketConstructor || WebSocket;
        this.debug = options.reportDebugInfoToConvex ?? false;
        this.address = address;
        this.logger = options.logger === false ? instantiateNoopLogger({ verbose: options.verbose ?? false }) : options.logger !== true && options.logger ? options.logger : instantiateDefaultLogger({ verbose: options.verbose ?? false });
        const i = address.search("://");
        if (i === -1) {
          throw new Error("Provided address was not an absolute URL.");
        }
        const origin = address.substring(i + 3);
        const protocol = address.substring(0, i);
        let wsProtocol;
        if (protocol === "http") {
          wsProtocol = "ws";
        } else if (protocol === "https") {
          wsProtocol = "wss";
        } else {
          throw new Error(`Unknown parent protocol ${protocol}`);
        }
        const wsUri = `${wsProtocol}://${origin}/api/${version}/sync`;
        this.state = new LocalSyncState();
        this.remoteQuerySet = new RemoteQuerySet(
          (queryId) => this.state.queryPath(queryId),
          this.logger
        );
        this.requestManager = new RequestManager(
          this.logger,
          this.markConnectionStateDirty
        );
        const pauseSocket = () => {
          this.webSocketManager.pause();
          this.state.pause();
        };
        this.authenticationManager = new AuthenticationManager(
          this.state,
          {
            authenticate: (token) => {
              const message = this.state.setAuth(token);
              this.webSocketManager.sendMessage(message);
              return message.baseVersion;
            },
            stopSocket: () => this.webSocketManager.stop(),
            tryRestartSocket: () => this.webSocketManager.tryRestart(),
            pauseSocket,
            resumeSocket: () => this.webSocketManager.resume(),
            clearAuth: () => {
              this.clearAuth();
            }
          },
          {
            logger: this.logger,
            refreshTokenLeewaySeconds: authRefreshTokenLeewaySeconds,
            initialAuthTokenReuse: options.initialAuthTokenReuse ?? false
          }
        );
        this.optimisticQueryResults = new OptimisticQueryResults();
        this.addOnTransitionHandler((transition) => {
          onTransition(transition.queries.map((q) => q.token));
        });
        this._nextRequestId = 0;
        this._sessionId = newSessionId();
        const { unsavedChangesWarning } = options;
        if (typeof window === "undefined" || typeof window.addEventListener === "undefined") {
          if (unsavedChangesWarning === true) {
            throw new Error(
              "unsavedChangesWarning requested, but window.addEventListener not found! Remove {unsavedChangesWarning: true} from Convex client options."
            );
          }
        } else if (unsavedChangesWarning !== false) {
          window.addEventListener("beforeunload", (e) => {
            if (this.requestManager.hasIncompleteRequests()) {
              e.preventDefault();
              const confirmationMessage = "Are you sure you want to leave? Your changes may not be saved.";
              (e || window.event).returnValue = confirmationMessage;
              return confirmationMessage;
            }
          });
        }
        this.webSocketManager = new WebSocketManager(
          wsUri,
          {
            onOpen: (reconnectMetadata) => {
              this.mark("convexWebSocketOpen");
              this.webSocketManager.sendMessage({
                ...reconnectMetadata,
                type: "Connect",
                sessionId: this._sessionId,
                maxObservedTimestamp: this.maxObservedTimestamp
              });
              this.remoteQuerySet = new RemoteQuerySet(
                (queryId) => this.state.queryPath(queryId),
                this.logger
              );
              const [querySetModification, authModification] = this.state.restart();
              if (authModification) {
                this.webSocketManager.sendMessage(authModification);
              }
              this.webSocketManager.sendMessage(querySetModification);
              for (const message of this.requestManager.restart()) {
                this.webSocketManager.sendMessage(message);
              }
            },
            onResume: () => {
              const [querySetModification, authModification] = this.state.resume();
              if (authModification) {
                this.webSocketManager.sendMessage(authModification);
              }
              if (querySetModification) {
                this.webSocketManager.sendMessage(querySetModification);
              }
              for (const message of this.requestManager.resume()) {
                this.webSocketManager.sendMessage(message);
              }
            },
            onMessage: (serverMessage) => {
              if (!this.firstMessageReceived) {
                this.firstMessageReceived = true;
                this.mark("convexFirstMessageReceived");
                this.reportMarks();
              }
              switch (serverMessage.type) {
                case "Transition": {
                  this.observedTimestamp(serverMessage.endVersion.ts);
                  this.authenticationManager.onTransition(serverMessage);
                  this.remoteQuerySet.transition(serverMessage);
                  this.state.transition(serverMessage);
                  const completedRequests = this.requestManager.removeCompleted(
                    this.remoteQuerySet.timestamp()
                  );
                  this.notifyOnQueryResultChanges(completedRequests);
                  break;
                }
                case "MutationResponse": {
                  if (serverMessage.success) {
                    this.observedTimestamp(serverMessage.ts);
                  }
                  const completedMutationInfo = this.requestManager.onResponse(serverMessage);
                  if (completedMutationInfo !== null) {
                    this.notifyOnQueryResultChanges(
                      /* @__PURE__ */ new Map([
                        [
                          completedMutationInfo.requestId,
                          completedMutationInfo.result
                        ]
                      ])
                    );
                  }
                  break;
                }
                case "ActionResponse": {
                  this.requestManager.onResponse(serverMessage);
                  break;
                }
                case "AuthError": {
                  this.authenticationManager.onAuthError(serverMessage);
                  break;
                }
                case "FatalError": {
                  const error = logFatalError(this.logger, serverMessage.error);
                  void this.webSocketManager.terminate();
                  throw error;
                }
                default: {
                  serverMessage;
                }
              }
              return {
                hasSyncedPastLastReconnect: this.hasSyncedPastLastReconnect()
              };
            },
            onServerDisconnectError: options.onServerDisconnectError
          },
          webSocketConstructor,
          this.logger,
          this.markConnectionStateDirty,
          this.debug
        );
        this.mark("convexClientConstructed");
        if (options.expectAuth) {
          pauseSocket();
        }
      }
      /**
       * Return true if there is outstanding work from prior to the time of the most recent restart.
       * This indicates that the client has not proven itself to have gotten past the issue that
       * potentially led to the restart. Use this to influence when to reset backoff after a failure.
       */
      hasSyncedPastLastReconnect() {
        const hasSyncedPastLastReconnect = this.requestManager.hasSyncedPastLastReconnect() && this.state.hasSyncedPastLastReconnect();
        return hasSyncedPastLastReconnect;
      }
      observedTimestamp(observedTs) {
        if (this.maxObservedTimestamp === void 0 || this.maxObservedTimestamp.lessThanOrEqual(observedTs)) {
          this.maxObservedTimestamp = observedTs;
        }
      }
      getMaxObservedTimestamp() {
        return this.maxObservedTimestamp;
      }
      /**
       * Compute the current query results based on the remoteQuerySet and the
       * current optimistic updates and call `onTransition` for all the changed
       * queries.
       *
       * @param completedMutations - A set of mutation IDs whose optimistic updates
       * are no longer needed.
       */
      notifyOnQueryResultChanges(completedRequests) {
        const remoteQueryResults = this.remoteQuerySet.remoteQueryResults();
        const queryTokenToValue = /* @__PURE__ */ new Map();
        for (const [queryId, result] of remoteQueryResults) {
          const queryToken = this.state.queryToken(queryId);
          if (queryToken !== null) {
            const query = {
              result,
              udfPath: this.state.queryPath(queryId),
              args: this.state.queryArgs(queryId)
            };
            queryTokenToValue.set(queryToken, query);
          }
        }
        const changedQueryTokens = this.optimisticQueryResults.ingestQueryResultsFromServer(
          queryTokenToValue,
          new Set(completedRequests.keys())
        );
        this.handleTransition({
          queries: changedQueryTokens.map((token) => {
            const optimisticResult = this.optimisticQueryResults.rawQueryResult(token);
            return {
              token,
              modification: {
                kind: "Updated",
                result: optimisticResult
              }
            };
          }),
          reflectedMutations: Array.from(completedRequests).map(
            ([requestId, result]) => ({
              requestId,
              result
            })
          ),
          timestamp: this.remoteQuerySet.timestamp()
        });
      }
      handleTransition(transition) {
        for (const fn of this._onTransitionFns.values()) {
          fn(transition);
        }
      }
      /**
       * Add a handler that will be called on a transition.
       *
       * Any external side effects (e.g. setting React state) should be handled here.
       *
       * @param fn
       *
       * @returns
       */
      addOnTransitionHandler(fn) {
        const id = this._transitionHandlerCounter++;
        this._onTransitionFns.set(id, fn);
        return () => this._onTransitionFns.delete(id);
      }
      /**
       * Get the current JWT auth token and decoded claims.
       */
      getCurrentAuthClaims() {
        const authToken = this.state.getAuth();
        let decoded = {};
        if (authToken && authToken.tokenType === "User") {
          try {
            decoded = authToken ? jwtDecode(authToken.value) : {};
          } catch {
            decoded = {};
          }
        } else {
          return void 0;
        }
        return { token: authToken.value, decoded };
      }
      /**
       * Set the authentication token to be used for subsequent queries and mutations.
       * `fetchToken` will be called automatically again if a token expires.
       * `fetchToken` should return `null` if the token cannot be retrieved, for example
       * when the user's rights were permanently revoked.
       * @param fetchToken - an async function returning the JWT-encoded OpenID Connect Identity Token
       * @param onChange - a callback that will be called when the authentication status changes
       * @param onRefreshChange - a callback called with `true` when the socket is paused to fetch a replacement token after a server rejection, and `false` when refresh completes
       */
      setAuth(fetchToken, onChange, onRefreshChange) {
        void this.authenticationManager.setConfig(
          fetchToken,
          onChange,
          onRefreshChange
        );
      }
      hasAuth() {
        return this.state.hasAuth();
      }
      /** @internal */
      setAdminAuth(value, fakeUserIdentity) {
        const message = this.state.setAdminAuth(value, fakeUserIdentity);
        this.webSocketManager.sendMessage(message);
      }
      clearAuth() {
        const message = this.state.clearAuth();
        this.webSocketManager.sendMessage(message);
      }
      /**
         * Subscribe to a query function.
         *
         * Whenever this query's result changes, the `onTransition` callback
         * passed into the constructor will be called.
         *
         * @param name - The name of the query.
         * @param args - An arguments object for the query. If this is omitted, the
         * arguments will be `{}`.
         * @param options - A {@link SubscribeOptions} options object for this query.
      
         * @returns An object containing a {@link QueryToken} corresponding to this
         * query and an `unsubscribe` callback.
         */
      subscribe(name, args, options) {
        const argsObject = parseArgs(args);
        const { modification, queryToken, unsubscribe } = this.state.subscribe(
          name,
          argsObject,
          options?.journal,
          options?.componentPath
        );
        if (modification !== null) {
          this.webSocketManager.sendMessage(modification);
        }
        return {
          queryToken,
          unsubscribe: () => {
            const modification2 = unsubscribe();
            if (modification2) {
              this.webSocketManager.sendMessage(modification2);
            }
          }
        };
      }
      /**
       * A query result based only on the current, local state.
       *
       * The only way this will return a value is if we're already subscribed to the
       * query or its value has been set optimistically.
       */
      localQueryResult(udfPath, args) {
        const argsObject = parseArgs(args);
        const queryToken = serializePathAndArgs(udfPath, argsObject);
        return this.optimisticQueryResults.queryResult(queryToken);
      }
      /**
       * Get query result by query token based on current, local state
       *
       * The only way this will return a value is if we're already subscribed to the
       * query or its value has been set optimistically.
       *
       * @internal
       */
      localQueryResultByToken(queryToken) {
        return this.optimisticQueryResults.queryResult(queryToken);
      }
      /**
       * Whether local query result is available for a token.
       *
       * This method does not throw if the result is an error.
       *
       * @internal
       */
      hasLocalQueryResultByToken(queryToken) {
        return this.optimisticQueryResults.hasQueryResult(queryToken);
      }
      /**
       * @internal
       */
      localQueryLogs(udfPath, args) {
        const argsObject = parseArgs(args);
        const queryToken = serializePathAndArgs(udfPath, argsObject);
        return this.optimisticQueryResults.queryLogs(queryToken);
      }
      /**
       * Retrieve the current {@link QueryJournal} for this query function.
       *
       * If we have not yet received a result for this query, this will be `undefined`.
       *
       * @param name - The name of the query.
       * @param args - The arguments object for this query.
       * @returns The query's {@link QueryJournal} or `undefined`.
       */
      queryJournal(name, args) {
        const argsObject = parseArgs(args);
        const queryToken = serializePathAndArgs(name, argsObject);
        return this.state.queryJournal(queryToken);
      }
      /**
       * Get the current {@link ConnectionState} between the client and the Convex
       * backend.
       *
       * @returns The {@link ConnectionState} with the Convex backend.
       */
      connectionState() {
        const wsConnectionState = this.webSocketManager.connectionState();
        return {
          hasInflightRequests: this.requestManager.hasInflightRequests(),
          isWebSocketConnected: wsConnectionState.isConnected,
          hasEverConnected: wsConnectionState.hasEverConnected,
          connectionCount: wsConnectionState.connectionCount,
          connectionRetries: wsConnectionState.connectionRetries,
          timeOfOldestInflightRequest: this.requestManager.timeOfOldestInflightRequest(),
          inflightMutations: this.requestManager.inflightMutations(),
          inflightActions: this.requestManager.inflightActions()
        };
      }
      /**
       * Subscribe to the {@link ConnectionState} between the client and the Convex
       * backend, calling a callback each time it changes.
       *
       * Subscribed callbacks will be called when any part of ConnectionState changes.
       * ConnectionState may grow in future versions (e.g. to provide a array of
       * inflight requests) in which case callbacks would be called more frequently.
       *
       * @returns An unsubscribe function to stop listening.
       */
      subscribeToConnectionState(cb) {
        const id = this.nextConnectionStateSubscriberId++;
        this.connectionStateSubscribers.set(id, cb);
        return () => {
          this.connectionStateSubscribers.delete(id);
        };
      }
      /**
         * Execute a mutation function.
         *
         * @param name - The name of the mutation.
         * @param args - An arguments object for the mutation. If this is omitted,
         * the arguments will be `{}`.
         * @param options - A {@link MutationOptions} options object for this mutation.
      
         * @returns - A promise of the mutation's result.
         */
      async mutation(name, args, options) {
        const result = await this.mutationInternal(name, args, options);
        if (!result.success) {
          if (result.errorData !== void 0) {
            throw forwardData(
              result,
              new ConvexError(
                createHybridErrorStacktrace("mutation", name, result)
              )
            );
          }
          throw new Error(createHybridErrorStacktrace("mutation", name, result));
        }
        return result.value;
      }
      /**
       * @internal
       */
      async mutationInternal(udfPath, args, options, componentPath) {
        const { mutationPromise } = this.enqueueMutation(
          udfPath,
          args,
          options,
          componentPath
        );
        return mutationPromise;
      }
      /**
       * @internal
       */
      enqueueMutation(udfPath, args, options, componentPath) {
        const mutationArgs = parseArgs(args);
        this.tryReportLongDisconnect();
        const requestId = this.nextRequestId;
        this._nextRequestId++;
        if (options !== void 0) {
          const optimisticUpdate = options.optimisticUpdate;
          if (optimisticUpdate !== void 0) {
            const wrappedUpdate = (localQueryStore) => {
              const result = optimisticUpdate(
                localQueryStore,
                mutationArgs
              );
              if (result instanceof Promise) {
                this.logger.warn(
                  "Optimistic update handler returned a Promise. Optimistic updates should be synchronous."
                );
              }
            };
            const changedQueryTokens = this.optimisticQueryResults.applyOptimisticUpdate(
              wrappedUpdate,
              requestId
            );
            const changedQueries = changedQueryTokens.map((token) => {
              const localResult = this.localQueryResultByToken(token);
              return {
                token,
                modification: {
                  kind: "Updated",
                  result: localResult === void 0 ? void 0 : {
                    success: true,
                    value: localResult,
                    logLines: []
                  }
                }
              };
            });
            this.handleTransition({
              queries: changedQueries,
              reflectedMutations: [],
              timestamp: this.remoteQuerySet.timestamp()
            });
          }
        }
        const message = {
          type: "Mutation",
          requestId,
          udfPath,
          componentPath,
          args: [convexToJson(mutationArgs)]
        };
        const mightBeSent = this.webSocketManager.sendMessage(message);
        const mutationPromise = this.requestManager.request(message, mightBeSent);
        return {
          requestId,
          mutationPromise
        };
      }
      /**
       * Execute an action function.
       *
       * @param name - The name of the action.
       * @param args - An arguments object for the action. If this is omitted,
       * the arguments will be `{}`.
       * @returns A promise of the action's result.
       */
      async action(name, args) {
        const result = await this.actionInternal(name, args);
        if (!result.success) {
          if (result.errorData !== void 0) {
            throw forwardData(
              result,
              new ConvexError(createHybridErrorStacktrace("action", name, result))
            );
          }
          throw new Error(createHybridErrorStacktrace("action", name, result));
        }
        return result.value;
      }
      /**
       * @internal
       */
      async actionInternal(udfPath, args, componentPath) {
        const actionArgs = parseArgs(args);
        const requestId = this.nextRequestId;
        this._nextRequestId++;
        this.tryReportLongDisconnect();
        const message = {
          type: "Action",
          requestId,
          udfPath,
          componentPath,
          args: [convexToJson(actionArgs)]
        };
        const mightBeSent = this.webSocketManager.sendMessage(message);
        return this.requestManager.request(message, mightBeSent);
      }
      /**
       * Close any network handles associated with this client and stop all subscriptions.
       *
       * Call this method when you're done with an {@link BaseConvexClient} to
       * dispose of its sockets and resources.
       *
       * @returns A `Promise` fulfilled when the connection has been completely closed.
       */
      async close() {
        this.authenticationManager.stop();
        return this.webSocketManager.terminate();
      }
      /**
       * Return the address for this client, useful for creating a new client.
       *
       * Not guaranteed to match the address with which this client was constructed:
       * it may be canonicalized.
       */
      get url() {
        return this.address;
      }
      /**
       * @internal
       */
      get nextRequestId() {
        return this._nextRequestId;
      }
      /**
       * @internal
       */
      get sessionId() {
        return this._sessionId;
      }
      /**
       * Reports performance marks to the server. This should only be called when
       * we have a functional websocket.
       */
      reportMarks() {
        if (this.debug) {
          const report = getMarksReport(this.sessionId);
          this.webSocketManager.sendMessage({
            type: "Event",
            eventType: "ClientConnect",
            event: report
          });
        }
      }
      tryReportLongDisconnect() {
        if (!this.debug) {
          return;
        }
        const timeOfOldestRequest = this.connectionState().timeOfOldestInflightRequest;
        if (timeOfOldestRequest === null || Date.now() - timeOfOldestRequest.getTime() <= 60 * 1e3) {
          return;
        }
        const endpoint = `${this.address}/api/debug_event`;
        fetch(endpoint, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Convex-Client": `npm-${version}`
          },
          body: JSON.stringify({ event: "LongWebsocketDisconnect" })
        }).then((response) => {
          if (!response.ok) {
            this.logger.warn(
              "Analytics request failed with response:",
              response.body
            );
          }
        }).catch((error) => {
          this.logger.warn("Analytics response failed with error:", error);
        });
      }
    };
  }
});

// node_modules/convex/dist/esm/browser/sync/pagination.js
function asPaginationResult(value) {
  if (typeof value !== "object" || value === null || !Array.isArray(value.page) || typeof value.isDone !== "boolean" || typeof value.continueCursor !== "string") {
    throw new Error(`Not a valid paginated query result: ${value?.toString()}`);
  }
  return value;
}
var init_pagination = __esm({
  "node_modules/convex/dist/esm/browser/sync/pagination.js"() {
    "use strict";
  }
});

// node_modules/convex/dist/esm/browser/sync/paginated_query_client.js
var __defProp13, __defNormalProp12, __publicField12, PaginatedQueryClient;
var init_paginated_query_client = __esm({
  "node_modules/convex/dist/esm/browser/sync/paginated_query_client.js"() {
    "use strict";
    init_udf_path_utils();
    init_pagination();
    init_long();
    __defProp13 = Object.defineProperty;
    __defNormalProp12 = (obj, key, value) => key in obj ? __defProp13(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
    __publicField12 = (obj, key, value) => __defNormalProp12(obj, typeof key !== "symbol" ? key + "" : key, value);
    PaginatedQueryClient = class {
      constructor(client, onTransition) {
        this.client = client;
        this.onTransition = onTransition;
        __publicField12(this, "paginatedQuerySet", /* @__PURE__ */ new Map());
        __publicField12(this, "lastTransitionTs");
        this.lastTransitionTs = Long.fromNumber(0);
        this.client.addOnTransitionHandler(
          (transition) => this.onBaseTransition(transition)
        );
      }
      /**
       * Subscribe to a paginated query.
       *
       * @param name - The name of the paginated query function
       * @param args - Arguments for the query (excluding paginationOpts)
       * @param options - Pagination options including initialNumItems
       * @returns Object with paginatedQueryToken and unsubscribe function
       */
      subscribe(name, args, options) {
        const canonicalizedUdfPath = canonicalizeUdfPath(name);
        const token = serializePaginatedPathAndArgs(
          canonicalizedUdfPath,
          args,
          options
        );
        const unsubscribe = () => this.removePaginatedQuerySubscriber(token);
        const existingEntry = this.paginatedQuerySet.get(token);
        if (existingEntry) {
          existingEntry.numSubscribers += 1;
          return {
            paginatedQueryToken: token,
            unsubscribe
          };
        }
        this.paginatedQuerySet.set(token, {
          token,
          canonicalizedUdfPath,
          args,
          numSubscribers: 1,
          options: { initialNumItems: options.initialNumItems },
          nextPageKey: 0,
          pageKeys: [],
          pageKeyToQuery: /* @__PURE__ */ new Map(),
          ongoingSplits: /* @__PURE__ */ new Map(),
          skip: false,
          id: options.id
        });
        this.addPageToPaginatedQuery(token, null, options.initialNumItems);
        return {
          paginatedQueryToken: token,
          unsubscribe
        };
      }
      /**
       * Get current results for a paginated query based on local state.
       *
       * Throws an error when one of the pages has errored.
       */
      localQueryResult(name, args, options) {
        const canonicalizedUdfPath = canonicalizeUdfPath(name);
        const token = serializePaginatedPathAndArgs(
          canonicalizedUdfPath,
          args,
          options
        );
        return this.localQueryResultByToken(token);
      }
      /**
       * @internal
       */
      localQueryResultByToken(token) {
        const paginatedQuery = this.paginatedQuerySet.get(token);
        if (!paginatedQuery) {
          return void 0;
        }
        const activePages = this.activePageQueryTokens(paginatedQuery);
        if (activePages.length === 0) {
          return {
            results: [],
            status: "LoadingFirstPage",
            loadMore: (numItems) => {
              return this.loadMoreOfPaginatedQuery(token, numItems);
            }
          };
        }
        let allResults = [];
        let hasUndefined = false;
        let isDone = false;
        for (const pageToken of activePages) {
          const result = this.client.localQueryResultByToken(pageToken);
          if (result === void 0) {
            hasUndefined = true;
            isDone = false;
            continue;
          }
          const paginationResult = asPaginationResult(result);
          allResults = allResults.concat(paginationResult.page);
          isDone = !!paginationResult.isDone;
        }
        let status;
        if (hasUndefined) {
          status = allResults.length === 0 ? "LoadingFirstPage" : "LoadingMore";
        } else if (isDone) {
          status = "Exhausted";
        } else {
          status = "CanLoadMore";
        }
        return {
          results: allResults,
          status,
          loadMore: (numItems) => {
            return this.loadMoreOfPaginatedQuery(token, numItems);
          }
        };
      }
      onBaseTransition(transition) {
        const changedBaseTokens = transition.queries.map((q) => q.token);
        const changed = this.queriesContainingTokens(changedBaseTokens);
        let paginatedQueries = [];
        if (changed.length > 0) {
          this.processPaginatedQuerySplits(
            changed,
            (token) => this.client.localQueryResultByToken(token)
          );
          paginatedQueries = changed.map((token) => ({
            token,
            modification: {
              kind: "Updated",
              result: this.localQueryResultByToken(token)
            }
          }));
        }
        const extendedTransition = {
          ...transition,
          paginatedQueries
        };
        this.onTransition(extendedTransition);
      }
      /**
       * Load more items for a paginated query.
       *
       * This *always* causes a transition, the status of the query
       * has probably changed from "CanLoadMore" to "LoadingMore".
       * Data might have changed too: maybe a subscription to this page
       * query already exists (unlikely but possible) or this page query
       * has an optimistic update providing some initial data.
       *
       * @internal
       */
      loadMoreOfPaginatedQuery(token, numItems) {
        this.mustGetPaginatedQuery(token);
        const lastPageToken = this.queryTokenForLastPageOfPaginatedQuery(token);
        const lastPageResult = this.client.localQueryResultByToken(lastPageToken);
        if (!lastPageResult) {
          return false;
        }
        const paginationResult = asPaginationResult(lastPageResult);
        if (paginationResult.isDone) {
          return false;
        }
        this.addPageToPaginatedQuery(
          token,
          paginationResult.continueCursor,
          numItems
        );
        const loadMoreTransition = {
          timestamp: this.lastTransitionTs,
          reflectedMutations: [],
          queries: [],
          paginatedQueries: [
            {
              token,
              modification: {
                kind: "Updated",
                result: this.localQueryResultByToken(token)
              }
            }
          ]
        };
        this.onTransition(loadMoreTransition);
        return true;
      }
      /**
       * @internal
       */
      queriesContainingTokens(queryTokens) {
        if (queryTokens.length === 0) {
          return [];
        }
        const changed = [];
        const queryTokenSet = new Set(queryTokens);
        for (const [paginatedToken, paginatedQuery] of this.paginatedQuerySet) {
          for (const pageToken of this.allQueryTokens(paginatedQuery)) {
            if (queryTokenSet.has(pageToken)) {
              changed.push(paginatedToken);
              break;
            }
          }
        }
        return changed;
      }
      /**
       * @internal
       */
      processPaginatedQuerySplits(changed, getResult) {
        for (const paginatedQueryToken of changed) {
          const paginatedQuery = this.mustGetPaginatedQuery(paginatedQueryToken);
          const { ongoingSplits, pageKeyToQuery, pageKeys } = paginatedQuery;
          for (const [pageKey, [splitKey1, splitKey2]] of ongoingSplits) {
            const bothNewPagesLoaded = getResult(pageKeyToQuery.get(splitKey1).queryToken) !== void 0 && getResult(pageKeyToQuery.get(splitKey2).queryToken) !== void 0;
            if (bothNewPagesLoaded) {
              this.completePaginatedQuerySplit(
                paginatedQuery,
                pageKey,
                splitKey1,
                splitKey2
              );
            }
          }
          for (const pageKey of pageKeys) {
            if (ongoingSplits.has(pageKey)) {
              continue;
            }
            const pageEntry = pageKeyToQuery.get(pageKey);
            if (!pageEntry) {
              throw new Error(`No page query for active pageKey ${pageKey}`);
            }
            const pageResult = getResult(pageEntry.queryToken);
            if (!pageResult) {
              continue;
            }
            const result = asPaginationResult(pageResult);
            const shouldSplit = result.splitCursor && (result.pageStatus === "SplitRecommended" || result.pageStatus === "SplitRequired" || // This client-driven page splitting condition will change in the future.
            result.page.length > paginatedQuery.options.initialNumItems * 2);
            if (shouldSplit) {
              this.splitPaginatedQueryPage(
                paginatedQuery,
                pageKey,
                pageEntry.cursor,
                result.splitCursor,
                // we just checked
                result.continueCursor
              );
            }
          }
        }
      }
      splitPaginatedQueryPage(paginatedQuery, pageKey, startCursor, splitCursor, continueCursor) {
        const splitKey1 = paginatedQuery.nextPageKey++;
        const splitKey2 = paginatedQuery.nextPageKey++;
        const paginationOpts = {
          numItems: paginatedQuery.options.initialNumItems,
          id: paginatedQuery.id
        };
        const firstSubscription = this.client.subscribe(
          paginatedQuery.canonicalizedUdfPath,
          {
            ...paginatedQuery.args,
            paginationOpts: {
              ...paginationOpts,
              cursor: startCursor,
              endCursor: splitCursor
            }
          }
        );
        paginatedQuery.pageKeyToQuery.set(splitKey1, {
          ...firstSubscription,
          cursor: startCursor
        });
        const secondSubscription = this.client.subscribe(
          paginatedQuery.canonicalizedUdfPath,
          {
            ...paginatedQuery.args,
            paginationOpts: {
              ...paginationOpts,
              cursor: splitCursor,
              endCursor: continueCursor
            }
          }
        );
        paginatedQuery.pageKeyToQuery.set(splitKey2, {
          ...secondSubscription,
          cursor: splitCursor
        });
        paginatedQuery.ongoingSplits.set(pageKey, [splitKey1, splitKey2]);
      }
      /**
       * @internal
       */
      addPageToPaginatedQuery(token, continueCursor, numItems) {
        const paginatedQuery = this.mustGetPaginatedQuery(token);
        const pageKey = paginatedQuery.nextPageKey++;
        const paginationOpts = {
          cursor: continueCursor,
          numItems,
          id: paginatedQuery.id
        };
        const pageArgs = {
          ...paginatedQuery.args,
          paginationOpts
        };
        const subscription = this.client.subscribe(
          paginatedQuery.canonicalizedUdfPath,
          pageArgs
        );
        paginatedQuery.pageKeys.push(pageKey);
        paginatedQuery.pageKeyToQuery.set(pageKey, {
          ...subscription,
          cursor: continueCursor
        });
        return subscription;
      }
      removePaginatedQuerySubscriber(token) {
        const paginatedQuery = this.paginatedQuerySet.get(token);
        if (!paginatedQuery) {
          return;
        }
        paginatedQuery.numSubscribers -= 1;
        if (paginatedQuery.numSubscribers > 0) {
          return;
        }
        for (const subscription of paginatedQuery.pageKeyToQuery.values()) {
          subscription.unsubscribe();
        }
        this.paginatedQuerySet.delete(token);
      }
      completePaginatedQuerySplit(paginatedQuery, pageKey, splitKey1, splitKey2) {
        const originalQuery = paginatedQuery.pageKeyToQuery.get(pageKey);
        paginatedQuery.pageKeyToQuery.delete(pageKey);
        const pageIndex = paginatedQuery.pageKeys.indexOf(pageKey);
        paginatedQuery.pageKeys.splice(pageIndex, 1, splitKey1, splitKey2);
        paginatedQuery.ongoingSplits.delete(pageKey);
        originalQuery.unsubscribe();
      }
      /** The query tokens for all active pages, in result order */
      activePageQueryTokens(paginatedQuery) {
        return paginatedQuery.pageKeys.map(
          (pageKey) => paginatedQuery.pageKeyToQuery.get(pageKey).queryToken
        );
      }
      allQueryTokens(paginatedQuery) {
        return Array.from(paginatedQuery.pageKeyToQuery.values()).map(
          (sub) => sub.queryToken
        );
      }
      queryTokenForLastPageOfPaginatedQuery(token) {
        const paginatedQuery = this.mustGetPaginatedQuery(token);
        const lastPageKey = paginatedQuery.pageKeys[paginatedQuery.pageKeys.length - 1];
        if (lastPageKey === void 0) {
          throw new Error(`No pages for paginated query ${token}`);
        }
        return paginatedQuery.pageKeyToQuery.get(lastPageKey).queryToken;
      }
      mustGetPaginatedQuery(token) {
        const paginatedQuery = this.paginatedQuerySet.get(token);
        if (!paginatedQuery) {
          throw new Error("paginated query no longer exists for token " + token);
        }
        return paginatedQuery;
      }
    };
  }
});

// node_modules/convex/dist/esm/browser/simple_client.js
function setDefaultWebSocketConstructor(ws) {
  defaultWebSocketConstructor = ws;
}
var __defProp14, __defNormalProp13, __publicField13, defaultWebSocketConstructor, ConvexClient;
var init_simple_client = __esm({
  "node_modules/convex/dist/esm/browser/simple_client.js"() {
    "use strict";
    init_common();
    init_api();
    init_client();
    init_paginated_query_client();
    init_udf_path_utils();
    __defProp14 = Object.defineProperty;
    __defNormalProp13 = (obj, key, value) => key in obj ? __defProp14(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
    __publicField13 = (obj, key, value) => __defNormalProp13(obj, typeof key !== "symbol" ? key + "" : key, value);
    ConvexClient = class {
      /**
       * Construct a client and immediately initiate a WebSocket connection to the passed address.
       *
       * @public
       */
      constructor(address, options = {}) {
        __publicField13(this, "listeners");
        __publicField13(this, "_client");
        __publicField13(this, "_paginatedClient");
        __publicField13(this, "callNewListenersWithCurrentValuesTimer");
        __publicField13(this, "_closed");
        __publicField13(this, "_disabled");
        if (options.skipConvexDeploymentUrlCheck !== true) {
          validateDeploymentUrl(address);
        }
        const { disabled, ...baseOptions } = options;
        this._closed = false;
        this._disabled = !!disabled;
        if (defaultWebSocketConstructor && !("webSocketConstructor" in baseOptions) && typeof WebSocket === "undefined") {
          baseOptions.webSocketConstructor = defaultWebSocketConstructor;
        }
        if (typeof window === "undefined" && !("unsavedChangesWarning" in baseOptions)) {
          baseOptions.unsavedChangesWarning = false;
        }
        if (!this.disabled) {
          this._client = new BaseConvexClient(
            address,
            () => {
            },
            // NOP, let the paginated query client do it all
            baseOptions
          );
          this._paginatedClient = new PaginatedQueryClient(
            this._client,
            (transition) => this._transition(transition)
          );
        }
        this.listeners = /* @__PURE__ */ new Set();
      }
      /**
       * Once closed no registered callbacks will fire again.
       */
      get closed() {
        return this._closed;
      }
      get client() {
        if (this._client) return this._client;
        throw new Error("ConvexClient is disabled");
      }
      /**
       * @internal
       */
      get paginatedClient() {
        if (this._paginatedClient) return this._paginatedClient;
        throw new Error("ConvexClient is disabled");
      }
      get disabled() {
        return this._disabled;
      }
      /**
       * Call a callback whenever a new result for a query is received. The callback
       * will run soon after being registered if a result for the query is already
       * in memory.
       *
       * The return value is an {@link Unsubscribe} object which is both a function
       * an an object with properties. Both of the patterns below work with this object:
       *
       *```ts
       * // call the return value as a function
       * const unsubscribe = client.onUpdate(api.messages.list, {}, (messages) => {
       *   console.log(messages);
       * });
       * unsubscribe();
       *
       * // unpack the return value into its properties
       * const {
       *   getCurrentValue,
       *   unsubscribe,
       * } = client.onUpdate(api.messages.list, {}, (messages) => {
       *   console.log(messages);
       * });
       *```
       *
       * @param query - A {@link server.FunctionReference} for the public query to run.
       * @param args - The arguments to run the query with.
       * @param callback - Function to call when the query result updates.
       * @param onError - Function to call when the query result updates with an error.
       * If not provided, errors will be thrown instead of calling the callback.
       *
       * @return an {@link Unsubscribe} function to stop calling the onUpdate function.
       */
      onUpdate(query, args, callback, onError) {
        if (this.disabled) {
          return this.createDisabledUnsubscribe();
        }
        const { queryToken, unsubscribe } = this.client.subscribe(
          getFunctionName(query),
          args
        );
        const queryInfo = {
          queryToken,
          callback,
          onError,
          unsubscribe,
          hasEverRun: false,
          query,
          args,
          paginationOptions: void 0
        };
        this.listeners.add(queryInfo);
        if (this.queryResultReady(queryToken) && this.callNewListenersWithCurrentValuesTimer === void 0) {
          this.callNewListenersWithCurrentValuesTimer = setTimeout(
            () => this.callNewListenersWithCurrentValues(),
            0
          );
        }
        const unsubscribeProps = {
          unsubscribe: () => {
            if (this.closed) {
              return;
            }
            this.listeners.delete(queryInfo);
            unsubscribe();
          },
          getCurrentValue: () => this.client.localQueryResultByToken(queryToken),
          getQueryLogs: () => this.client.localQueryLogs(queryToken)
        };
        const ret = unsubscribeProps.unsubscribe;
        Object.assign(ret, unsubscribeProps);
        return ret;
      }
      /**
       * Call a callback whenever a new result for a paginated query is received.
       *
       * This is an experimental preview: the final API may change.
       * In particular, caching behavior, page splitting, and required paginated query options
       * may change.
       *
       * @param query - A {@link server.FunctionReference} for the public query to run.
       * @param args - The arguments to run the query with.
       * @param options - Options for the paginated query including initialNumItems and id.
       * @param callback - Function to call when the query result updates.
       * @param onError - Function to call when the query result updates with an error.
       *
       * @return an {@link Unsubscribe} function to stop calling the callback.
       */
      onPaginatedUpdate_experimental(query, args, options, callback, onError) {
        if (this.disabled) {
          return this.createDisabledUnsubscribe();
        }
        const paginationOptions = {
          initialNumItems: options.initialNumItems,
          id: -1
        };
        const { paginatedQueryToken, unsubscribe } = this.paginatedClient.subscribe(
          getFunctionName(query),
          args,
          // Simple client doesn't use IDs, there's no expectation that these queries remain separate.
          paginationOptions
        );
        const queryInfo = {
          queryToken: paginatedQueryToken,
          callback,
          onError,
          unsubscribe,
          hasEverRun: false,
          query,
          args,
          paginationOptions
        };
        this.listeners.add(queryInfo);
        if (!!this.paginatedClient.localQueryResultByToken(paginatedQueryToken) && this.callNewListenersWithCurrentValuesTimer === void 0) {
          this.callNewListenersWithCurrentValuesTimer = setTimeout(
            () => this.callNewListenersWithCurrentValues(),
            0
          );
        }
        const unsubscribeProps = {
          unsubscribe: () => {
            if (this.closed) {
              return;
            }
            this.listeners.delete(queryInfo);
            unsubscribe();
          },
          getCurrentValue: () => {
            const result = this.paginatedClient.localQueryResult(
              getFunctionName(query),
              args,
              paginationOptions
            );
            return result;
          },
          getQueryLogs: () => []
          // Paginated queries don't aggregate their logs
        };
        const ret = unsubscribeProps.unsubscribe;
        Object.assign(ret, unsubscribeProps);
        return ret;
      }
      // Run all callbacks that have never been run before if they have a query
      // result available now.
      callNewListenersWithCurrentValues() {
        this.callNewListenersWithCurrentValuesTimer = void 0;
        this._transition({ queries: [], paginatedQueries: [] }, true);
      }
      queryResultReady(queryToken) {
        return this.client.hasLocalQueryResultByToken(queryToken);
      }
      createDisabledUnsubscribe() {
        const disabledUnsubscribe = (() => {
        });
        const unsubscribeProps = {
          unsubscribe: disabledUnsubscribe,
          getCurrentValue: () => void 0,
          getQueryLogs: () => void 0
        };
        Object.assign(disabledUnsubscribe, unsubscribeProps);
        return disabledUnsubscribe;
      }
      async close() {
        if (this.disabled) return;
        this.listeners.clear();
        this._closed = true;
        if (this._paginatedClient) {
          this._paginatedClient = void 0;
        }
        return this.client.close();
      }
      /**
       * Get the current JWT auth token and decoded claims.
       */
      getAuth() {
        if (this.disabled) return;
        return this.client.getCurrentAuthClaims();
      }
      /**
       * Set the authentication token to be used for subsequent queries and mutations.
       * `fetchToken` will be called automatically again if a token expires.
       * `fetchToken` should return `null` if the token cannot be retrieved, for example
       * when the user's rights were permanently revoked.
       * @param fetchToken - an async function returning the JWT (typically an OpenID Connect Identity Token)
       * @param onChange - a callback that will be called when the authentication status changes
       */
      setAuth(fetchToken, onChange) {
        if (this.disabled) return;
        this.client.setAuth(
          fetchToken,
          onChange ?? (() => {
          })
        );
      }
      /**
       * @internal
       */
      setAdminAuth(token, identity) {
        if (this.closed) {
          throw new Error("ConvexClient has already been closed.");
        }
        if (this.disabled) return;
        this.client.setAdminAuth(token, identity);
      }
      /**
       * @internal
       */
      _transition({
        queries,
        paginatedQueries
      }, callNewListeners = false) {
        const updatedQueries = [
          ...queries.map((q) => q.token),
          ...paginatedQueries.map((q) => q.token)
        ];
        for (const queryInfo of this.listeners) {
          const { callback, queryToken, onError, hasEverRun } = queryInfo;
          const isPaginatedQuery = serializedQueryTokenIsPaginated(queryToken);
          const hasResultReady = isPaginatedQuery ? !!this.paginatedClient.localQueryResultByToken(queryToken) : this.client.hasLocalQueryResultByToken(queryToken);
          if (updatedQueries.includes(queryToken) || callNewListeners && !hasEverRun && hasResultReady) {
            queryInfo.hasEverRun = true;
            let newValue;
            try {
              if (isPaginatedQuery) {
                newValue = this.paginatedClient.localQueryResultByToken(queryToken);
              } else {
                newValue = this.client.localQueryResultByToken(queryToken);
              }
            } catch (error) {
              if (!(error instanceof Error)) throw error;
              if (onError) {
                onError(
                  error,
                  "Second argument to onUpdate onError is reserved for later use"
                );
              } else {
                void Promise.reject(error);
              }
              continue;
            }
            callback(
              newValue,
              "Second argument to onUpdate callback is reserved for later use"
            );
          }
        }
      }
      /**
       * Execute a mutation function.
       *
       * @param mutation - A {@link server.FunctionReference} for the public mutation
       * to run.
       * @param args - An arguments object for the mutation.
       * @param options - A {@link MutationOptions} options object for the mutation.
       * @returns A promise of the mutation's result.
       */
      async mutation(mutation, args, options) {
        if (this.disabled) throw new Error("ConvexClient is disabled");
        return await this.client.mutation(getFunctionName(mutation), args, options);
      }
      /**
       * Execute an action function.
       *
       * @param action - A {@link server.FunctionReference} for the public action
       * to run.
       * @param args - An arguments object for the action.
       * @returns A promise of the action's result.
       */
      async action(action, args) {
        if (this.disabled) throw new Error("ConvexClient is disabled");
        return await this.client.action(getFunctionName(action), args);
      }
      /**
       * Fetch a query result once.
       *
       * @param query - A {@link server.FunctionReference} for the public query
       * to run.
       * @param args - An arguments object for the query.
       * @returns A promise of the query's result.
       */
      async query(query, args) {
        if (this.disabled) throw new Error("ConvexClient is disabled");
        const value = this.client.localQueryResult(getFunctionName(query), args);
        if (value !== void 0) return Promise.resolve(value);
        return new Promise((resolve, reject) => {
          const { unsubscribe } = this.onUpdate(
            query,
            args,
            (value2) => {
              unsubscribe();
              resolve(value2);
            },
            (e) => {
              unsubscribe();
              reject(e);
            }
          );
        });
      }
      /**
       * Get the current {@link ConnectionState} between the client and the Convex
       * backend.
       *
       * @returns The {@link ConnectionState} with the Convex backend.
       */
      connectionState() {
        if (this.disabled) throw new Error("ConvexClient is disabled");
        return this.client.connectionState();
      }
      /**
       * Subscribe to the {@link ConnectionState} between the client and the Convex
       * backend, calling a callback each time it changes.
       *
       * Subscribed callbacks will be called when any part of ConnectionState changes.
       * ConnectionState may grow in future versions (e.g. to provide a array of
       * inflight requests) in which case callbacks would be called more frequently.
       *
       * @returns An unsubscribe function to stop listening.
       */
      subscribeToConnectionState(cb) {
        if (this.disabled) return () => {
        };
        return this.client.subscribeToConnectionState(cb);
      }
    };
  }
});

// node_modules/convex/dist/esm/browser/simple_client-node.js
var import_module, import_path, require2, __create, __defProp15, __getOwnPropDesc2, __getOwnPropNames2, __getProtoOf, __hasOwnProp2, __require, __commonJS, __copyProps2, __toESM, require_constants, require_node_gyp_build, require_node_gyp_build2, require_fallback, require_bufferutil, require_buffer_util, require_limiter, require_permessage_deflate, require_validation, require_receiver, require_sender, require_event_target, require_extension, require_websocket, require_stream, require_subprotocol, require_websocket_server, import_stream, import_extension, import_permessage_deflate, import_receiver, import_sender, import_subprotocol, import_websocket, import_websocket_server, wrapper_default, nodeWebSocket;
var init_simple_client_node = __esm({
  "node_modules/convex/dist/esm/browser/simple_client-node.js"() {
    "use strict";
    import_module = require("module");
    import_path = require("path");
    init_simple_client();
    require2 = (0, import_module.createRequire)((0, import_path.resolve)("."));
    __create = Object.create;
    __defProp15 = Object.defineProperty;
    __getOwnPropDesc2 = Object.getOwnPropertyDescriptor;
    __getOwnPropNames2 = Object.getOwnPropertyNames;
    __getProtoOf = Object.getPrototypeOf;
    __hasOwnProp2 = Object.prototype.hasOwnProperty;
    __require = /* @__PURE__ */ ((x) => typeof require2 !== "undefined" ? require2 : typeof Proxy !== "undefined" ? new Proxy(x, {
      get: (a, b) => (typeof require2 !== "undefined" ? require2 : a)[b]
    }) : x)(function(x) {
      if (typeof require2 !== "undefined") return require2.apply(this, arguments);
      throw Error('Dynamic require of "' + x + '" is not supported');
    });
    __commonJS = (cb, mod) => function __require2() {
      return mod || (0, cb[__getOwnPropNames2(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    };
    __copyProps2 = (to, from, except, desc) => {
      if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames2(from))
          if (!__hasOwnProp2.call(to, key) && key !== except)
            __defProp15(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc2(from, key)) || desc.enumerable });
      }
      return to;
    };
    __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps2(
      // If the importer is in node compatibility mode or this is not an ESM
      // file that has been converted to a CommonJS file using a Babel-
      // compatible transform (i.e. "__esModule" has not been set), then set
      // "default" to the CommonJS "module.exports" for node compatibility.
      isNodeMode || !mod || !mod.__esModule ? __defProp15(target, "default", { value: mod, enumerable: true }) : target,
      mod
    ));
    require_constants = __commonJS({
      "../node_modules/.pnpm/ws@8.21.0_bufferutil@4.0.9/node_modules/ws/lib/constants.js"(exports2, module2) {
        "use strict";
        var BINARY_TYPES = ["nodebuffer", "arraybuffer", "fragments"];
        var hasBlob = typeof Blob !== "undefined";
        if (hasBlob) BINARY_TYPES.push("blob");
        module2.exports = {
          BINARY_TYPES,
          CLOSE_TIMEOUT: 3e4,
          EMPTY_BUFFER: Buffer.alloc(0),
          GUID: "258EAFA5-E914-47DA-95CA-C5AB0DC85B11",
          hasBlob,
          kForOnEventAttribute: Symbol("kIsForOnEventAttribute"),
          kListener: Symbol("kListener"),
          kStatusCode: Symbol("status-code"),
          kWebSocket: Symbol("websocket"),
          NOOP: () => {
          }
        };
      }
    });
    require_node_gyp_build = __commonJS({
      "../node_modules/.pnpm/node-gyp-build@4.8.4/node_modules/node-gyp-build/node-gyp-build.js"(exports2, module2) {
        var fs = __require("fs");
        var path = __require("path");
        var os = __require("os");
        var runtimeRequire = typeof __webpack_require__ === "function" ? __non_webpack_require__ : __require;
        var vars2 = process.config && process.config.variables || {};
        var prebuildsOnly = !!process.env.PREBUILDS_ONLY;
        var abi = process.versions.modules;
        var runtime = isElectron() ? "electron" : isNwjs() ? "node-webkit" : "node";
        var arch = process.env.npm_config_arch || os.arch();
        var platform = process.env.npm_config_platform || os.platform();
        var libc = process.env.LIBC || (isAlpine(platform) ? "musl" : "glibc");
        var armv = process.env.ARM_VERSION || (arch === "arm64" ? "8" : vars2.arm_version) || "";
        var uv = (process.versions.uv || "").split(".")[0];
        module2.exports = load;
        function load(dir) {
          return runtimeRequire(load.resolve(dir));
        }
        load.resolve = load.path = function(dir) {
          dir = path.resolve(dir || ".");
          try {
            var name = runtimeRequire(path.join(dir, "package.json")).name.toUpperCase().replace(/-/g, "_");
            if (process.env[name + "_PREBUILD"]) dir = process.env[name + "_PREBUILD"];
          } catch (err) {
          }
          if (!prebuildsOnly) {
            var release = getFirst(path.join(dir, "build/Release"), matchBuild);
            if (release) return release;
            var debug = getFirst(path.join(dir, "build/Debug"), matchBuild);
            if (debug) return debug;
          }
          var prebuild = resolve(dir);
          if (prebuild) return prebuild;
          var nearby = resolve(path.dirname(process.execPath));
          if (nearby) return nearby;
          var target = [
            "platform=" + platform,
            "arch=" + arch,
            "runtime=" + runtime,
            "abi=" + abi,
            "uv=" + uv,
            armv ? "armv=" + armv : "",
            "libc=" + libc,
            "node=" + process.versions.node,
            process.versions.electron ? "electron=" + process.versions.electron : "",
            typeof __webpack_require__ === "function" ? "webpack=true" : ""
            // eslint-disable-line
          ].filter(Boolean).join(" ");
          throw new Error("No native build was found for " + target + "\n    loaded from: " + dir + "\n");
          function resolve(dir2) {
            var tuples = readdirSync(path.join(dir2, "prebuilds")).map(parseTuple);
            var tuple = tuples.filter(matchTuple(platform, arch)).sort(compareTuples)[0];
            if (!tuple) return;
            var prebuilds = path.join(dir2, "prebuilds", tuple.name);
            var parsed = readdirSync(prebuilds).map(parseTags);
            var candidates = parsed.filter(matchTags(runtime, abi));
            var winner = candidates.sort(compareTags(runtime))[0];
            if (winner) return path.join(prebuilds, winner.file);
          }
        };
        function readdirSync(dir) {
          try {
            return fs.readdirSync(dir);
          } catch (err) {
            return [];
          }
        }
        function getFirst(dir, filter) {
          var files = readdirSync(dir).filter(filter);
          return files[0] && path.join(dir, files[0]);
        }
        function matchBuild(name) {
          return /\.node$/.test(name);
        }
        function parseTuple(name) {
          var arr2 = name.split("-");
          if (arr2.length !== 2) return;
          var platform2 = arr2[0];
          var architectures = arr2[1].split("+");
          if (!platform2) return;
          if (!architectures.length) return;
          if (!architectures.every(Boolean)) return;
          return { name, platform: platform2, architectures };
        }
        function matchTuple(platform2, arch2) {
          return function(tuple) {
            if (tuple == null) return false;
            if (tuple.platform !== platform2) return false;
            return tuple.architectures.includes(arch2);
          };
        }
        function compareTuples(a, b) {
          return a.architectures.length - b.architectures.length;
        }
        function parseTags(file) {
          var arr2 = file.split(".");
          var extension2 = arr2.pop();
          var tags = { file, specificity: 0 };
          if (extension2 !== "node") return;
          for (var i = 0; i < arr2.length; i++) {
            var tag = arr2[i];
            if (tag === "node" || tag === "electron" || tag === "node-webkit") {
              tags.runtime = tag;
            } else if (tag === "napi") {
              tags.napi = true;
            } else if (tag.slice(0, 3) === "abi") {
              tags.abi = tag.slice(3);
            } else if (tag.slice(0, 2) === "uv") {
              tags.uv = tag.slice(2);
            } else if (tag.slice(0, 4) === "armv") {
              tags.armv = tag.slice(4);
            } else if (tag === "glibc" || tag === "musl") {
              tags.libc = tag;
            } else {
              continue;
            }
            tags.specificity++;
          }
          return tags;
        }
        function matchTags(runtime2, abi2) {
          return function(tags) {
            if (tags == null) return false;
            if (tags.runtime && tags.runtime !== runtime2 && !runtimeAgnostic(tags)) return false;
            if (tags.abi && tags.abi !== abi2 && !tags.napi) return false;
            if (tags.uv && tags.uv !== uv) return false;
            if (tags.armv && tags.armv !== armv) return false;
            if (tags.libc && tags.libc !== libc) return false;
            return true;
          };
        }
        function runtimeAgnostic(tags) {
          return tags.runtime === "node" && tags.napi;
        }
        function compareTags(runtime2) {
          return function(a, b) {
            if (a.runtime !== b.runtime) {
              return a.runtime === runtime2 ? -1 : 1;
            } else if (a.abi !== b.abi) {
              return a.abi ? -1 : 1;
            } else if (a.specificity !== b.specificity) {
              return a.specificity > b.specificity ? -1 : 1;
            } else {
              return 0;
            }
          };
        }
        function isNwjs() {
          return !!(process.versions && process.versions.nw);
        }
        function isElectron() {
          if (process.versions && process.versions.electron) return true;
          if (process.env.ELECTRON_RUN_AS_NODE) return true;
          return typeof window !== "undefined" && window.process && window.process.type === "renderer";
        }
        function isAlpine(platform2) {
          return platform2 === "linux" && fs.existsSync("/etc/alpine-release");
        }
        load.parseTags = parseTags;
        load.matchTags = matchTags;
        load.compareTags = compareTags;
        load.parseTuple = parseTuple;
        load.matchTuple = matchTuple;
        load.compareTuples = compareTuples;
      }
    });
    require_node_gyp_build2 = __commonJS({
      "../node_modules/.pnpm/node-gyp-build@4.8.4/node_modules/node-gyp-build/index.js"(exports2, module2) {
        var runtimeRequire = typeof __webpack_require__ === "function" ? __non_webpack_require__ : __require;
        if (typeof runtimeRequire.addon === "function") {
          module2.exports = runtimeRequire.addon.bind(runtimeRequire);
        } else {
          module2.exports = require_node_gyp_build();
        }
      }
    });
    require_fallback = __commonJS({
      "../node_modules/.pnpm/bufferutil@4.0.9/node_modules/bufferutil/fallback.js"(exports2, module2) {
        "use strict";
        var mask = (source, mask2, output, offset, length) => {
          for (var i = 0; i < length; i++) {
            output[offset + i] = source[i] ^ mask2[i & 3];
          }
        };
        var unmask = (buffer, mask2) => {
          const length = buffer.length;
          for (var i = 0; i < length; i++) {
            buffer[i] ^= mask2[i & 3];
          }
        };
        module2.exports = { mask, unmask };
      }
    });
    require_bufferutil = __commonJS({
      "../node_modules/.pnpm/bufferutil@4.0.9/node_modules/bufferutil/index.js"(exports2, module2) {
        "use strict";
        try {
          module2.exports = require_node_gyp_build2()(__dirname);
        } catch (e) {
          module2.exports = require_fallback();
        }
      }
    });
    require_buffer_util = __commonJS({
      "../node_modules/.pnpm/ws@8.21.0_bufferutil@4.0.9/node_modules/ws/lib/buffer-util.js"(exports2, module2) {
        "use strict";
        var { EMPTY_BUFFER } = require_constants();
        var FastBuffer = Buffer[Symbol.species];
        function concat(list, totalLength) {
          if (list.length === 0) return EMPTY_BUFFER;
          if (list.length === 1) return list[0];
          const target = Buffer.allocUnsafe(totalLength);
          let offset = 0;
          for (let i = 0; i < list.length; i++) {
            const buf = list[i];
            target.set(buf, offset);
            offset += buf.length;
          }
          if (offset < totalLength) {
            return new FastBuffer(target.buffer, target.byteOffset, offset);
          }
          return target;
        }
        function _mask(source, mask, output, offset, length) {
          for (let i = 0; i < length; i++) {
            output[offset + i] = source[i] ^ mask[i & 3];
          }
        }
        function _unmask(buffer, mask) {
          for (let i = 0; i < buffer.length; i++) {
            buffer[i] ^= mask[i & 3];
          }
        }
        function toArrayBuffer(buf) {
          if (buf.length === buf.buffer.byteLength) {
            return buf.buffer;
          }
          return buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.length);
        }
        function toBuffer(data) {
          toBuffer.readOnly = true;
          if (Buffer.isBuffer(data)) return data;
          let buf;
          if (data instanceof ArrayBuffer) {
            buf = new FastBuffer(data);
          } else if (ArrayBuffer.isView(data)) {
            buf = new FastBuffer(data.buffer, data.byteOffset, data.byteLength);
          } else {
            buf = Buffer.from(data);
            toBuffer.readOnly = false;
          }
          return buf;
        }
        module2.exports = {
          concat,
          mask: _mask,
          toArrayBuffer,
          toBuffer,
          unmask: _unmask
        };
        if (!process.env.WS_NO_BUFFER_UTIL) {
          try {
            const bufferUtil = require_bufferutil();
            module2.exports.mask = function(source, mask, output, offset, length) {
              if (length < 48) _mask(source, mask, output, offset, length);
              else bufferUtil.mask(source, mask, output, offset, length);
            };
            module2.exports.unmask = function(buffer, mask) {
              if (buffer.length < 32) _unmask(buffer, mask);
              else bufferUtil.unmask(buffer, mask);
            };
          } catch (e) {
          }
        }
      }
    });
    require_limiter = __commonJS({
      "../node_modules/.pnpm/ws@8.21.0_bufferutil@4.0.9/node_modules/ws/lib/limiter.js"(exports2, module2) {
        "use strict";
        var kDone = Symbol("kDone");
        var kRun = Symbol("kRun");
        var Limiter = class {
          /**
           * Creates a new `Limiter`.
           *
           * @param {Number} [concurrency=Infinity] The maximum number of jobs allowed
           *     to run concurrently
           */
          constructor(concurrency) {
            this[kDone] = () => {
              this.pending--;
              this[kRun]();
            };
            this.concurrency = concurrency || Infinity;
            this.jobs = [];
            this.pending = 0;
          }
          /**
           * Adds a job to the queue.
           *
           * @param {Function} job The job to run
           * @public
           */
          add(job) {
            this.jobs.push(job);
            this[kRun]();
          }
          /**
           * Removes a job from the queue and runs it if possible.
           *
           * @private
           */
          [kRun]() {
            if (this.pending === this.concurrency) return;
            if (this.jobs.length) {
              const job = this.jobs.shift();
              this.pending++;
              job(this[kDone]);
            }
          }
        };
        module2.exports = Limiter;
      }
    });
    require_permessage_deflate = __commonJS({
      "../node_modules/.pnpm/ws@8.21.0_bufferutil@4.0.9/node_modules/ws/lib/permessage-deflate.js"(exports2, module2) {
        "use strict";
        var zlib = __require("zlib");
        var bufferUtil = require_buffer_util();
        var Limiter = require_limiter();
        var { kStatusCode } = require_constants();
        var FastBuffer = Buffer[Symbol.species];
        var TRAILER = Buffer.from([0, 0, 255, 255]);
        var kPerMessageDeflate = Symbol("permessage-deflate");
        var kTotalLength = Symbol("total-length");
        var kCallback = Symbol("callback");
        var kBuffers = Symbol("buffers");
        var kError = Symbol("error");
        var zlibLimiter;
        var PerMessageDeflate2 = class {
          /**
           * Creates a PerMessageDeflate instance.
           *
           * @param {Object} [options] Configuration options
           * @param {(Boolean|Number)} [options.clientMaxWindowBits] Advertise support
           *     for, or request, a custom client window size
           * @param {Boolean} [options.clientNoContextTakeover=false] Advertise/
           *     acknowledge disabling of client context takeover
           * @param {Number} [options.concurrencyLimit=10] The number of concurrent
           *     calls to zlib
           * @param {Boolean} [options.isServer=false] Create the instance in either
           *     server or client mode
           * @param {Number} [options.maxPayload=0] The maximum allowed message length
           * @param {(Boolean|Number)} [options.serverMaxWindowBits] Request/confirm the
           *     use of a custom server window size
           * @param {Boolean} [options.serverNoContextTakeover=false] Request/accept
           *     disabling of server context takeover
           * @param {Number} [options.threshold=1024] Size (in bytes) below which
           *     messages should not be compressed if context takeover is disabled
           * @param {Object} [options.zlibDeflateOptions] Options to pass to zlib on
           *     deflate
           * @param {Object} [options.zlibInflateOptions] Options to pass to zlib on
           *     inflate
           */
          constructor(options) {
            this._options = options || {};
            this._threshold = this._options.threshold !== void 0 ? this._options.threshold : 1024;
            this._maxPayload = this._options.maxPayload | 0;
            this._isServer = !!this._options.isServer;
            this._deflate = null;
            this._inflate = null;
            this.params = null;
            if (!zlibLimiter) {
              const concurrency = this._options.concurrencyLimit !== void 0 ? this._options.concurrencyLimit : 10;
              zlibLimiter = new Limiter(concurrency);
            }
          }
          /**
           * @type {String}
           */
          static get extensionName() {
            return "permessage-deflate";
          }
          /**
           * Create an extension negotiation offer.
           *
           * @return {Object} Extension parameters
           * @public
           */
          offer() {
            const params = {};
            if (this._options.serverNoContextTakeover) {
              params.server_no_context_takeover = true;
            }
            if (this._options.clientNoContextTakeover) {
              params.client_no_context_takeover = true;
            }
            if (this._options.serverMaxWindowBits) {
              params.server_max_window_bits = this._options.serverMaxWindowBits;
            }
            if (this._options.clientMaxWindowBits) {
              params.client_max_window_bits = this._options.clientMaxWindowBits;
            } else if (this._options.clientMaxWindowBits == null) {
              params.client_max_window_bits = true;
            }
            return params;
          }
          /**
           * Accept an extension negotiation offer/response.
           *
           * @param {Array} configurations The extension negotiation offers/reponse
           * @return {Object} Accepted configuration
           * @public
           */
          accept(configurations) {
            configurations = this.normalizeParams(configurations);
            this.params = this._isServer ? this.acceptAsServer(configurations) : this.acceptAsClient(configurations);
            return this.params;
          }
          /**
           * Releases all resources used by the extension.
           *
           * @public
           */
          cleanup() {
            if (this._inflate) {
              this._inflate.close();
              this._inflate = null;
            }
            if (this._deflate) {
              const callback = this._deflate[kCallback];
              this._deflate.close();
              this._deflate = null;
              if (callback) {
                callback(
                  new Error(
                    "The deflate stream was closed while data was being processed"
                  )
                );
              }
            }
          }
          /**
           *  Accept an extension negotiation offer.
           *
           * @param {Array} offers The extension negotiation offers
           * @return {Object} Accepted configuration
           * @private
           */
          acceptAsServer(offers) {
            const opts = this._options;
            const accepted = offers.find((params) => {
              if (opts.serverNoContextTakeover === false && params.server_no_context_takeover || params.server_max_window_bits && (opts.serverMaxWindowBits === false || typeof opts.serverMaxWindowBits === "number" && opts.serverMaxWindowBits > params.server_max_window_bits) || typeof opts.clientMaxWindowBits === "number" && !params.client_max_window_bits) {
                return false;
              }
              return true;
            });
            if (!accepted) {
              throw new Error("None of the extension offers can be accepted");
            }
            if (opts.serverNoContextTakeover) {
              accepted.server_no_context_takeover = true;
            }
            if (opts.clientNoContextTakeover) {
              accepted.client_no_context_takeover = true;
            }
            if (typeof opts.serverMaxWindowBits === "number") {
              accepted.server_max_window_bits = opts.serverMaxWindowBits;
            }
            if (typeof opts.clientMaxWindowBits === "number") {
              accepted.client_max_window_bits = opts.clientMaxWindowBits;
            } else if (accepted.client_max_window_bits === true || opts.clientMaxWindowBits === false) {
              delete accepted.client_max_window_bits;
            }
            return accepted;
          }
          /**
           * Accept the extension negotiation response.
           *
           * @param {Array} response The extension negotiation response
           * @return {Object} Accepted configuration
           * @private
           */
          acceptAsClient(response) {
            const params = response[0];
            if (this._options.clientNoContextTakeover === false && params.client_no_context_takeover) {
              throw new Error('Unexpected parameter "client_no_context_takeover"');
            }
            if (!params.client_max_window_bits) {
              if (typeof this._options.clientMaxWindowBits === "number") {
                params.client_max_window_bits = this._options.clientMaxWindowBits;
              }
            } else if (this._options.clientMaxWindowBits === false || typeof this._options.clientMaxWindowBits === "number" && params.client_max_window_bits > this._options.clientMaxWindowBits) {
              throw new Error(
                'Unexpected or invalid parameter "client_max_window_bits"'
              );
            }
            return params;
          }
          /**
           * Normalize parameters.
           *
           * @param {Array} configurations The extension negotiation offers/reponse
           * @return {Array} The offers/response with normalized parameters
           * @private
           */
          normalizeParams(configurations) {
            configurations.forEach((params) => {
              Object.keys(params).forEach((key) => {
                let value = params[key];
                if (value.length > 1) {
                  throw new Error(`Parameter "${key}" must have only a single value`);
                }
                value = value[0];
                if (key === "client_max_window_bits") {
                  if (value !== true) {
                    const num2 = +value;
                    if (!Number.isInteger(num2) || num2 < 8 || num2 > 15) {
                      throw new TypeError(
                        `Invalid value for parameter "${key}": ${value}`
                      );
                    }
                    value = num2;
                  } else if (!this._isServer) {
                    throw new TypeError(
                      `Invalid value for parameter "${key}": ${value}`
                    );
                  }
                } else if (key === "server_max_window_bits") {
                  const num2 = +value;
                  if (!Number.isInteger(num2) || num2 < 8 || num2 > 15) {
                    throw new TypeError(
                      `Invalid value for parameter "${key}": ${value}`
                    );
                  }
                  value = num2;
                } else if (key === "client_no_context_takeover" || key === "server_no_context_takeover") {
                  if (value !== true) {
                    throw new TypeError(
                      `Invalid value for parameter "${key}": ${value}`
                    );
                  }
                } else {
                  throw new Error(`Unknown parameter "${key}"`);
                }
                params[key] = value;
              });
            });
            return configurations;
          }
          /**
           * Decompress data. Concurrency limited.
           *
           * @param {Buffer} data Compressed data
           * @param {Boolean} fin Specifies whether or not this is the last fragment
           * @param {Function} callback Callback
           * @public
           */
          decompress(data, fin, callback) {
            zlibLimiter.add((done) => {
              this._decompress(data, fin, (err, result) => {
                done();
                callback(err, result);
              });
            });
          }
          /**
           * Compress data. Concurrency limited.
           *
           * @param {(Buffer|String)} data Data to compress
           * @param {Boolean} fin Specifies whether or not this is the last fragment
           * @param {Function} callback Callback
           * @public
           */
          compress(data, fin, callback) {
            zlibLimiter.add((done) => {
              this._compress(data, fin, (err, result) => {
                done();
                callback(err, result);
              });
            });
          }
          /**
           * Decompress data.
           *
           * @param {Buffer} data Compressed data
           * @param {Boolean} fin Specifies whether or not this is the last fragment
           * @param {Function} callback Callback
           * @private
           */
          _decompress(data, fin, callback) {
            const endpoint = this._isServer ? "client" : "server";
            if (!this._inflate) {
              const key = `${endpoint}_max_window_bits`;
              const windowBits = typeof this.params[key] !== "number" ? zlib.Z_DEFAULT_WINDOWBITS : this.params[key];
              this._inflate = zlib.createInflateRaw({
                ...this._options.zlibInflateOptions,
                windowBits
              });
              this._inflate[kPerMessageDeflate] = this;
              this._inflate[kTotalLength] = 0;
              this._inflate[kBuffers] = [];
              this._inflate.on("error", inflateOnError);
              this._inflate.on("data", inflateOnData);
            }
            this._inflate[kCallback] = callback;
            this._inflate.write(data);
            if (fin) this._inflate.write(TRAILER);
            this._inflate.flush(() => {
              const err = this._inflate[kError];
              if (err) {
                this._inflate.close();
                this._inflate = null;
                callback(err);
                return;
              }
              const data2 = bufferUtil.concat(
                this._inflate[kBuffers],
                this._inflate[kTotalLength]
              );
              if (this._inflate._readableState.endEmitted) {
                this._inflate.close();
                this._inflate = null;
              } else {
                this._inflate[kTotalLength] = 0;
                this._inflate[kBuffers] = [];
                if (fin && this.params[`${endpoint}_no_context_takeover`]) {
                  this._inflate.reset();
                }
              }
              callback(null, data2);
            });
          }
          /**
           * Compress data.
           *
           * @param {(Buffer|String)} data Data to compress
           * @param {Boolean} fin Specifies whether or not this is the last fragment
           * @param {Function} callback Callback
           * @private
           */
          _compress(data, fin, callback) {
            const endpoint = this._isServer ? "server" : "client";
            if (!this._deflate) {
              const key = `${endpoint}_max_window_bits`;
              const windowBits = typeof this.params[key] !== "number" ? zlib.Z_DEFAULT_WINDOWBITS : this.params[key];
              this._deflate = zlib.createDeflateRaw({
                ...this._options.zlibDeflateOptions,
                windowBits
              });
              this._deflate[kTotalLength] = 0;
              this._deflate[kBuffers] = [];
              this._deflate.on("data", deflateOnData);
            }
            this._deflate[kCallback] = callback;
            this._deflate.write(data);
            this._deflate.flush(zlib.Z_SYNC_FLUSH, () => {
              if (!this._deflate) {
                return;
              }
              let data2 = bufferUtil.concat(
                this._deflate[kBuffers],
                this._deflate[kTotalLength]
              );
              if (fin) {
                data2 = new FastBuffer(data2.buffer, data2.byteOffset, data2.length - 4);
              }
              this._deflate[kCallback] = null;
              this._deflate[kTotalLength] = 0;
              this._deflate[kBuffers] = [];
              if (fin && this.params[`${endpoint}_no_context_takeover`]) {
                this._deflate.reset();
              }
              callback(null, data2);
            });
          }
        };
        module2.exports = PerMessageDeflate2;
        function deflateOnData(chunk) {
          this[kBuffers].push(chunk);
          this[kTotalLength] += chunk.length;
        }
        function inflateOnData(chunk) {
          this[kTotalLength] += chunk.length;
          if (this[kPerMessageDeflate]._maxPayload < 1 || this[kTotalLength] <= this[kPerMessageDeflate]._maxPayload) {
            this[kBuffers].push(chunk);
            return;
          }
          this[kError] = new RangeError("Max payload size exceeded");
          this[kError].code = "WS_ERR_UNSUPPORTED_MESSAGE_LENGTH";
          this[kError][kStatusCode] = 1009;
          this.removeListener("data", inflateOnData);
          this.reset();
        }
        function inflateOnError(err) {
          this[kPerMessageDeflate]._inflate = null;
          if (this[kError]) {
            this[kCallback](this[kError]);
            return;
          }
          err[kStatusCode] = 1007;
          this[kCallback](err);
        }
      }
    });
    require_validation = __commonJS({
      "../node_modules/.pnpm/ws@8.21.0_bufferutil@4.0.9/node_modules/ws/lib/validation.js"(exports2, module2) {
        "use strict";
        var { isUtf8 } = __require("buffer");
        var { hasBlob } = require_constants();
        var tokenChars = [
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          // 0 - 15
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          // 16 - 31
          0,
          1,
          0,
          1,
          1,
          1,
          1,
          1,
          0,
          0,
          1,
          1,
          0,
          1,
          1,
          0,
          // 32 - 47
          1,
          1,
          1,
          1,
          1,
          1,
          1,
          1,
          1,
          1,
          0,
          0,
          0,
          0,
          0,
          0,
          // 48 - 63
          0,
          1,
          1,
          1,
          1,
          1,
          1,
          1,
          1,
          1,
          1,
          1,
          1,
          1,
          1,
          1,
          // 64 - 79
          1,
          1,
          1,
          1,
          1,
          1,
          1,
          1,
          1,
          1,
          1,
          0,
          0,
          0,
          1,
          1,
          // 80 - 95
          1,
          1,
          1,
          1,
          1,
          1,
          1,
          1,
          1,
          1,
          1,
          1,
          1,
          1,
          1,
          1,
          // 96 - 111
          1,
          1,
          1,
          1,
          1,
          1,
          1,
          1,
          1,
          1,
          1,
          0,
          1,
          0,
          1,
          0
          // 112 - 127
        ];
        function isValidStatusCode(code2) {
          return code2 >= 1e3 && code2 <= 1014 && code2 !== 1004 && code2 !== 1005 && code2 !== 1006 || code2 >= 3e3 && code2 <= 4999;
        }
        function _isValidUTF8(buf) {
          const len = buf.length;
          let i = 0;
          while (i < len) {
            if ((buf[i] & 128) === 0) {
              i++;
            } else if ((buf[i] & 224) === 192) {
              if (i + 1 === len || (buf[i + 1] & 192) !== 128 || (buf[i] & 254) === 192) {
                return false;
              }
              i += 2;
            } else if ((buf[i] & 240) === 224) {
              if (i + 2 >= len || (buf[i + 1] & 192) !== 128 || (buf[i + 2] & 192) !== 128 || buf[i] === 224 && (buf[i + 1] & 224) === 128 || // Overlong
              buf[i] === 237 && (buf[i + 1] & 224) === 160) {
                return false;
              }
              i += 3;
            } else if ((buf[i] & 248) === 240) {
              if (i + 3 >= len || (buf[i + 1] & 192) !== 128 || (buf[i + 2] & 192) !== 128 || (buf[i + 3] & 192) !== 128 || buf[i] === 240 && (buf[i + 1] & 240) === 128 || // Overlong
              buf[i] === 244 && buf[i + 1] > 143 || buf[i] > 244) {
                return false;
              }
              i += 4;
            } else {
              return false;
            }
          }
          return true;
        }
        function isBlob(value) {
          return hasBlob && typeof value === "object" && typeof value.arrayBuffer === "function" && typeof value.type === "string" && typeof value.stream === "function" && (value[Symbol.toStringTag] === "Blob" || value[Symbol.toStringTag] === "File");
        }
        module2.exports = {
          isBlob,
          isValidStatusCode,
          isValidUTF8: _isValidUTF8,
          tokenChars
        };
        if (isUtf8) {
          module2.exports.isValidUTF8 = function(buf) {
            return buf.length < 24 ? _isValidUTF8(buf) : isUtf8(buf);
          };
        } else if (!process.env.WS_NO_UTF_8_VALIDATE) {
          try {
            const isValidUTF8 = __require("utf-8-validate");
            module2.exports.isValidUTF8 = function(buf) {
              return buf.length < 32 ? _isValidUTF8(buf) : isValidUTF8(buf);
            };
          } catch (e) {
          }
        }
      }
    });
    require_receiver = __commonJS({
      "../node_modules/.pnpm/ws@8.21.0_bufferutil@4.0.9/node_modules/ws/lib/receiver.js"(exports2, module2) {
        "use strict";
        var { Writable } = __require("stream");
        var PerMessageDeflate2 = require_permessage_deflate();
        var {
          BINARY_TYPES,
          EMPTY_BUFFER,
          kStatusCode,
          kWebSocket
        } = require_constants();
        var { concat, toArrayBuffer, unmask } = require_buffer_util();
        var { isValidStatusCode, isValidUTF8 } = require_validation();
        var FastBuffer = Buffer[Symbol.species];
        var GET_INFO = 0;
        var GET_PAYLOAD_LENGTH_16 = 1;
        var GET_PAYLOAD_LENGTH_64 = 2;
        var GET_MASK = 3;
        var GET_DATA = 4;
        var INFLATING = 5;
        var DEFER_EVENT = 6;
        var Receiver2 = class extends Writable {
          /**
           * Creates a Receiver instance.
           *
           * @param {Object} [options] Options object
           * @param {Boolean} [options.allowSynchronousEvents=true] Specifies whether
           *     any of the `'message'`, `'ping'`, and `'pong'` events can be emitted
           *     multiple times in the same tick
           * @param {String} [options.binaryType=nodebuffer] The type for binary data
           * @param {Object} [options.extensions] An object containing the negotiated
           *     extensions
           * @param {Boolean} [options.isServer=false] Specifies whether to operate in
           *     client or server mode
           * @param {Number} [options.maxBufferedChunks=0] The maximum number of
           *     buffered data chunks
           * @param {Number} [options.maxFragments=0] The maximum number of message
           *     fragments
           * @param {Number} [options.maxPayload=0] The maximum allowed message length
           * @param {Boolean} [options.skipUTF8Validation=false] Specifies whether or
           *     not to skip UTF-8 validation for text and close messages
           */
          constructor(options = {}) {
            super();
            this._allowSynchronousEvents = options.allowSynchronousEvents !== void 0 ? options.allowSynchronousEvents : true;
            this._binaryType = options.binaryType || BINARY_TYPES[0];
            this._extensions = options.extensions || {};
            this._isServer = !!options.isServer;
            this._maxBufferedChunks = options.maxBufferedChunks | 0;
            this._maxFragments = options.maxFragments | 0;
            this._maxPayload = options.maxPayload | 0;
            this._skipUTF8Validation = !!options.skipUTF8Validation;
            this[kWebSocket] = void 0;
            this._bufferedBytes = 0;
            this._buffers = [];
            this._compressed = false;
            this._payloadLength = 0;
            this._mask = void 0;
            this._fragmented = 0;
            this._masked = false;
            this._fin = false;
            this._opcode = 0;
            this._totalPayloadLength = 0;
            this._messageLength = 0;
            this._fragments = [];
            this._errored = false;
            this._loop = false;
            this._state = GET_INFO;
          }
          /**
           * Implements `Writable.prototype._write()`.
           *
           * @param {Buffer} chunk The chunk of data to write
           * @param {String} encoding The character encoding of `chunk`
           * @param {Function} cb Callback
           * @private
           */
          _write(chunk, encoding, cb) {
            if (this._opcode === 8 && this._state == GET_INFO) return cb();
            if (this._maxBufferedChunks > 0 && this._buffers.length >= this._maxBufferedChunks) {
              cb(
                this.createError(
                  RangeError,
                  "Too many buffered chunks",
                  false,
                  1008,
                  "WS_ERR_TOO_MANY_BUFFERED_PARTS"
                )
              );
              return;
            }
            this._bufferedBytes += chunk.length;
            this._buffers.push(chunk);
            this.startLoop(cb);
          }
          /**
           * Consumes `n` bytes from the buffered data.
           *
           * @param {Number} n The number of bytes to consume
           * @return {Buffer} The consumed bytes
           * @private
           */
          consume(n) {
            this._bufferedBytes -= n;
            if (n === this._buffers[0].length) return this._buffers.shift();
            if (n < this._buffers[0].length) {
              const buf = this._buffers[0];
              this._buffers[0] = new FastBuffer(
                buf.buffer,
                buf.byteOffset + n,
                buf.length - n
              );
              return new FastBuffer(buf.buffer, buf.byteOffset, n);
            }
            const dst = Buffer.allocUnsafe(n);
            do {
              const buf = this._buffers[0];
              const offset = dst.length - n;
              if (n >= buf.length) {
                dst.set(this._buffers.shift(), offset);
              } else {
                dst.set(new Uint8Array(buf.buffer, buf.byteOffset, n), offset);
                this._buffers[0] = new FastBuffer(
                  buf.buffer,
                  buf.byteOffset + n,
                  buf.length - n
                );
              }
              n -= buf.length;
            } while (n > 0);
            return dst;
          }
          /**
           * Starts the parsing loop.
           *
           * @param {Function} cb Callback
           * @private
           */
          startLoop(cb) {
            this._loop = true;
            do {
              switch (this._state) {
                case GET_INFO:
                  this.getInfo(cb);
                  break;
                case GET_PAYLOAD_LENGTH_16:
                  this.getPayloadLength16(cb);
                  break;
                case GET_PAYLOAD_LENGTH_64:
                  this.getPayloadLength64(cb);
                  break;
                case GET_MASK:
                  this.getMask();
                  break;
                case GET_DATA:
                  this.getData(cb);
                  break;
                case INFLATING:
                case DEFER_EVENT:
                  this._loop = false;
                  return;
              }
            } while (this._loop);
            if (!this._errored) cb();
          }
          /**
           * Reads the first two bytes of a frame.
           *
           * @param {Function} cb Callback
           * @private
           */
          getInfo(cb) {
            if (this._bufferedBytes < 2) {
              this._loop = false;
              return;
            }
            const buf = this.consume(2);
            if ((buf[0] & 48) !== 0) {
              const error = this.createError(
                RangeError,
                "RSV2 and RSV3 must be clear",
                true,
                1002,
                "WS_ERR_UNEXPECTED_RSV_2_3"
              );
              cb(error);
              return;
            }
            const compressed = (buf[0] & 64) === 64;
            if (compressed && !this._extensions[PerMessageDeflate2.extensionName]) {
              const error = this.createError(
                RangeError,
                "RSV1 must be clear",
                true,
                1002,
                "WS_ERR_UNEXPECTED_RSV_1"
              );
              cb(error);
              return;
            }
            this._fin = (buf[0] & 128) === 128;
            this._opcode = buf[0] & 15;
            this._payloadLength = buf[1] & 127;
            if (this._opcode === 0) {
              if (compressed) {
                const error = this.createError(
                  RangeError,
                  "RSV1 must be clear",
                  true,
                  1002,
                  "WS_ERR_UNEXPECTED_RSV_1"
                );
                cb(error);
                return;
              }
              if (!this._fragmented) {
                const error = this.createError(
                  RangeError,
                  "invalid opcode 0",
                  true,
                  1002,
                  "WS_ERR_INVALID_OPCODE"
                );
                cb(error);
                return;
              }
              this._opcode = this._fragmented;
            } else if (this._opcode === 1 || this._opcode === 2) {
              if (this._fragmented) {
                const error = this.createError(
                  RangeError,
                  `invalid opcode ${this._opcode}`,
                  true,
                  1002,
                  "WS_ERR_INVALID_OPCODE"
                );
                cb(error);
                return;
              }
              this._compressed = compressed;
            } else if (this._opcode > 7 && this._opcode < 11) {
              if (!this._fin) {
                const error = this.createError(
                  RangeError,
                  "FIN must be set",
                  true,
                  1002,
                  "WS_ERR_EXPECTED_FIN"
                );
                cb(error);
                return;
              }
              if (compressed) {
                const error = this.createError(
                  RangeError,
                  "RSV1 must be clear",
                  true,
                  1002,
                  "WS_ERR_UNEXPECTED_RSV_1"
                );
                cb(error);
                return;
              }
              if (this._payloadLength > 125 || this._opcode === 8 && this._payloadLength === 1) {
                const error = this.createError(
                  RangeError,
                  `invalid payload length ${this._payloadLength}`,
                  true,
                  1002,
                  "WS_ERR_INVALID_CONTROL_PAYLOAD_LENGTH"
                );
                cb(error);
                return;
              }
            } else {
              const error = this.createError(
                RangeError,
                `invalid opcode ${this._opcode}`,
                true,
                1002,
                "WS_ERR_INVALID_OPCODE"
              );
              cb(error);
              return;
            }
            if (!this._fin && !this._fragmented) this._fragmented = this._opcode;
            this._masked = (buf[1] & 128) === 128;
            if (this._isServer) {
              if (!this._masked) {
                const error = this.createError(
                  RangeError,
                  "MASK must be set",
                  true,
                  1002,
                  "WS_ERR_EXPECTED_MASK"
                );
                cb(error);
                return;
              }
            } else if (this._masked) {
              const error = this.createError(
                RangeError,
                "MASK must be clear",
                true,
                1002,
                "WS_ERR_UNEXPECTED_MASK"
              );
              cb(error);
              return;
            }
            if (this._payloadLength === 126) this._state = GET_PAYLOAD_LENGTH_16;
            else if (this._payloadLength === 127) this._state = GET_PAYLOAD_LENGTH_64;
            else this.haveLength(cb);
          }
          /**
           * Gets extended payload length (7+16).
           *
           * @param {Function} cb Callback
           * @private
           */
          getPayloadLength16(cb) {
            if (this._bufferedBytes < 2) {
              this._loop = false;
              return;
            }
            this._payloadLength = this.consume(2).readUInt16BE(0);
            this.haveLength(cb);
          }
          /**
           * Gets extended payload length (7+64).
           *
           * @param {Function} cb Callback
           * @private
           */
          getPayloadLength64(cb) {
            if (this._bufferedBytes < 8) {
              this._loop = false;
              return;
            }
            const buf = this.consume(8);
            const num2 = buf.readUInt32BE(0);
            if (num2 > Math.pow(2, 53 - 32) - 1) {
              const error = this.createError(
                RangeError,
                "Unsupported WebSocket frame: payload length > 2^53 - 1",
                false,
                1009,
                "WS_ERR_UNSUPPORTED_DATA_PAYLOAD_LENGTH"
              );
              cb(error);
              return;
            }
            this._payloadLength = num2 * Math.pow(2, 32) + buf.readUInt32BE(4);
            this.haveLength(cb);
          }
          /**
           * Payload length has been read.
           *
           * @param {Function} cb Callback
           * @private
           */
          haveLength(cb) {
            if (this._payloadLength && this._opcode < 8) {
              this._totalPayloadLength += this._payloadLength;
              if (this._totalPayloadLength > this._maxPayload && this._maxPayload > 0) {
                const error = this.createError(
                  RangeError,
                  "Max payload size exceeded",
                  false,
                  1009,
                  "WS_ERR_UNSUPPORTED_MESSAGE_LENGTH"
                );
                cb(error);
                return;
              }
            }
            if (this._masked) this._state = GET_MASK;
            else this._state = GET_DATA;
          }
          /**
           * Reads mask bytes.
           *
           * @private
           */
          getMask() {
            if (this._bufferedBytes < 4) {
              this._loop = false;
              return;
            }
            this._mask = this.consume(4);
            this._state = GET_DATA;
          }
          /**
           * Reads data bytes.
           *
           * @param {Function} cb Callback
           * @private
           */
          getData(cb) {
            let data = EMPTY_BUFFER;
            if (this._payloadLength) {
              if (this._bufferedBytes < this._payloadLength) {
                this._loop = false;
                return;
              }
              data = this.consume(this._payloadLength);
              if (this._masked && (this._mask[0] | this._mask[1] | this._mask[2] | this._mask[3]) !== 0) {
                unmask(data, this._mask);
              }
            }
            if (this._opcode > 7) {
              this.controlMessage(data, cb);
              return;
            }
            if (this._compressed) {
              this._state = INFLATING;
              this.decompress(data, cb);
              return;
            }
            if (data.length) {
              if (this._maxFragments > 0 && this._fragments.length >= this._maxFragments) {
                const error = this.createError(
                  RangeError,
                  "Too many message fragments",
                  false,
                  1008,
                  "WS_ERR_TOO_MANY_BUFFERED_PARTS"
                );
                cb(error);
                return;
              }
              this._messageLength = this._totalPayloadLength;
              this._fragments.push(data);
            }
            this.dataMessage(cb);
          }
          /**
           * Decompresses data.
           *
           * @param {Buffer} data Compressed data
           * @param {Function} cb Callback
           * @private
           */
          decompress(data, cb) {
            const perMessageDeflate = this._extensions[PerMessageDeflate2.extensionName];
            perMessageDeflate.decompress(data, this._fin, (err, buf) => {
              if (err) return cb(err);
              if (buf.length) {
                this._messageLength += buf.length;
                if (this._messageLength > this._maxPayload && this._maxPayload > 0) {
                  const error = this.createError(
                    RangeError,
                    "Max payload size exceeded",
                    false,
                    1009,
                    "WS_ERR_UNSUPPORTED_MESSAGE_LENGTH"
                  );
                  cb(error);
                  return;
                }
                if (this._maxFragments > 0 && this._fragments.length >= this._maxFragments) {
                  const error = this.createError(
                    RangeError,
                    "Too many message fragments",
                    false,
                    1008,
                    "WS_ERR_TOO_MANY_BUFFERED_PARTS"
                  );
                  cb(error);
                  return;
                }
                this._fragments.push(buf);
              }
              this.dataMessage(cb);
              if (this._state === GET_INFO) this.startLoop(cb);
            });
          }
          /**
           * Handles a data message.
           *
           * @param {Function} cb Callback
           * @private
           */
          dataMessage(cb) {
            if (!this._fin) {
              this._state = GET_INFO;
              return;
            }
            const messageLength = this._messageLength;
            const fragments = this._fragments;
            this._totalPayloadLength = 0;
            this._messageLength = 0;
            this._fragmented = 0;
            this._fragments = [];
            if (this._opcode === 2) {
              let data;
              if (this._binaryType === "nodebuffer") {
                data = concat(fragments, messageLength);
              } else if (this._binaryType === "arraybuffer") {
                data = toArrayBuffer(concat(fragments, messageLength));
              } else if (this._binaryType === "blob") {
                data = new Blob(fragments);
              } else {
                data = fragments;
              }
              if (this._allowSynchronousEvents) {
                this.emit("message", data, true);
                this._state = GET_INFO;
              } else {
                this._state = DEFER_EVENT;
                setImmediate(() => {
                  this.emit("message", data, true);
                  this._state = GET_INFO;
                  this.startLoop(cb);
                });
              }
            } else {
              const buf = concat(fragments, messageLength);
              if (!this._skipUTF8Validation && !isValidUTF8(buf)) {
                const error = this.createError(
                  Error,
                  "invalid UTF-8 sequence",
                  true,
                  1007,
                  "WS_ERR_INVALID_UTF8"
                );
                cb(error);
                return;
              }
              if (this._state === INFLATING || this._allowSynchronousEvents) {
                this.emit("message", buf, false);
                this._state = GET_INFO;
              } else {
                this._state = DEFER_EVENT;
                setImmediate(() => {
                  this.emit("message", buf, false);
                  this._state = GET_INFO;
                  this.startLoop(cb);
                });
              }
            }
          }
          /**
           * Handles a control message.
           *
           * @param {Buffer} data Data to handle
           * @return {(Error|RangeError|undefined)} A possible error
           * @private
           */
          controlMessage(data, cb) {
            if (this._opcode === 8) {
              if (data.length === 0) {
                this._loop = false;
                this.emit("conclude", 1005, EMPTY_BUFFER);
                this.end();
              } else {
                const code2 = data.readUInt16BE(0);
                if (!isValidStatusCode(code2)) {
                  const error = this.createError(
                    RangeError,
                    `invalid status code ${code2}`,
                    true,
                    1002,
                    "WS_ERR_INVALID_CLOSE_CODE"
                  );
                  cb(error);
                  return;
                }
                const buf = new FastBuffer(
                  data.buffer,
                  data.byteOffset + 2,
                  data.length - 2
                );
                if (!this._skipUTF8Validation && !isValidUTF8(buf)) {
                  const error = this.createError(
                    Error,
                    "invalid UTF-8 sequence",
                    true,
                    1007,
                    "WS_ERR_INVALID_UTF8"
                  );
                  cb(error);
                  return;
                }
                this._loop = false;
                this.emit("conclude", code2, buf);
                this.end();
              }
              this._state = GET_INFO;
              return;
            }
            if (this._allowSynchronousEvents) {
              this.emit(this._opcode === 9 ? "ping" : "pong", data);
              this._state = GET_INFO;
            } else {
              this._state = DEFER_EVENT;
              setImmediate(() => {
                this.emit(this._opcode === 9 ? "ping" : "pong", data);
                this._state = GET_INFO;
                this.startLoop(cb);
              });
            }
          }
          /**
           * Builds an error object.
           *
           * @param {function(new:Error|RangeError)} ErrorCtor The error constructor
           * @param {String} message The error message
           * @param {Boolean} prefix Specifies whether or not to add a default prefix to
           *     `message`
           * @param {Number} statusCode The status code
           * @param {String} errorCode The exposed error code
           * @return {(Error|RangeError)} The error
           * @private
           */
          createError(ErrorCtor, message, prefix, statusCode, errorCode) {
            this._loop = false;
            this._errored = true;
            const err = new ErrorCtor(
              prefix ? `Invalid WebSocket frame: ${message}` : message
            );
            Error.captureStackTrace(err, this.createError);
            err.code = errorCode;
            err[kStatusCode] = statusCode;
            return err;
          }
        };
        module2.exports = Receiver2;
      }
    });
    require_sender = __commonJS({
      "../node_modules/.pnpm/ws@8.21.0_bufferutil@4.0.9/node_modules/ws/lib/sender.js"(exports2, module2) {
        "use strict";
        var { Duplex } = __require("stream");
        var { randomFillSync } = __require("crypto");
        var {
          types: { isUint8Array }
        } = __require("util");
        var PerMessageDeflate2 = require_permessage_deflate();
        var { EMPTY_BUFFER, kWebSocket, NOOP } = require_constants();
        var { isBlob, isValidStatusCode } = require_validation();
        var { mask: applyMask, toBuffer } = require_buffer_util();
        var kByteLength = Symbol("kByteLength");
        var maskBuffer = Buffer.alloc(4);
        var RANDOM_POOL_SIZE = 8 * 1024;
        var randomPool;
        var randomPoolPointer = RANDOM_POOL_SIZE;
        var DEFAULT = 0;
        var DEFLATING = 1;
        var GET_BLOB_DATA = 2;
        var Sender2 = class _Sender {
          /**
           * Creates a Sender instance.
           *
           * @param {Duplex} socket The connection socket
           * @param {Object} [extensions] An object containing the negotiated extensions
           * @param {Function} [generateMask] The function used to generate the masking
           *     key
           */
          constructor(socket, extensions, generateMask) {
            this._extensions = extensions || {};
            if (generateMask) {
              this._generateMask = generateMask;
              this._maskBuffer = Buffer.alloc(4);
            }
            this._socket = socket;
            this._firstFragment = true;
            this._compress = false;
            this._bufferedBytes = 0;
            this._queue = [];
            this._state = DEFAULT;
            this.onerror = NOOP;
            this[kWebSocket] = void 0;
          }
          /**
           * Frames a piece of data according to the HyBi WebSocket protocol.
           *
           * @param {(Buffer|String)} data The data to frame
           * @param {Object} options Options object
           * @param {Boolean} [options.fin=false] Specifies whether or not to set the
           *     FIN bit
           * @param {Function} [options.generateMask] The function used to generate the
           *     masking key
           * @param {Boolean} [options.mask=false] Specifies whether or not to mask
           *     `data`
           * @param {Buffer} [options.maskBuffer] The buffer used to store the masking
           *     key
           * @param {Number} options.opcode The opcode
           * @param {Boolean} [options.readOnly=false] Specifies whether `data` can be
           *     modified
           * @param {Boolean} [options.rsv1=false] Specifies whether or not to set the
           *     RSV1 bit
           * @return {(Buffer|String)[]} The framed data
           * @public
           */
          static frame(data, options) {
            let mask;
            let merge = false;
            let offset = 2;
            let skipMasking = false;
            if (options.mask) {
              mask = options.maskBuffer || maskBuffer;
              if (options.generateMask) {
                options.generateMask(mask);
              } else {
                if (randomPoolPointer === RANDOM_POOL_SIZE) {
                  if (randomPool === void 0) {
                    randomPool = Buffer.alloc(RANDOM_POOL_SIZE);
                  }
                  randomFillSync(randomPool, 0, RANDOM_POOL_SIZE);
                  randomPoolPointer = 0;
                }
                mask[0] = randomPool[randomPoolPointer++];
                mask[1] = randomPool[randomPoolPointer++];
                mask[2] = randomPool[randomPoolPointer++];
                mask[3] = randomPool[randomPoolPointer++];
              }
              skipMasking = (mask[0] | mask[1] | mask[2] | mask[3]) === 0;
              offset = 6;
            }
            let dataLength;
            if (typeof data === "string") {
              if ((!options.mask || skipMasking) && options[kByteLength] !== void 0) {
                dataLength = options[kByteLength];
              } else {
                data = Buffer.from(data);
                dataLength = data.length;
              }
            } else {
              dataLength = data.length;
              merge = options.mask && options.readOnly && !skipMasking;
            }
            let payloadLength = dataLength;
            if (dataLength >= 65536) {
              offset += 8;
              payloadLength = 127;
            } else if (dataLength > 125) {
              offset += 2;
              payloadLength = 126;
            }
            const target = Buffer.allocUnsafe(merge ? dataLength + offset : offset);
            target[0] = options.fin ? options.opcode | 128 : options.opcode;
            if (options.rsv1) target[0] |= 64;
            target[1] = payloadLength;
            if (payloadLength === 126) {
              target.writeUInt16BE(dataLength, 2);
            } else if (payloadLength === 127) {
              target[2] = target[3] = 0;
              target.writeUIntBE(dataLength, 4, 6);
            }
            if (!options.mask) return [target, data];
            target[1] |= 128;
            target[offset - 4] = mask[0];
            target[offset - 3] = mask[1];
            target[offset - 2] = mask[2];
            target[offset - 1] = mask[3];
            if (skipMasking) return [target, data];
            if (merge) {
              applyMask(data, mask, target, offset, dataLength);
              return [target];
            }
            applyMask(data, mask, data, 0, dataLength);
            return [target, data];
          }
          /**
           * Sends a close message to the other peer.
           *
           * @param {Number} [code] The status code component of the body
           * @param {(String|Buffer)} [data] The message component of the body
           * @param {Boolean} [mask=false] Specifies whether or not to mask the message
           * @param {Function} [cb] Callback
           * @public
           */
          close(code2, data, mask, cb) {
            let buf;
            if (code2 === void 0) {
              buf = EMPTY_BUFFER;
            } else if (typeof code2 !== "number" || !isValidStatusCode(code2)) {
              throw new TypeError("First argument must be a valid error code number");
            } else if (data === void 0 || !data.length) {
              buf = Buffer.allocUnsafe(2);
              buf.writeUInt16BE(code2, 0);
            } else {
              const length = Buffer.byteLength(data);
              if (length > 123) {
                throw new RangeError("The message must not be greater than 123 bytes");
              }
              buf = Buffer.allocUnsafe(2 + length);
              buf.writeUInt16BE(code2, 0);
              if (typeof data === "string") {
                buf.write(data, 2);
              } else if (isUint8Array(data)) {
                buf.set(data, 2);
              } else {
                throw new TypeError("Second argument must be a string or a Uint8Array");
              }
            }
            const options = {
              [kByteLength]: buf.length,
              fin: true,
              generateMask: this._generateMask,
              mask,
              maskBuffer: this._maskBuffer,
              opcode: 8,
              readOnly: false,
              rsv1: false
            };
            if (this._state !== DEFAULT) {
              this.enqueue([this.dispatch, buf, false, options, cb]);
            } else {
              this.sendFrame(_Sender.frame(buf, options), cb);
            }
          }
          /**
           * Sends a ping message to the other peer.
           *
           * @param {*} data The message to send
           * @param {Boolean} [mask=false] Specifies whether or not to mask `data`
           * @param {Function} [cb] Callback
           * @public
           */
          ping(data, mask, cb) {
            let byteLength2;
            let readOnly;
            if (typeof data === "string") {
              byteLength2 = Buffer.byteLength(data);
              readOnly = false;
            } else if (isBlob(data)) {
              byteLength2 = data.size;
              readOnly = false;
            } else {
              data = toBuffer(data);
              byteLength2 = data.length;
              readOnly = toBuffer.readOnly;
            }
            if (byteLength2 > 125) {
              throw new RangeError("The data size must not be greater than 125 bytes");
            }
            const options = {
              [kByteLength]: byteLength2,
              fin: true,
              generateMask: this._generateMask,
              mask,
              maskBuffer: this._maskBuffer,
              opcode: 9,
              readOnly,
              rsv1: false
            };
            if (isBlob(data)) {
              if (this._state !== DEFAULT) {
                this.enqueue([this.getBlobData, data, false, options, cb]);
              } else {
                this.getBlobData(data, false, options, cb);
              }
            } else if (this._state !== DEFAULT) {
              this.enqueue([this.dispatch, data, false, options, cb]);
            } else {
              this.sendFrame(_Sender.frame(data, options), cb);
            }
          }
          /**
           * Sends a pong message to the other peer.
           *
           * @param {*} data The message to send
           * @param {Boolean} [mask=false] Specifies whether or not to mask `data`
           * @param {Function} [cb] Callback
           * @public
           */
          pong(data, mask, cb) {
            let byteLength2;
            let readOnly;
            if (typeof data === "string") {
              byteLength2 = Buffer.byteLength(data);
              readOnly = false;
            } else if (isBlob(data)) {
              byteLength2 = data.size;
              readOnly = false;
            } else {
              data = toBuffer(data);
              byteLength2 = data.length;
              readOnly = toBuffer.readOnly;
            }
            if (byteLength2 > 125) {
              throw new RangeError("The data size must not be greater than 125 bytes");
            }
            const options = {
              [kByteLength]: byteLength2,
              fin: true,
              generateMask: this._generateMask,
              mask,
              maskBuffer: this._maskBuffer,
              opcode: 10,
              readOnly,
              rsv1: false
            };
            if (isBlob(data)) {
              if (this._state !== DEFAULT) {
                this.enqueue([this.getBlobData, data, false, options, cb]);
              } else {
                this.getBlobData(data, false, options, cb);
              }
            } else if (this._state !== DEFAULT) {
              this.enqueue([this.dispatch, data, false, options, cb]);
            } else {
              this.sendFrame(_Sender.frame(data, options), cb);
            }
          }
          /**
           * Sends a data message to the other peer.
           *
           * @param {*} data The message to send
           * @param {Object} options Options object
           * @param {Boolean} [options.binary=false] Specifies whether `data` is binary
           *     or text
           * @param {Boolean} [options.compress=false] Specifies whether or not to
           *     compress `data`
           * @param {Boolean} [options.fin=false] Specifies whether the fragment is the
           *     last one
           * @param {Boolean} [options.mask=false] Specifies whether or not to mask
           *     `data`
           * @param {Function} [cb] Callback
           * @public
           */
          send(data, options, cb) {
            const perMessageDeflate = this._extensions[PerMessageDeflate2.extensionName];
            let opcode = options.binary ? 2 : 1;
            let rsv1 = options.compress;
            let byteLength2;
            let readOnly;
            if (typeof data === "string") {
              byteLength2 = Buffer.byteLength(data);
              readOnly = false;
            } else if (isBlob(data)) {
              byteLength2 = data.size;
              readOnly = false;
            } else {
              data = toBuffer(data);
              byteLength2 = data.length;
              readOnly = toBuffer.readOnly;
            }
            if (this._firstFragment) {
              this._firstFragment = false;
              if (rsv1 && perMessageDeflate && perMessageDeflate.params[perMessageDeflate._isServer ? "server_no_context_takeover" : "client_no_context_takeover"]) {
                rsv1 = byteLength2 >= perMessageDeflate._threshold;
              }
              this._compress = rsv1;
            } else {
              rsv1 = false;
              opcode = 0;
            }
            if (options.fin) this._firstFragment = true;
            const opts = {
              [kByteLength]: byteLength2,
              fin: options.fin,
              generateMask: this._generateMask,
              mask: options.mask,
              maskBuffer: this._maskBuffer,
              opcode,
              readOnly,
              rsv1
            };
            if (isBlob(data)) {
              if (this._state !== DEFAULT) {
                this.enqueue([this.getBlobData, data, this._compress, opts, cb]);
              } else {
                this.getBlobData(data, this._compress, opts, cb);
              }
            } else if (this._state !== DEFAULT) {
              this.enqueue([this.dispatch, data, this._compress, opts, cb]);
            } else {
              this.dispatch(data, this._compress, opts, cb);
            }
          }
          /**
           * Gets the contents of a blob as binary data.
           *
           * @param {Blob} blob The blob
           * @param {Boolean} [compress=false] Specifies whether or not to compress
           *     the data
           * @param {Object} options Options object
           * @param {Boolean} [options.fin=false] Specifies whether or not to set the
           *     FIN bit
           * @param {Function} [options.generateMask] The function used to generate the
           *     masking key
           * @param {Boolean} [options.mask=false] Specifies whether or not to mask
           *     `data`
           * @param {Buffer} [options.maskBuffer] The buffer used to store the masking
           *     key
           * @param {Number} options.opcode The opcode
           * @param {Boolean} [options.readOnly=false] Specifies whether `data` can be
           *     modified
           * @param {Boolean} [options.rsv1=false] Specifies whether or not to set the
           *     RSV1 bit
           * @param {Function} [cb] Callback
           * @private
           */
          getBlobData(blob, compress, options, cb) {
            this._bufferedBytes += options[kByteLength];
            this._state = GET_BLOB_DATA;
            blob.arrayBuffer().then((arrayBuffer) => {
              if (this._socket.destroyed) {
                const err = new Error(
                  "The socket was closed while the blob was being read"
                );
                process.nextTick(callCallbacks, this, err, cb);
                return;
              }
              this._bufferedBytes -= options[kByteLength];
              const data = toBuffer(arrayBuffer);
              if (!compress) {
                this._state = DEFAULT;
                this.sendFrame(_Sender.frame(data, options), cb);
                this.dequeue();
              } else {
                this.dispatch(data, compress, options, cb);
              }
            }).catch((err) => {
              process.nextTick(onError, this, err, cb);
            });
          }
          /**
           * Dispatches a message.
           *
           * @param {(Buffer|String)} data The message to send
           * @param {Boolean} [compress=false] Specifies whether or not to compress
           *     `data`
           * @param {Object} options Options object
           * @param {Boolean} [options.fin=false] Specifies whether or not to set the
           *     FIN bit
           * @param {Function} [options.generateMask] The function used to generate the
           *     masking key
           * @param {Boolean} [options.mask=false] Specifies whether or not to mask
           *     `data`
           * @param {Buffer} [options.maskBuffer] The buffer used to store the masking
           *     key
           * @param {Number} options.opcode The opcode
           * @param {Boolean} [options.readOnly=false] Specifies whether `data` can be
           *     modified
           * @param {Boolean} [options.rsv1=false] Specifies whether or not to set the
           *     RSV1 bit
           * @param {Function} [cb] Callback
           * @private
           */
          dispatch(data, compress, options, cb) {
            if (!compress) {
              this.sendFrame(_Sender.frame(data, options), cb);
              return;
            }
            const perMessageDeflate = this._extensions[PerMessageDeflate2.extensionName];
            this._bufferedBytes += options[kByteLength];
            this._state = DEFLATING;
            perMessageDeflate.compress(data, options.fin, (_, buf) => {
              if (this._socket.destroyed) {
                const err = new Error(
                  "The socket was closed while data was being compressed"
                );
                callCallbacks(this, err, cb);
                return;
              }
              this._bufferedBytes -= options[kByteLength];
              this._state = DEFAULT;
              options.readOnly = false;
              this.sendFrame(_Sender.frame(buf, options), cb);
              this.dequeue();
            });
          }
          /**
           * Executes queued send operations.
           *
           * @private
           */
          dequeue() {
            while (this._state === DEFAULT && this._queue.length) {
              const params = this._queue.shift();
              this._bufferedBytes -= params[3][kByteLength];
              Reflect.apply(params[0], this, params.slice(1));
            }
          }
          /**
           * Enqueues a send operation.
           *
           * @param {Array} params Send operation parameters.
           * @private
           */
          enqueue(params) {
            this._bufferedBytes += params[3][kByteLength];
            this._queue.push(params);
          }
          /**
           * Sends a frame.
           *
           * @param {(Buffer | String)[]} list The frame to send
           * @param {Function} [cb] Callback
           * @private
           */
          sendFrame(list, cb) {
            if (list.length === 2) {
              this._socket.cork();
              this._socket.write(list[0]);
              this._socket.write(list[1], cb);
              this._socket.uncork();
            } else {
              this._socket.write(list[0], cb);
            }
          }
        };
        module2.exports = Sender2;
        function callCallbacks(sender, err, cb) {
          if (typeof cb === "function") cb(err);
          for (let i = 0; i < sender._queue.length; i++) {
            const params = sender._queue[i];
            const callback = params[params.length - 1];
            if (typeof callback === "function") callback(err);
          }
        }
        function onError(sender, err, cb) {
          callCallbacks(sender, err, cb);
          sender.onerror(err);
        }
      }
    });
    require_event_target = __commonJS({
      "../node_modules/.pnpm/ws@8.21.0_bufferutil@4.0.9/node_modules/ws/lib/event-target.js"(exports2, module2) {
        "use strict";
        var { kForOnEventAttribute, kListener } = require_constants();
        var kCode = Symbol("kCode");
        var kData = Symbol("kData");
        var kError = Symbol("kError");
        var kMessage = Symbol("kMessage");
        var kReason = Symbol("kReason");
        var kTarget = Symbol("kTarget");
        var kType = Symbol("kType");
        var kWasClean = Symbol("kWasClean");
        var Event = class {
          /**
           * Create a new `Event`.
           *
           * @param {String} type The name of the event
           * @throws {TypeError} If the `type` argument is not specified
           */
          constructor(type) {
            this[kTarget] = null;
            this[kType] = type;
          }
          /**
           * @type {*}
           */
          get target() {
            return this[kTarget];
          }
          /**
           * @type {String}
           */
          get type() {
            return this[kType];
          }
        };
        Object.defineProperty(Event.prototype, "target", { enumerable: true });
        Object.defineProperty(Event.prototype, "type", { enumerable: true });
        var CloseEvent = class extends Event {
          /**
           * Create a new `CloseEvent`.
           *
           * @param {String} type The name of the event
           * @param {Object} [options] A dictionary object that allows for setting
           *     attributes via object members of the same name
           * @param {Number} [options.code=0] The status code explaining why the
           *     connection was closed
           * @param {String} [options.reason=''] A human-readable string explaining why
           *     the connection was closed
           * @param {Boolean} [options.wasClean=false] Indicates whether or not the
           *     connection was cleanly closed
           */
          constructor(type, options = {}) {
            super(type);
            this[kCode] = options.code === void 0 ? 0 : options.code;
            this[kReason] = options.reason === void 0 ? "" : options.reason;
            this[kWasClean] = options.wasClean === void 0 ? false : options.wasClean;
          }
          /**
           * @type {Number}
           */
          get code() {
            return this[kCode];
          }
          /**
           * @type {String}
           */
          get reason() {
            return this[kReason];
          }
          /**
           * @type {Boolean}
           */
          get wasClean() {
            return this[kWasClean];
          }
        };
        Object.defineProperty(CloseEvent.prototype, "code", { enumerable: true });
        Object.defineProperty(CloseEvent.prototype, "reason", { enumerable: true });
        Object.defineProperty(CloseEvent.prototype, "wasClean", { enumerable: true });
        var ErrorEvent = class extends Event {
          /**
           * Create a new `ErrorEvent`.
           *
           * @param {String} type The name of the event
           * @param {Object} [options] A dictionary object that allows for setting
           *     attributes via object members of the same name
           * @param {*} [options.error=null] The error that generated this event
           * @param {String} [options.message=''] The error message
           */
          constructor(type, options = {}) {
            super(type);
            this[kError] = options.error === void 0 ? null : options.error;
            this[kMessage] = options.message === void 0 ? "" : options.message;
          }
          /**
           * @type {*}
           */
          get error() {
            return this[kError];
          }
          /**
           * @type {String}
           */
          get message() {
            return this[kMessage];
          }
        };
        Object.defineProperty(ErrorEvent.prototype, "error", { enumerable: true });
        Object.defineProperty(ErrorEvent.prototype, "message", { enumerable: true });
        var MessageEvent = class extends Event {
          /**
           * Create a new `MessageEvent`.
           *
           * @param {String} type The name of the event
           * @param {Object} [options] A dictionary object that allows for setting
           *     attributes via object members of the same name
           * @param {*} [options.data=null] The message content
           */
          constructor(type, options = {}) {
            super(type);
            this[kData] = options.data === void 0 ? null : options.data;
          }
          /**
           * @type {*}
           */
          get data() {
            return this[kData];
          }
        };
        Object.defineProperty(MessageEvent.prototype, "data", { enumerable: true });
        var EventTarget = {
          /**
           * Register an event listener.
           *
           * @param {String} type A string representing the event type to listen for
           * @param {(Function|Object)} handler The listener to add
           * @param {Object} [options] An options object specifies characteristics about
           *     the event listener
           * @param {Boolean} [options.once=false] A `Boolean` indicating that the
           *     listener should be invoked at most once after being added. If `true`,
           *     the listener would be automatically removed when invoked.
           * @public
           */
          addEventListener(type, handler, options = {}) {
            for (const listener of this.listeners(type)) {
              if (!options[kForOnEventAttribute] && listener[kListener] === handler && !listener[kForOnEventAttribute]) {
                return;
              }
            }
            let wrapper;
            if (type === "message") {
              wrapper = function onMessage(data, isBinary) {
                const event = new MessageEvent("message", {
                  data: isBinary ? data : data.toString()
                });
                event[kTarget] = this;
                callListener(handler, this, event);
              };
            } else if (type === "close") {
              wrapper = function onClose(code2, message) {
                const event = new CloseEvent("close", {
                  code: code2,
                  reason: message.toString(),
                  wasClean: this._closeFrameReceived && this._closeFrameSent
                });
                event[kTarget] = this;
                callListener(handler, this, event);
              };
            } else if (type === "error") {
              wrapper = function onError(error) {
                const event = new ErrorEvent("error", {
                  error,
                  message: error.message
                });
                event[kTarget] = this;
                callListener(handler, this, event);
              };
            } else if (type === "open") {
              wrapper = function onOpen() {
                const event = new Event("open");
                event[kTarget] = this;
                callListener(handler, this, event);
              };
            } else {
              return;
            }
            wrapper[kForOnEventAttribute] = !!options[kForOnEventAttribute];
            wrapper[kListener] = handler;
            if (options.once) {
              this.once(type, wrapper);
            } else {
              this.on(type, wrapper);
            }
          },
          /**
           * Remove an event listener.
           *
           * @param {String} type A string representing the event type to remove
           * @param {(Function|Object)} handler The listener to remove
           * @public
           */
          removeEventListener(type, handler) {
            for (const listener of this.listeners(type)) {
              if (listener[kListener] === handler && !listener[kForOnEventAttribute]) {
                this.removeListener(type, listener);
                break;
              }
            }
          }
        };
        module2.exports = {
          CloseEvent,
          ErrorEvent,
          Event,
          EventTarget,
          MessageEvent
        };
        function callListener(listener, thisArg, event) {
          if (typeof listener === "object" && listener.handleEvent) {
            listener.handleEvent.call(listener, event);
          } else {
            listener.call(thisArg, event);
          }
        }
      }
    });
    require_extension = __commonJS({
      "../node_modules/.pnpm/ws@8.21.0_bufferutil@4.0.9/node_modules/ws/lib/extension.js"(exports2, module2) {
        "use strict";
        var { tokenChars } = require_validation();
        function push(dest, name, elem) {
          if (dest[name] === void 0) dest[name] = [elem];
          else dest[name].push(elem);
        }
        function parse(header) {
          const offers = /* @__PURE__ */ Object.create(null);
          let params = /* @__PURE__ */ Object.create(null);
          let mustUnescape = false;
          let isEscaping = false;
          let inQuotes = false;
          let extensionName;
          let paramName;
          let start = -1;
          let code2 = -1;
          let end = -1;
          let i = 0;
          for (; i < header.length; i++) {
            code2 = header.charCodeAt(i);
            if (extensionName === void 0) {
              if (end === -1 && tokenChars[code2] === 1) {
                if (start === -1) start = i;
              } else if (i !== 0 && (code2 === 32 || code2 === 9)) {
                if (end === -1 && start !== -1) end = i;
              } else if (code2 === 59 || code2 === 44) {
                if (start === -1) {
                  throw new SyntaxError(`Unexpected character at index ${i}`);
                }
                if (end === -1) end = i;
                const name = header.slice(start, end);
                if (code2 === 44) {
                  push(offers, name, params);
                  params = /* @__PURE__ */ Object.create(null);
                } else {
                  extensionName = name;
                }
                start = end = -1;
              } else {
                throw new SyntaxError(`Unexpected character at index ${i}`);
              }
            } else if (paramName === void 0) {
              if (end === -1 && tokenChars[code2] === 1) {
                if (start === -1) start = i;
              } else if (code2 === 32 || code2 === 9) {
                if (end === -1 && start !== -1) end = i;
              } else if (code2 === 59 || code2 === 44) {
                if (start === -1) {
                  throw new SyntaxError(`Unexpected character at index ${i}`);
                }
                if (end === -1) end = i;
                push(params, header.slice(start, end), true);
                if (code2 === 44) {
                  push(offers, extensionName, params);
                  params = /* @__PURE__ */ Object.create(null);
                  extensionName = void 0;
                }
                start = end = -1;
              } else if (code2 === 61 && start !== -1 && end === -1) {
                paramName = header.slice(start, i);
                start = end = -1;
              } else {
                throw new SyntaxError(`Unexpected character at index ${i}`);
              }
            } else {
              if (isEscaping) {
                if (tokenChars[code2] !== 1) {
                  throw new SyntaxError(`Unexpected character at index ${i}`);
                }
                if (start === -1) start = i;
                else if (!mustUnescape) mustUnescape = true;
                isEscaping = false;
              } else if (inQuotes) {
                if (tokenChars[code2] === 1) {
                  if (start === -1) start = i;
                } else if (code2 === 34 && start !== -1) {
                  inQuotes = false;
                  end = i;
                } else if (code2 === 92) {
                  isEscaping = true;
                } else {
                  throw new SyntaxError(`Unexpected character at index ${i}`);
                }
              } else if (code2 === 34 && header.charCodeAt(i - 1) === 61) {
                inQuotes = true;
              } else if (end === -1 && tokenChars[code2] === 1) {
                if (start === -1) start = i;
              } else if (start !== -1 && (code2 === 32 || code2 === 9)) {
                if (end === -1) end = i;
              } else if (code2 === 59 || code2 === 44) {
                if (start === -1) {
                  throw new SyntaxError(`Unexpected character at index ${i}`);
                }
                if (end === -1) end = i;
                let value = header.slice(start, end);
                if (mustUnescape) {
                  value = value.replace(/\\/g, "");
                  mustUnescape = false;
                }
                push(params, paramName, value);
                if (code2 === 44) {
                  push(offers, extensionName, params);
                  params = /* @__PURE__ */ Object.create(null);
                  extensionName = void 0;
                }
                paramName = void 0;
                start = end = -1;
              } else {
                throw new SyntaxError(`Unexpected character at index ${i}`);
              }
            }
          }
          if (start === -1 || inQuotes || code2 === 32 || code2 === 9) {
            throw new SyntaxError("Unexpected end of input");
          }
          if (end === -1) end = i;
          const token = header.slice(start, end);
          if (extensionName === void 0) {
            push(offers, token, params);
          } else {
            if (paramName === void 0) {
              push(params, token, true);
            } else if (mustUnescape) {
              push(params, paramName, token.replace(/\\/g, ""));
            } else {
              push(params, paramName, token);
            }
            push(offers, extensionName, params);
          }
          return offers;
        }
        function format(extensions) {
          return Object.keys(extensions).map((extension2) => {
            let configurations = extensions[extension2];
            if (!Array.isArray(configurations)) configurations = [configurations];
            return configurations.map((params) => {
              return [extension2].concat(
                Object.keys(params).map((k) => {
                  let values = params[k];
                  if (!Array.isArray(values)) values = [values];
                  return values.map((v2) => v2 === true ? k : `${k}=${v2}`).join("; ");
                })
              ).join("; ");
            }).join(", ");
          }).join(", ");
        }
        module2.exports = { format, parse };
      }
    });
    require_websocket = __commonJS({
      "../node_modules/.pnpm/ws@8.21.0_bufferutil@4.0.9/node_modules/ws/lib/websocket.js"(exports2, module2) {
        "use strict";
        var EventEmitter = __require("events");
        var https = __require("https");
        var http = __require("http");
        var net = __require("net");
        var tls = __require("tls");
        var { randomBytes, createHash } = __require("crypto");
        var { Duplex, Readable } = __require("stream");
        var { URL: URL2 } = __require("url");
        var PerMessageDeflate2 = require_permessage_deflate();
        var Receiver2 = require_receiver();
        var Sender2 = require_sender();
        var { isBlob } = require_validation();
        var {
          BINARY_TYPES,
          CLOSE_TIMEOUT,
          EMPTY_BUFFER,
          GUID,
          kForOnEventAttribute,
          kListener,
          kStatusCode,
          kWebSocket,
          NOOP
        } = require_constants();
        var {
          EventTarget: { addEventListener, removeEventListener }
        } = require_event_target();
        var { format, parse } = require_extension();
        var { toBuffer } = require_buffer_util();
        var kAborted = Symbol("kAborted");
        var protocolVersions = [8, 13];
        var readyStates = ["CONNECTING", "OPEN", "CLOSING", "CLOSED"];
        var subprotocolRegex = /^[!#$%&'*+\-.0-9A-Z^_`|a-z~]+$/;
        var WebSocket2 = class _WebSocket extends EventEmitter {
          /**
           * Create a new `WebSocket`.
           *
           * @param {(String|URL)} address The URL to which to connect
           * @param {(String|String[])} [protocols] The subprotocols
           * @param {Object} [options] Connection options
           */
          constructor(address, protocols, options) {
            super();
            this._binaryType = BINARY_TYPES[0];
            this._closeCode = 1006;
            this._closeFrameReceived = false;
            this._closeFrameSent = false;
            this._closeMessage = EMPTY_BUFFER;
            this._closeTimer = null;
            this._errorEmitted = false;
            this._extensions = {};
            this._paused = false;
            this._protocol = "";
            this._readyState = _WebSocket.CONNECTING;
            this._receiver = null;
            this._sender = null;
            this._socket = null;
            if (address !== null) {
              this._bufferedAmount = 0;
              this._isServer = false;
              this._redirects = 0;
              if (protocols === void 0) {
                protocols = [];
              } else if (!Array.isArray(protocols)) {
                if (typeof protocols === "object" && protocols !== null) {
                  options = protocols;
                  protocols = [];
                } else {
                  protocols = [protocols];
                }
              }
              initAsClient(this, address, protocols, options);
            } else {
              this._autoPong = options.autoPong;
              this._closeTimeout = options.closeTimeout;
              this._isServer = true;
            }
          }
          /**
           * For historical reasons, the custom "nodebuffer" type is used by the default
           * instead of "blob".
           *
           * @type {String}
           */
          get binaryType() {
            return this._binaryType;
          }
          set binaryType(type) {
            if (!BINARY_TYPES.includes(type)) return;
            this._binaryType = type;
            if (this._receiver) this._receiver._binaryType = type;
          }
          /**
           * @type {Number}
           */
          get bufferedAmount() {
            if (!this._socket) return this._bufferedAmount;
            return this._socket._writableState.length + this._sender._bufferedBytes;
          }
          /**
           * @type {String}
           */
          get extensions() {
            return Object.keys(this._extensions).join();
          }
          /**
           * @type {Boolean}
           */
          get isPaused() {
            return this._paused;
          }
          /**
           * @type {Function}
           */
          /* istanbul ignore next */
          get onclose() {
            return null;
          }
          /**
           * @type {Function}
           */
          /* istanbul ignore next */
          get onerror() {
            return null;
          }
          /**
           * @type {Function}
           */
          /* istanbul ignore next */
          get onopen() {
            return null;
          }
          /**
           * @type {Function}
           */
          /* istanbul ignore next */
          get onmessage() {
            return null;
          }
          /**
           * @type {String}
           */
          get protocol() {
            return this._protocol;
          }
          /**
           * @type {Number}
           */
          get readyState() {
            return this._readyState;
          }
          /**
           * @type {String}
           */
          get url() {
            return this._url;
          }
          /**
           * Set up the socket and the internal resources.
           *
           * @param {Duplex} socket The network socket between the server and client
           * @param {Buffer} head The first packet of the upgraded stream
           * @param {Object} options Options object
           * @param {Boolean} [options.allowSynchronousEvents=false] Specifies whether
           *     any of the `'message'`, `'ping'`, and `'pong'` events can be emitted
           *     multiple times in the same tick
           * @param {Function} [options.generateMask] The function used to generate the
           *     masking key
           * @param {Number} [options.maxBufferedChunks=0] The maximum number of
           *     buffered data chunks
           * @param {Number} [options.maxFragments=0] The maximum number of message
           *     fragments
           * @param {Number} [options.maxPayload=0] The maximum allowed message size
           * @param {Boolean} [options.skipUTF8Validation=false] Specifies whether or
           *     not to skip UTF-8 validation for text and close messages
           * @private
           */
          setSocket(socket, head, options) {
            const receiver = new Receiver2({
              allowSynchronousEvents: options.allowSynchronousEvents,
              binaryType: this.binaryType,
              extensions: this._extensions,
              isServer: this._isServer,
              maxBufferedChunks: options.maxBufferedChunks,
              maxFragments: options.maxFragments,
              maxPayload: options.maxPayload,
              skipUTF8Validation: options.skipUTF8Validation
            });
            const sender = new Sender2(socket, this._extensions, options.generateMask);
            this._receiver = receiver;
            this._sender = sender;
            this._socket = socket;
            receiver[kWebSocket] = this;
            sender[kWebSocket] = this;
            socket[kWebSocket] = this;
            receiver.on("conclude", receiverOnConclude);
            receiver.on("drain", receiverOnDrain);
            receiver.on("error", receiverOnError);
            receiver.on("message", receiverOnMessage);
            receiver.on("ping", receiverOnPing);
            receiver.on("pong", receiverOnPong);
            sender.onerror = senderOnError;
            if (socket.setTimeout) socket.setTimeout(0);
            if (socket.setNoDelay) socket.setNoDelay();
            if (head.length > 0) socket.unshift(head);
            socket.on("close", socketOnClose);
            socket.on("data", socketOnData);
            socket.on("end", socketOnEnd);
            socket.on("error", socketOnError);
            this._readyState = _WebSocket.OPEN;
            this.emit("open");
          }
          /**
           * Emit the `'close'` event.
           *
           * @private
           */
          emitClose() {
            if (!this._socket) {
              this._readyState = _WebSocket.CLOSED;
              this.emit("close", this._closeCode, this._closeMessage);
              return;
            }
            if (this._extensions[PerMessageDeflate2.extensionName]) {
              this._extensions[PerMessageDeflate2.extensionName].cleanup();
            }
            this._receiver.removeAllListeners();
            this._readyState = _WebSocket.CLOSED;
            this.emit("close", this._closeCode, this._closeMessage);
          }
          /**
           * Start a closing handshake.
           *
           *          +----------+   +-----------+   +----------+
           *     - - -|ws.close()|-->|close frame|-->|ws.close()|- - -
           *    |     +----------+   +-----------+   +----------+     |
           *          +----------+   +-----------+         |
           * CLOSING  |ws.close()|<--|close frame|<--+-----+       CLOSING
           *          +----------+   +-----------+   |
           *    |           |                        |   +---+        |
           *                +------------------------+-->|fin| - - - -
           *    |         +---+                      |   +---+
           *     - - - - -|fin|<---------------------+
           *              +---+
           *
           * @param {Number} [code] Status code explaining why the connection is closing
           * @param {(String|Buffer)} [data] The reason why the connection is
           *     closing
           * @public
           */
          close(code2, data) {
            if (this.readyState === _WebSocket.CLOSED) return;
            if (this.readyState === _WebSocket.CONNECTING) {
              const msg = "WebSocket was closed before the connection was established";
              abortHandshake(this, this._req, msg);
              return;
            }
            if (this.readyState === _WebSocket.CLOSING) {
              if (this._closeFrameSent && (this._closeFrameReceived || this._receiver._writableState.errorEmitted)) {
                this._socket.end();
              }
              return;
            }
            this._readyState = _WebSocket.CLOSING;
            this._sender.close(code2, data, !this._isServer, (err) => {
              if (err) return;
              this._closeFrameSent = true;
              if (this._closeFrameReceived || this._receiver._writableState.errorEmitted) {
                this._socket.end();
              }
            });
            setCloseTimer(this);
          }
          /**
           * Pause the socket.
           *
           * @public
           */
          pause() {
            if (this.readyState === _WebSocket.CONNECTING || this.readyState === _WebSocket.CLOSED) {
              return;
            }
            this._paused = true;
            this._socket.pause();
          }
          /**
           * Send a ping.
           *
           * @param {*} [data] The data to send
           * @param {Boolean} [mask] Indicates whether or not to mask `data`
           * @param {Function} [cb] Callback which is executed when the ping is sent
           * @public
           */
          ping(data, mask, cb) {
            if (this.readyState === _WebSocket.CONNECTING) {
              throw new Error("WebSocket is not open: readyState 0 (CONNECTING)");
            }
            if (typeof data === "function") {
              cb = data;
              data = mask = void 0;
            } else if (typeof mask === "function") {
              cb = mask;
              mask = void 0;
            }
            if (typeof data === "number") data = data.toString();
            if (this.readyState !== _WebSocket.OPEN) {
              sendAfterClose(this, data, cb);
              return;
            }
            if (mask === void 0) mask = !this._isServer;
            this._sender.ping(data || EMPTY_BUFFER, mask, cb);
          }
          /**
           * Send a pong.
           *
           * @param {*} [data] The data to send
           * @param {Boolean} [mask] Indicates whether or not to mask `data`
           * @param {Function} [cb] Callback which is executed when the pong is sent
           * @public
           */
          pong(data, mask, cb) {
            if (this.readyState === _WebSocket.CONNECTING) {
              throw new Error("WebSocket is not open: readyState 0 (CONNECTING)");
            }
            if (typeof data === "function") {
              cb = data;
              data = mask = void 0;
            } else if (typeof mask === "function") {
              cb = mask;
              mask = void 0;
            }
            if (typeof data === "number") data = data.toString();
            if (this.readyState !== _WebSocket.OPEN) {
              sendAfterClose(this, data, cb);
              return;
            }
            if (mask === void 0) mask = !this._isServer;
            this._sender.pong(data || EMPTY_BUFFER, mask, cb);
          }
          /**
           * Resume the socket.
           *
           * @public
           */
          resume() {
            if (this.readyState === _WebSocket.CONNECTING || this.readyState === _WebSocket.CLOSED) {
              return;
            }
            this._paused = false;
            if (!this._receiver._writableState.needDrain) this._socket.resume();
          }
          /**
           * Send a data message.
           *
           * @param {*} data The message to send
           * @param {Object} [options] Options object
           * @param {Boolean} [options.binary] Specifies whether `data` is binary or
           *     text
           * @param {Boolean} [options.compress] Specifies whether or not to compress
           *     `data`
           * @param {Boolean} [options.fin=true] Specifies whether the fragment is the
           *     last one
           * @param {Boolean} [options.mask] Specifies whether or not to mask `data`
           * @param {Function} [cb] Callback which is executed when data is written out
           * @public
           */
          send(data, options, cb) {
            if (this.readyState === _WebSocket.CONNECTING) {
              throw new Error("WebSocket is not open: readyState 0 (CONNECTING)");
            }
            if (typeof options === "function") {
              cb = options;
              options = {};
            }
            if (typeof data === "number") data = data.toString();
            if (this.readyState !== _WebSocket.OPEN) {
              sendAfterClose(this, data, cb);
              return;
            }
            const opts = {
              binary: typeof data !== "string",
              mask: !this._isServer,
              compress: true,
              fin: true,
              ...options
            };
            if (!this._extensions[PerMessageDeflate2.extensionName]) {
              opts.compress = false;
            }
            this._sender.send(data || EMPTY_BUFFER, opts, cb);
          }
          /**
           * Forcibly close the connection.
           *
           * @public
           */
          terminate() {
            if (this.readyState === _WebSocket.CLOSED) return;
            if (this.readyState === _WebSocket.CONNECTING) {
              const msg = "WebSocket was closed before the connection was established";
              abortHandshake(this, this._req, msg);
              return;
            }
            if (this._socket) {
              this._readyState = _WebSocket.CLOSING;
              this._socket.destroy();
            }
          }
        };
        Object.defineProperty(WebSocket2, "CONNECTING", {
          enumerable: true,
          value: readyStates.indexOf("CONNECTING")
        });
        Object.defineProperty(WebSocket2.prototype, "CONNECTING", {
          enumerable: true,
          value: readyStates.indexOf("CONNECTING")
        });
        Object.defineProperty(WebSocket2, "OPEN", {
          enumerable: true,
          value: readyStates.indexOf("OPEN")
        });
        Object.defineProperty(WebSocket2.prototype, "OPEN", {
          enumerable: true,
          value: readyStates.indexOf("OPEN")
        });
        Object.defineProperty(WebSocket2, "CLOSING", {
          enumerable: true,
          value: readyStates.indexOf("CLOSING")
        });
        Object.defineProperty(WebSocket2.prototype, "CLOSING", {
          enumerable: true,
          value: readyStates.indexOf("CLOSING")
        });
        Object.defineProperty(WebSocket2, "CLOSED", {
          enumerable: true,
          value: readyStates.indexOf("CLOSED")
        });
        Object.defineProperty(WebSocket2.prototype, "CLOSED", {
          enumerable: true,
          value: readyStates.indexOf("CLOSED")
        });
        [
          "binaryType",
          "bufferedAmount",
          "extensions",
          "isPaused",
          "protocol",
          "readyState",
          "url"
        ].forEach((property) => {
          Object.defineProperty(WebSocket2.prototype, property, { enumerable: true });
        });
        ["open", "error", "close", "message"].forEach((method) => {
          Object.defineProperty(WebSocket2.prototype, `on${method}`, {
            enumerable: true,
            get() {
              for (const listener of this.listeners(method)) {
                if (listener[kForOnEventAttribute]) return listener[kListener];
              }
              return null;
            },
            set(handler) {
              for (const listener of this.listeners(method)) {
                if (listener[kForOnEventAttribute]) {
                  this.removeListener(method, listener);
                  break;
                }
              }
              if (typeof handler !== "function") return;
              this.addEventListener(method, handler, {
                [kForOnEventAttribute]: true
              });
            }
          });
        });
        WebSocket2.prototype.addEventListener = addEventListener;
        WebSocket2.prototype.removeEventListener = removeEventListener;
        module2.exports = WebSocket2;
        function initAsClient(websocket, address, protocols, options) {
          const opts = {
            allowSynchronousEvents: true,
            autoPong: true,
            closeTimeout: CLOSE_TIMEOUT,
            protocolVersion: protocolVersions[1],
            maxBufferedChunks: 1024 * 1024,
            maxFragments: 128 * 1024,
            maxPayload: 100 * 1024 * 1024,
            skipUTF8Validation: false,
            perMessageDeflate: true,
            followRedirects: false,
            maxRedirects: 10,
            ...options,
            socketPath: void 0,
            hostname: void 0,
            protocol: void 0,
            timeout: void 0,
            method: "GET",
            host: void 0,
            path: void 0,
            port: void 0
          };
          websocket._autoPong = opts.autoPong;
          websocket._closeTimeout = opts.closeTimeout;
          if (!protocolVersions.includes(opts.protocolVersion)) {
            throw new RangeError(
              `Unsupported protocol version: ${opts.protocolVersion} (supported versions: ${protocolVersions.join(", ")})`
            );
          }
          let parsedUrl;
          if (address instanceof URL2) {
            parsedUrl = address;
          } else {
            try {
              parsedUrl = new URL2(address);
            } catch {
              throw new SyntaxError(`Invalid URL: ${address}`);
            }
          }
          if (parsedUrl.protocol === "http:") {
            parsedUrl.protocol = "ws:";
          } else if (parsedUrl.protocol === "https:") {
            parsedUrl.protocol = "wss:";
          }
          websocket._url = parsedUrl.href;
          const isSecure = parsedUrl.protocol === "wss:";
          const isIpcUrl = parsedUrl.protocol === "ws+unix:";
          let invalidUrlMessage;
          if (parsedUrl.protocol !== "ws:" && !isSecure && !isIpcUrl) {
            invalidUrlMessage = `The URL's protocol must be one of "ws:", "wss:", "http:", "https:", or "ws+unix:"`;
          } else if (isIpcUrl && !parsedUrl.pathname) {
            invalidUrlMessage = "The URL's pathname is empty";
          } else if (parsedUrl.hash) {
            invalidUrlMessage = "The URL contains a fragment identifier";
          }
          if (invalidUrlMessage) {
            const err = new SyntaxError(invalidUrlMessage);
            if (websocket._redirects === 0) {
              throw err;
            } else {
              emitErrorAndClose(websocket, err);
              return;
            }
          }
          const defaultPort = isSecure ? 443 : 80;
          const key = randomBytes(16).toString("base64");
          const request = isSecure ? https.request : http.request;
          const protocolSet = /* @__PURE__ */ new Set();
          let perMessageDeflate;
          opts.createConnection = opts.createConnection || (isSecure ? tlsConnect : netConnect);
          opts.defaultPort = opts.defaultPort || defaultPort;
          opts.port = parsedUrl.port || defaultPort;
          opts.host = parsedUrl.hostname.startsWith("[") ? parsedUrl.hostname.slice(1, -1) : parsedUrl.hostname;
          opts.headers = {
            ...opts.headers,
            "Sec-WebSocket-Version": opts.protocolVersion,
            "Sec-WebSocket-Key": key,
            Connection: "Upgrade",
            Upgrade: "websocket"
          };
          opts.path = parsedUrl.pathname + parsedUrl.search;
          opts.timeout = opts.handshakeTimeout;
          if (opts.perMessageDeflate) {
            perMessageDeflate = new PerMessageDeflate2({
              ...opts.perMessageDeflate,
              isServer: false,
              maxPayload: opts.maxPayload
            });
            opts.headers["Sec-WebSocket-Extensions"] = format({
              [PerMessageDeflate2.extensionName]: perMessageDeflate.offer()
            });
          }
          if (protocols.length) {
            for (const protocol of protocols) {
              if (typeof protocol !== "string" || !subprotocolRegex.test(protocol) || protocolSet.has(protocol)) {
                throw new SyntaxError(
                  "An invalid or duplicated subprotocol was specified"
                );
              }
              protocolSet.add(protocol);
            }
            opts.headers["Sec-WebSocket-Protocol"] = protocols.join(",");
          }
          if (opts.origin) {
            if (opts.protocolVersion < 13) {
              opts.headers["Sec-WebSocket-Origin"] = opts.origin;
            } else {
              opts.headers.Origin = opts.origin;
            }
          }
          if (parsedUrl.username || parsedUrl.password) {
            opts.auth = `${parsedUrl.username}:${parsedUrl.password}`;
          }
          if (isIpcUrl) {
            const parts = opts.path.split(":");
            opts.socketPath = parts[0];
            opts.path = parts[1];
          }
          let req;
          if (opts.followRedirects) {
            if (websocket._redirects === 0) {
              websocket._originalIpc = isIpcUrl;
              websocket._originalSecure = isSecure;
              websocket._originalHostOrSocketPath = isIpcUrl ? opts.socketPath : parsedUrl.host;
              const headers = options && options.headers;
              options = { ...options, headers: {} };
              if (headers) {
                for (const [key2, value] of Object.entries(headers)) {
                  options.headers[key2.toLowerCase()] = value;
                }
              }
            } else if (websocket.listenerCount("redirect") === 0) {
              const isSameHost = isIpcUrl ? websocket._originalIpc ? opts.socketPath === websocket._originalHostOrSocketPath : false : websocket._originalIpc ? false : parsedUrl.host === websocket._originalHostOrSocketPath;
              if (!isSameHost || websocket._originalSecure && !isSecure) {
                delete opts.headers.authorization;
                delete opts.headers.cookie;
                if (!isSameHost) delete opts.headers.host;
                opts.auth = void 0;
              }
            }
            if (opts.auth && !options.headers.authorization) {
              options.headers.authorization = "Basic " + Buffer.from(opts.auth).toString("base64");
            }
            req = websocket._req = request(opts);
            if (websocket._redirects) {
              websocket.emit("redirect", websocket.url, req);
            }
          } else {
            req = websocket._req = request(opts);
          }
          if (opts.timeout) {
            req.on("timeout", () => {
              abortHandshake(websocket, req, "Opening handshake has timed out");
            });
          }
          req.on("error", (err) => {
            if (req === null || req[kAborted]) return;
            req = websocket._req = null;
            emitErrorAndClose(websocket, err);
          });
          req.on("response", (res) => {
            const location = res.headers.location;
            const statusCode = res.statusCode;
            if (location && opts.followRedirects && statusCode >= 300 && statusCode < 400) {
              if (++websocket._redirects > opts.maxRedirects) {
                abortHandshake(websocket, req, "Maximum redirects exceeded");
                return;
              }
              req.abort();
              let addr;
              try {
                addr = new URL2(location, address);
              } catch (e) {
                const err = new SyntaxError(`Invalid URL: ${location}`);
                emitErrorAndClose(websocket, err);
                return;
              }
              initAsClient(websocket, addr, protocols, options);
            } else if (!websocket.emit("unexpected-response", req, res)) {
              abortHandshake(
                websocket,
                req,
                `Unexpected server response: ${res.statusCode}`
              );
            }
          });
          req.on("upgrade", (res, socket, head) => {
            websocket.emit("upgrade", res);
            if (websocket.readyState !== WebSocket2.CONNECTING) return;
            req = websocket._req = null;
            const upgrade = res.headers.upgrade;
            if (upgrade === void 0 || upgrade.toLowerCase() !== "websocket") {
              abortHandshake(websocket, socket, "Invalid Upgrade header");
              return;
            }
            const digest = createHash("sha1").update(key + GUID).digest("base64");
            if (res.headers["sec-websocket-accept"] !== digest) {
              abortHandshake(websocket, socket, "Invalid Sec-WebSocket-Accept header");
              return;
            }
            const serverProt = res.headers["sec-websocket-protocol"];
            let protError;
            if (serverProt !== void 0) {
              if (!protocolSet.size) {
                protError = "Server sent a subprotocol but none was requested";
              } else if (!protocolSet.has(serverProt)) {
                protError = "Server sent an invalid subprotocol";
              }
            } else if (protocolSet.size) {
              protError = "Server sent no subprotocol";
            }
            if (protError) {
              abortHandshake(websocket, socket, protError);
              return;
            }
            if (serverProt) websocket._protocol = serverProt;
            const secWebSocketExtensions = res.headers["sec-websocket-extensions"];
            if (secWebSocketExtensions !== void 0) {
              if (!perMessageDeflate) {
                const message = "Server sent a Sec-WebSocket-Extensions header but no extension was requested";
                abortHandshake(websocket, socket, message);
                return;
              }
              let extensions;
              try {
                extensions = parse(secWebSocketExtensions);
              } catch (err) {
                const message = "Invalid Sec-WebSocket-Extensions header";
                abortHandshake(websocket, socket, message);
                return;
              }
              const extensionNames = Object.keys(extensions);
              if (extensionNames.length !== 1 || extensionNames[0] !== PerMessageDeflate2.extensionName) {
                const message = "Server indicated an extension that was not requested";
                abortHandshake(websocket, socket, message);
                return;
              }
              try {
                perMessageDeflate.accept(extensions[PerMessageDeflate2.extensionName]);
              } catch (err) {
                const message = "Invalid Sec-WebSocket-Extensions header";
                abortHandshake(websocket, socket, message);
                return;
              }
              websocket._extensions[PerMessageDeflate2.extensionName] = perMessageDeflate;
            }
            websocket.setSocket(socket, head, {
              allowSynchronousEvents: opts.allowSynchronousEvents,
              generateMask: opts.generateMask,
              maxBufferedChunks: opts.maxBufferedChunks,
              maxFragments: opts.maxFragments,
              maxPayload: opts.maxPayload,
              skipUTF8Validation: opts.skipUTF8Validation
            });
          });
          if (opts.finishRequest) {
            opts.finishRequest(req, websocket);
          } else {
            req.end();
          }
        }
        function emitErrorAndClose(websocket, err) {
          websocket._readyState = WebSocket2.CLOSING;
          websocket._errorEmitted = true;
          websocket.emit("error", err);
          websocket.emitClose();
        }
        function netConnect(options) {
          options.path = options.socketPath;
          return net.connect(options);
        }
        function tlsConnect(options) {
          options.path = void 0;
          if (!options.servername && options.servername !== "") {
            options.servername = net.isIP(options.host) ? "" : options.host;
          }
          return tls.connect(options);
        }
        function abortHandshake(websocket, stream, message) {
          websocket._readyState = WebSocket2.CLOSING;
          const err = new Error(message);
          Error.captureStackTrace(err, abortHandshake);
          if (stream.setHeader) {
            stream[kAborted] = true;
            stream.abort();
            if (stream.socket && !stream.socket.destroyed) {
              stream.socket.destroy();
            }
            process.nextTick(emitErrorAndClose, websocket, err);
          } else {
            stream.destroy(err);
            stream.once("error", websocket.emit.bind(websocket, "error"));
            stream.once("close", websocket.emitClose.bind(websocket));
          }
        }
        function sendAfterClose(websocket, data, cb) {
          if (data) {
            const length = isBlob(data) ? data.size : toBuffer(data).length;
            if (websocket._socket) websocket._sender._bufferedBytes += length;
            else websocket._bufferedAmount += length;
          }
          if (cb) {
            const err = new Error(
              `WebSocket is not open: readyState ${websocket.readyState} (${readyStates[websocket.readyState]})`
            );
            process.nextTick(cb, err);
          }
        }
        function receiverOnConclude(code2, reason) {
          const websocket = this[kWebSocket];
          websocket._closeFrameReceived = true;
          websocket._closeMessage = reason;
          websocket._closeCode = code2;
          if (websocket._socket[kWebSocket] === void 0) return;
          websocket._socket.removeListener("data", socketOnData);
          process.nextTick(resume, websocket._socket);
          if (code2 === 1005) websocket.close();
          else websocket.close(code2, reason);
        }
        function receiverOnDrain() {
          const websocket = this[kWebSocket];
          if (!websocket.isPaused) websocket._socket.resume();
        }
        function receiverOnError(err) {
          const websocket = this[kWebSocket];
          if (websocket._socket[kWebSocket] !== void 0) {
            websocket._socket.removeListener("data", socketOnData);
            process.nextTick(resume, websocket._socket);
            websocket.close(err[kStatusCode]);
          }
          if (!websocket._errorEmitted) {
            websocket._errorEmitted = true;
            websocket.emit("error", err);
          }
        }
        function receiverOnFinish() {
          this[kWebSocket].emitClose();
        }
        function receiverOnMessage(data, isBinary) {
          this[kWebSocket].emit("message", data, isBinary);
        }
        function receiverOnPing(data) {
          const websocket = this[kWebSocket];
          if (websocket._autoPong) websocket.pong(data, !this._isServer, NOOP);
          websocket.emit("ping", data);
        }
        function receiverOnPong(data) {
          this[kWebSocket].emit("pong", data);
        }
        function resume(stream) {
          stream.resume();
        }
        function senderOnError(err) {
          const websocket = this[kWebSocket];
          if (websocket.readyState === WebSocket2.CLOSED) return;
          if (websocket.readyState === WebSocket2.OPEN) {
            websocket._readyState = WebSocket2.CLOSING;
            setCloseTimer(websocket);
          }
          this._socket.end();
          if (!websocket._errorEmitted) {
            websocket._errorEmitted = true;
            websocket.emit("error", err);
          }
        }
        function setCloseTimer(websocket) {
          websocket._closeTimer = setTimeout(
            websocket._socket.destroy.bind(websocket._socket),
            websocket._closeTimeout
          );
        }
        function socketOnClose() {
          const websocket = this[kWebSocket];
          this.removeListener("close", socketOnClose);
          this.removeListener("data", socketOnData);
          this.removeListener("end", socketOnEnd);
          websocket._readyState = WebSocket2.CLOSING;
          if (!this._readableState.endEmitted && !websocket._closeFrameReceived && !websocket._receiver._writableState.errorEmitted && this._readableState.length !== 0) {
            const chunk = this.read(this._readableState.length);
            websocket._receiver.write(chunk);
          }
          websocket._receiver.end();
          this[kWebSocket] = void 0;
          clearTimeout(websocket._closeTimer);
          if (websocket._receiver._writableState.finished || websocket._receiver._writableState.errorEmitted) {
            websocket.emitClose();
          } else {
            websocket._receiver.on("error", receiverOnFinish);
            websocket._receiver.on("finish", receiverOnFinish);
          }
        }
        function socketOnData(chunk) {
          if (!this[kWebSocket]._receiver.write(chunk)) {
            this.pause();
          }
        }
        function socketOnEnd() {
          const websocket = this[kWebSocket];
          websocket._readyState = WebSocket2.CLOSING;
          websocket._receiver.end();
          this.end();
        }
        function socketOnError() {
          const websocket = this[kWebSocket];
          this.removeListener("error", socketOnError);
          this.on("error", NOOP);
          if (websocket) {
            websocket._readyState = WebSocket2.CLOSING;
            this.destroy();
          }
        }
      }
    });
    require_stream = __commonJS({
      "../node_modules/.pnpm/ws@8.21.0_bufferutil@4.0.9/node_modules/ws/lib/stream.js"(exports2, module2) {
        "use strict";
        var WebSocket2 = require_websocket();
        var { Duplex } = __require("stream");
        function emitClose(stream) {
          stream.emit("close");
        }
        function duplexOnEnd() {
          if (!this.destroyed && this._writableState.finished) {
            this.destroy();
          }
        }
        function duplexOnError(err) {
          this.removeListener("error", duplexOnError);
          this.destroy();
          if (this.listenerCount("error") === 0) {
            this.emit("error", err);
          }
        }
        function createWebSocketStream2(ws, options) {
          let terminateOnDestroy = true;
          const duplex = new Duplex({
            ...options,
            autoDestroy: false,
            emitClose: false,
            objectMode: false,
            writableObjectMode: false
          });
          ws.on("message", function message(msg, isBinary) {
            const data = !isBinary && duplex._readableState.objectMode ? msg.toString() : msg;
            if (!duplex.push(data)) ws.pause();
          });
          ws.once("error", function error(err) {
            if (duplex.destroyed) return;
            terminateOnDestroy = false;
            duplex.destroy(err);
          });
          ws.once("close", function close() {
            if (duplex.destroyed) return;
            duplex.push(null);
          });
          duplex._destroy = function(err, callback) {
            if (ws.readyState === ws.CLOSED) {
              callback(err);
              process.nextTick(emitClose, duplex);
              return;
            }
            let called = false;
            ws.once("error", function error(err2) {
              called = true;
              callback(err2);
            });
            ws.once("close", function close() {
              if (!called) callback(err);
              process.nextTick(emitClose, duplex);
            });
            if (terminateOnDestroy) ws.terminate();
          };
          duplex._final = function(callback) {
            if (ws.readyState === ws.CONNECTING) {
              ws.once("open", function open() {
                duplex._final(callback);
              });
              return;
            }
            if (ws._socket === null) return;
            if (ws._socket._writableState.finished) {
              callback();
              if (duplex._readableState.endEmitted) duplex.destroy();
            } else {
              ws._socket.once("finish", function finish() {
                callback();
              });
              ws.close();
            }
          };
          duplex._read = function() {
            if (ws.isPaused) ws.resume();
          };
          duplex._write = function(chunk, encoding, callback) {
            if (ws.readyState === ws.CONNECTING) {
              ws.once("open", function open() {
                duplex._write(chunk, encoding, callback);
              });
              return;
            }
            ws.send(chunk, callback);
          };
          duplex.on("end", duplexOnEnd);
          duplex.on("error", duplexOnError);
          return duplex;
        }
        module2.exports = createWebSocketStream2;
      }
    });
    require_subprotocol = __commonJS({
      "../node_modules/.pnpm/ws@8.21.0_bufferutil@4.0.9/node_modules/ws/lib/subprotocol.js"(exports2, module2) {
        "use strict";
        var { tokenChars } = require_validation();
        function parse(header) {
          const protocols = /* @__PURE__ */ new Set();
          let start = -1;
          let end = -1;
          let i = 0;
          for (i; i < header.length; i++) {
            const code2 = header.charCodeAt(i);
            if (end === -1 && tokenChars[code2] === 1) {
              if (start === -1) start = i;
            } else if (i !== 0 && (code2 === 32 || code2 === 9)) {
              if (end === -1 && start !== -1) end = i;
            } else if (code2 === 44) {
              if (start === -1) {
                throw new SyntaxError(`Unexpected character at index ${i}`);
              }
              if (end === -1) end = i;
              const protocol2 = header.slice(start, end);
              if (protocols.has(protocol2)) {
                throw new SyntaxError(`The "${protocol2}" subprotocol is duplicated`);
              }
              protocols.add(protocol2);
              start = end = -1;
            } else {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
          }
          if (start === -1 || end !== -1) {
            throw new SyntaxError("Unexpected end of input");
          }
          const protocol = header.slice(start, i);
          if (protocols.has(protocol)) {
            throw new SyntaxError(`The "${protocol}" subprotocol is duplicated`);
          }
          protocols.add(protocol);
          return protocols;
        }
        module2.exports = { parse };
      }
    });
    require_websocket_server = __commonJS({
      "../node_modules/.pnpm/ws@8.21.0_bufferutil@4.0.9/node_modules/ws/lib/websocket-server.js"(exports2, module2) {
        "use strict";
        var EventEmitter = __require("events");
        var http = __require("http");
        var { Duplex } = __require("stream");
        var { createHash } = __require("crypto");
        var extension2 = require_extension();
        var PerMessageDeflate2 = require_permessage_deflate();
        var subprotocol2 = require_subprotocol();
        var WebSocket2 = require_websocket();
        var { CLOSE_TIMEOUT, GUID, kWebSocket } = require_constants();
        var keyRegex = /^[+/0-9A-Za-z]{22}==$/;
        var RUNNING = 0;
        var CLOSING = 1;
        var CLOSED = 2;
        var WebSocketServer2 = class extends EventEmitter {
          /**
           * Create a `WebSocketServer` instance.
           *
           * @param {Object} options Configuration options
           * @param {Boolean} [options.allowSynchronousEvents=true] Specifies whether
           *     any of the `'message'`, `'ping'`, and `'pong'` events can be emitted
           *     multiple times in the same tick
           * @param {Boolean} [options.autoPong=true] Specifies whether or not to
           *     automatically send a pong in response to a ping
           * @param {Number} [options.backlog=511] The maximum length of the queue of
           *     pending connections
           * @param {Boolean} [options.clientTracking=true] Specifies whether or not to
           *     track clients
           * @param {Number} [options.closeTimeout=30000] Duration in milliseconds to
           *     wait for the closing handshake to finish after `websocket.close()` is
           *     called
           * @param {Function} [options.handleProtocols] A hook to handle protocols
           * @param {String} [options.host] The hostname where to bind the server
           * @param {Number} [options.maxBufferedChunks=1048576] The maximum number of
           *     buffered data chunks
           * @param {Number} [options.maxFragments=131072] The maximum number of message
           *     fragments
           * @param {Number} [options.maxPayload=104857600] The maximum allowed message
           *     size
           * @param {Boolean} [options.noServer=false] Enable no server mode
           * @param {String} [options.path] Accept only connections matching this path
           * @param {(Boolean|Object)} [options.perMessageDeflate=false] Enable/disable
           *     permessage-deflate
           * @param {Number} [options.port] The port where to bind the server
           * @param {(http.Server|https.Server)} [options.server] A pre-created HTTP/S
           *     server to use
           * @param {Boolean} [options.skipUTF8Validation=false] Specifies whether or
           *     not to skip UTF-8 validation for text and close messages
           * @param {Function} [options.verifyClient] A hook to reject connections
           * @param {Function} [options.WebSocket=WebSocket] Specifies the `WebSocket`
           *     class to use. It must be the `WebSocket` class or class that extends it
           * @param {Function} [callback] A listener for the `listening` event
           */
          constructor(options, callback) {
            super();
            options = {
              allowSynchronousEvents: true,
              autoPong: true,
              maxBufferedChunks: 1024 * 1024,
              maxFragments: 128 * 1024,
              maxPayload: 100 * 1024 * 1024,
              skipUTF8Validation: false,
              perMessageDeflate: false,
              handleProtocols: null,
              clientTracking: true,
              closeTimeout: CLOSE_TIMEOUT,
              verifyClient: null,
              noServer: false,
              backlog: null,
              // use default (511 as implemented in net.js)
              server: null,
              host: null,
              path: null,
              port: null,
              WebSocket: WebSocket2,
              ...options
            };
            if (options.port == null && !options.server && !options.noServer || options.port != null && (options.server || options.noServer) || options.server && options.noServer) {
              throw new TypeError(
                'One and only one of the "port", "server", or "noServer" options must be specified'
              );
            }
            if (options.port != null) {
              this._server = http.createServer((req, res) => {
                const body = http.STATUS_CODES[426];
                res.writeHead(426, {
                  "Content-Length": body.length,
                  "Content-Type": "text/plain"
                });
                res.end(body);
              });
              this._server.listen(
                options.port,
                options.host,
                options.backlog,
                callback
              );
            } else if (options.server) {
              this._server = options.server;
            }
            if (this._server) {
              const emitConnection = this.emit.bind(this, "connection");
              this._removeListeners = addListeners(this._server, {
                listening: this.emit.bind(this, "listening"),
                error: this.emit.bind(this, "error"),
                upgrade: (req, socket, head) => {
                  this.handleUpgrade(req, socket, head, emitConnection);
                }
              });
            }
            if (options.perMessageDeflate === true) options.perMessageDeflate = {};
            if (options.clientTracking) {
              this.clients = /* @__PURE__ */ new Set();
              this._shouldEmitClose = false;
            }
            this.options = options;
            this._state = RUNNING;
          }
          /**
           * Returns the bound address, the address family name, and port of the server
           * as reported by the operating system if listening on an IP socket.
           * If the server is listening on a pipe or UNIX domain socket, the name is
           * returned as a string.
           *
           * @return {(Object|String|null)} The address of the server
           * @public
           */
          address() {
            if (this.options.noServer) {
              throw new Error('The server is operating in "noServer" mode');
            }
            if (!this._server) return null;
            return this._server.address();
          }
          /**
           * Stop the server from accepting new connections and emit the `'close'` event
           * when all existing connections are closed.
           *
           * @param {Function} [cb] A one-time listener for the `'close'` event
           * @public
           */
          close(cb) {
            if (this._state === CLOSED) {
              if (cb) {
                this.once("close", () => {
                  cb(new Error("The server is not running"));
                });
              }
              process.nextTick(emitClose, this);
              return;
            }
            if (cb) this.once("close", cb);
            if (this._state === CLOSING) return;
            this._state = CLOSING;
            if (this.options.noServer || this.options.server) {
              if (this._server) {
                this._removeListeners();
                this._removeListeners = this._server = null;
              }
              if (this.clients) {
                if (!this.clients.size) {
                  process.nextTick(emitClose, this);
                } else {
                  this._shouldEmitClose = true;
                }
              } else {
                process.nextTick(emitClose, this);
              }
            } else {
              const server = this._server;
              this._removeListeners();
              this._removeListeners = this._server = null;
              server.close(() => {
                emitClose(this);
              });
            }
          }
          /**
           * See if a given request should be handled by this server instance.
           *
           * @param {http.IncomingMessage} req Request object to inspect
           * @return {Boolean} `true` if the request is valid, else `false`
           * @public
           */
          shouldHandle(req) {
            if (this.options.path) {
              const index2 = req.url.indexOf("?");
              const pathname = index2 !== -1 ? req.url.slice(0, index2) : req.url;
              if (pathname !== this.options.path) return false;
            }
            return true;
          }
          /**
           * Handle a HTTP Upgrade request.
           *
           * @param {http.IncomingMessage} req The request object
           * @param {Duplex} socket The network socket between the server and client
           * @param {Buffer} head The first packet of the upgraded stream
           * @param {Function} cb Callback
           * @public
           */
          handleUpgrade(req, socket, head, cb) {
            socket.on("error", socketOnError);
            const key = req.headers["sec-websocket-key"];
            const upgrade = req.headers.upgrade;
            const version2 = +req.headers["sec-websocket-version"];
            if (req.method !== "GET") {
              const message = "Invalid HTTP method";
              abortHandshakeOrEmitwsClientError(this, req, socket, 405, message);
              return;
            }
            if (upgrade === void 0 || upgrade.toLowerCase() !== "websocket") {
              const message = "Invalid Upgrade header";
              abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
              return;
            }
            if (key === void 0 || !keyRegex.test(key)) {
              const message = "Missing or invalid Sec-WebSocket-Key header";
              abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
              return;
            }
            if (version2 !== 13 && version2 !== 8) {
              const message = "Missing or invalid Sec-WebSocket-Version header";
              abortHandshakeOrEmitwsClientError(this, req, socket, 400, message, {
                "Sec-WebSocket-Version": "13, 8"
              });
              return;
            }
            if (!this.shouldHandle(req)) {
              abortHandshake(socket, 400);
              return;
            }
            const secWebSocketProtocol = req.headers["sec-websocket-protocol"];
            let protocols = /* @__PURE__ */ new Set();
            if (secWebSocketProtocol !== void 0) {
              try {
                protocols = subprotocol2.parse(secWebSocketProtocol);
              } catch (err) {
                const message = "Invalid Sec-WebSocket-Protocol header";
                abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
                return;
              }
            }
            const secWebSocketExtensions = req.headers["sec-websocket-extensions"];
            const extensions = {};
            if (this.options.perMessageDeflate && secWebSocketExtensions !== void 0) {
              const perMessageDeflate = new PerMessageDeflate2({
                ...this.options.perMessageDeflate,
                isServer: true,
                maxPayload: this.options.maxPayload
              });
              try {
                const offers = extension2.parse(secWebSocketExtensions);
                if (offers[PerMessageDeflate2.extensionName]) {
                  perMessageDeflate.accept(offers[PerMessageDeflate2.extensionName]);
                  extensions[PerMessageDeflate2.extensionName] = perMessageDeflate;
                }
              } catch (err) {
                const message = "Invalid or unacceptable Sec-WebSocket-Extensions header";
                abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
                return;
              }
            }
            if (this.options.verifyClient) {
              const info = {
                origin: req.headers[`${version2 === 8 ? "sec-websocket-origin" : "origin"}`],
                secure: !!(req.socket.authorized || req.socket.encrypted),
                req
              };
              if (this.options.verifyClient.length === 2) {
                this.options.verifyClient(info, (verified, code2, message, headers) => {
                  if (!verified) {
                    return abortHandshake(socket, code2 || 401, message, headers);
                  }
                  this.completeUpgrade(
                    extensions,
                    key,
                    protocols,
                    req,
                    socket,
                    head,
                    cb
                  );
                });
                return;
              }
              if (!this.options.verifyClient(info)) return abortHandshake(socket, 401);
            }
            this.completeUpgrade(extensions, key, protocols, req, socket, head, cb);
          }
          /**
           * Upgrade the connection to WebSocket.
           *
           * @param {Object} extensions The accepted extensions
           * @param {String} key The value of the `Sec-WebSocket-Key` header
           * @param {Set} protocols The subprotocols
           * @param {http.IncomingMessage} req The request object
           * @param {Duplex} socket The network socket between the server and client
           * @param {Buffer} head The first packet of the upgraded stream
           * @param {Function} cb Callback
           * @throws {Error} If called more than once with the same socket
           * @private
           */
          completeUpgrade(extensions, key, protocols, req, socket, head, cb) {
            if (!socket.readable || !socket.writable) return socket.destroy();
            if (socket[kWebSocket]) {
              throw new Error(
                "server.handleUpgrade() was called more than once with the same socket, possibly due to a misconfiguration"
              );
            }
            if (this._state > RUNNING) return abortHandshake(socket, 503);
            const digest = createHash("sha1").update(key + GUID).digest("base64");
            const headers = [
              "HTTP/1.1 101 Switching Protocols",
              "Upgrade: websocket",
              "Connection: Upgrade",
              `Sec-WebSocket-Accept: ${digest}`
            ];
            const ws = new this.options.WebSocket(null, void 0, this.options);
            if (protocols.size) {
              const protocol = this.options.handleProtocols ? this.options.handleProtocols(protocols, req) : protocols.values().next().value;
              if (protocol) {
                headers.push(`Sec-WebSocket-Protocol: ${protocol}`);
                ws._protocol = protocol;
              }
            }
            if (extensions[PerMessageDeflate2.extensionName]) {
              const params = extensions[PerMessageDeflate2.extensionName].params;
              const value = extension2.format({
                [PerMessageDeflate2.extensionName]: [params]
              });
              headers.push(`Sec-WebSocket-Extensions: ${value}`);
              ws._extensions = extensions;
            }
            this.emit("headers", headers, req);
            socket.write(headers.concat("\r\n").join("\r\n"));
            socket.removeListener("error", socketOnError);
            ws.setSocket(socket, head, {
              allowSynchronousEvents: this.options.allowSynchronousEvents,
              maxBufferedChunks: this.options.maxBufferedChunks,
              maxFragments: this.options.maxFragments,
              maxPayload: this.options.maxPayload,
              skipUTF8Validation: this.options.skipUTF8Validation
            });
            if (this.clients) {
              this.clients.add(ws);
              ws.on("close", () => {
                this.clients.delete(ws);
                if (this._shouldEmitClose && !this.clients.size) {
                  process.nextTick(emitClose, this);
                }
              });
            }
            cb(ws, req);
          }
        };
        module2.exports = WebSocketServer2;
        function addListeners(server, map) {
          for (const event of Object.keys(map)) server.on(event, map[event]);
          return function removeListeners() {
            for (const event of Object.keys(map)) {
              server.removeListener(event, map[event]);
            }
          };
        }
        function emitClose(server) {
          server._state = CLOSED;
          server.emit("close");
        }
        function socketOnError() {
          this.destroy();
        }
        function abortHandshake(socket, code2, message, headers) {
          message = message || http.STATUS_CODES[code2];
          headers = {
            Connection: "close",
            "Content-Type": "text/html",
            "Content-Length": Buffer.byteLength(message),
            ...headers
          };
          socket.once("finish", socket.destroy);
          socket.end(
            `HTTP/1.1 ${code2} ${http.STATUS_CODES[code2]}\r
` + Object.keys(headers).map((h) => `${h}: ${headers[h]}`).join("\r\n") + "\r\n\r\n" + message
          );
        }
        function abortHandshakeOrEmitwsClientError(server, req, socket, code2, message, headers) {
          if (server.listenerCount("wsClientError")) {
            const err = new Error(message);
            Error.captureStackTrace(err, abortHandshakeOrEmitwsClientError);
            server.emit("wsClientError", err, socket, req);
          } else {
            abortHandshake(socket, code2, message, headers);
          }
        }
      }
    });
    import_stream = __toESM(require_stream(), 1);
    import_extension = __toESM(require_extension(), 1);
    import_permessage_deflate = __toESM(require_permessage_deflate(), 1);
    import_receiver = __toESM(require_receiver(), 1);
    import_sender = __toESM(require_sender(), 1);
    import_subprotocol = __toESM(require_subprotocol(), 1);
    import_websocket = __toESM(require_websocket(), 1);
    import_websocket_server = __toESM(require_websocket_server(), 1);
    wrapper_default = import_websocket.default;
    nodeWebSocket = wrapper_default;
    setDefaultWebSocketConstructor(nodeWebSocket);
  }
});

// node_modules/convex/dist/esm/browser/http_client.js
var init_http_client = __esm({
  "node_modules/convex/dist/esm/browser/http_client.js"() {
    "use strict";
    init_api();
    init_common();
    init_esm();
    init_values();
    init_logging();
  }
});

// node_modules/convex/dist/esm/browser/query_options.js
var init_query_options = __esm({
  "node_modules/convex/dist/esm/browser/query_options.js"() {
    "use strict";
  }
});

// node_modules/convex/dist/esm/browser/index-node.js
var init_index_node = __esm({
  "node_modules/convex/dist/esm/browser/index-node.js"() {
    "use strict";
    init_client();
    init_simple_client_node();
    init_http_client();
    init_query_options();
  }
});

// node_modules/convex/dist/esm/server/database.js
var init_database = __esm({
  "node_modules/convex/dist/esm/server/database.js"() {
    "use strict";
  }
});

// node_modules/convex/dist/esm/server/impl/syscall.js
var init_syscall = __esm({
  "node_modules/convex/dist/esm/server/impl/syscall.js"() {
    "use strict";
    init_errors();
    init_value();
  }
});

// node_modules/convex/dist/esm/server/impl/actions_impl.js
var init_actions_impl = __esm({
  "node_modules/convex/dist/esm/server/impl/actions_impl.js"() {
    "use strict";
    init_values();
    init_esm();
    init_syscall();
    init_common();
    init_paths();
  }
});

// node_modules/convex/dist/esm/server/vector_search.js
var init_vector_search = __esm({
  "node_modules/convex/dist/esm/server/vector_search.js"() {
    "use strict";
  }
});

// node_modules/convex/dist/esm/server/impl/validate.js
var init_validate = __esm({
  "node_modules/convex/dist/esm/server/impl/validate.js"() {
    "use strict";
  }
});

// node_modules/convex/dist/esm/server/impl/vector_search_impl.js
var init_vector_search_impl = __esm({
  "node_modules/convex/dist/esm/server/impl/vector_search_impl.js"() {
    "use strict";
    init_syscall();
    init_esm();
    init_vector_search();
    init_validate();
    init_value();
  }
});

// node_modules/convex/dist/esm/server/impl/authentication_impl.js
var init_authentication_impl = __esm({
  "node_modules/convex/dist/esm/server/impl/authentication_impl.js"() {
    "use strict";
    init_syscall();
  }
});

// node_modules/convex/dist/esm/server/filter_builder.js
var init_filter_builder = __esm({
  "node_modules/convex/dist/esm/server/filter_builder.js"() {
    "use strict";
  }
});

// node_modules/convex/dist/esm/server/impl/filter_builder_impl.js
var init_filter_builder_impl = __esm({
  "node_modules/convex/dist/esm/server/impl/filter_builder_impl.js"() {
    "use strict";
    init_value();
    init_filter_builder();
  }
});

// node_modules/convex/dist/esm/server/index_range_builder.js
var init_index_range_builder = __esm({
  "node_modules/convex/dist/esm/server/index_range_builder.js"() {
    "use strict";
  }
});

// node_modules/convex/dist/esm/server/impl/index_range_builder_impl.js
var init_index_range_builder_impl = __esm({
  "node_modules/convex/dist/esm/server/impl/index_range_builder_impl.js"() {
    "use strict";
    init_value();
    init_index_range_builder();
  }
});

// node_modules/convex/dist/esm/server/search_filter_builder.js
var init_search_filter_builder = __esm({
  "node_modules/convex/dist/esm/server/search_filter_builder.js"() {
    "use strict";
  }
});

// node_modules/convex/dist/esm/server/impl/search_filter_builder_impl.js
var init_search_filter_builder_impl = __esm({
  "node_modules/convex/dist/esm/server/impl/search_filter_builder_impl.js"() {
    "use strict";
    init_value();
    init_search_filter_builder();
    init_validate();
  }
});

// node_modules/convex/dist/esm/server/impl/query_impl.js
var init_query_impl = __esm({
  "node_modules/convex/dist/esm/server/impl/query_impl.js"() {
    "use strict";
    init_values();
    init_syscall();
    init_filter_builder_impl();
    init_index_range_builder_impl();
    init_search_filter_builder_impl();
    init_validate();
    init_esm();
  }
});

// node_modules/convex/dist/esm/server/impl/database_impl.js
var init_database_impl = __esm({
  "node_modules/convex/dist/esm/server/impl/database_impl.js"() {
    "use strict";
    init_values();
    init_syscall();
    init_query_impl();
    init_validate();
    init_esm();
    init_value();
  }
});

// node_modules/convex/dist/esm/server/impl/scheduler_impl.js
var init_scheduler_impl = __esm({
  "node_modules/convex/dist/esm/server/impl/scheduler_impl.js"() {
    "use strict";
    init_values();
    init_esm();
    init_syscall();
    init_common();
    init_validate();
    init_paths();
  }
});

// node_modules/convex/dist/esm/server/impl/storage_impl.js
var init_storage_impl = __esm({
  "node_modules/convex/dist/esm/server/impl/storage_impl.js"() {
    "use strict";
    init_esm();
    init_syscall();
    init_validate();
  }
});

// node_modules/convex/dist/esm/server/impl/meta_impl.js
var init_meta_impl = __esm({
  "node_modules/convex/dist/esm/server/impl/meta_impl.js"() {
    "use strict";
    init_values();
    init_syscall();
  }
});

// node_modules/convex/dist/esm/server/impl/registration_impl.js
var init_registration_impl = __esm({
  "node_modules/convex/dist/esm/server/impl/registration_impl.js"() {
    "use strict";
    init_values();
    init_actions_impl();
    init_vector_search_impl();
    init_authentication_impl();
    init_database_impl();
    init_query_impl();
    init_scheduler_impl();
    init_storage_impl();
    init_common();
    init_syscall();
    init_validator();
    init_paths();
    init_meta_impl();
  }
});

// node_modules/convex/dist/esm/server/pagination.js
var paginationOptsValidator;
var init_pagination2 = __esm({
  "node_modules/convex/dist/esm/server/pagination.js"() {
    "use strict";
    init_validator();
    paginationOptsValidator = v.object({
      numItems: v.number(),
      cursor: v.union(v.string(), v.null()),
      endCursor: v.optional(v.union(v.string(), v.null())),
      id: v.optional(v.number()),
      maximumRowsRead: v.optional(v.number()),
      maximumBytesRead: v.optional(v.number())
    });
  }
});

// node_modules/convex/dist/esm/server/storage.js
var init_storage = __esm({
  "node_modules/convex/dist/esm/server/storage.js"() {
    "use strict";
  }
});

// node_modules/convex/dist/esm/server/cron.js
var init_cron = __esm({
  "node_modules/convex/dist/esm/server/cron.js"() {
    "use strict";
    init_api();
    init_common();
    init_values();
    init_paths();
  }
});

// node_modules/convex/dist/esm/server/router.js
var init_router = __esm({
  "node_modules/convex/dist/esm/server/router.js"() {
    "use strict";
    init_syscall();
  }
});

// node_modules/convex/dist/esm/server/components/index.js
var init_components = __esm({
  "node_modules/convex/dist/esm/server/components/index.js"() {
    "use strict";
    init_esm();
    init_syscall();
    init_paths();
    init_validator();
    init_paths();
  }
});

// node_modules/convex/dist/esm/server/logVars.js
var REQUEST_ID, IP, USER_AGENT, NOW, CONVEX_ACTOR, varNames;
var init_logVars = __esm({
  "node_modules/convex/dist/esm/server/logVars.js"() {
    "use strict";
    REQUEST_ID = Symbol("var.requestId");
    IP = Symbol("var.ip");
    USER_AGENT = Symbol("var.userAgent");
    NOW = Symbol("var.now");
    CONVEX_ACTOR = Symbol("var.convexActor");
    varNames = {
      [REQUEST_ID]: "requestId",
      [IP]: "ip",
      [USER_AGENT]: "userAgent",
      [NOW]: "now",
      [CONVEX_ACTOR]: "convexActor"
    };
  }
});

// node_modules/convex/dist/esm/server/audit_logging.js
var init_audit_logging = __esm({
  "node_modules/convex/dist/esm/server/audit_logging.js"() {
    "use strict";
    init_esm();
    init_syscall();
    init_logVars();
  }
});

// node_modules/convex/dist/esm/server/log.js
var init_log = __esm({
  "node_modules/convex/dist/esm/server/log.js"() {
    "use strict";
    init_audit_logging();
    init_logVars();
  }
});

// node_modules/convex/dist/esm/server/schema.js
function defineTable(documentSchema) {
  if (isValidator(documentSchema)) {
    return new TableDefinition(documentSchema);
  } else {
    return new TableDefinition(v.object(documentSchema));
  }
}
function defineSchema(schema, options) {
  return new SchemaDefinition(schema, options);
}
var __defProp16, __defNormalProp14, __publicField14, TableDefinition, SchemaDefinition, _systemSchema;
var init_schema = __esm({
  "node_modules/convex/dist/esm/server/schema.js"() {
    "use strict";
    init_validator();
    __defProp16 = Object.defineProperty;
    __defNormalProp14 = (obj, key, value) => key in obj ? __defProp16(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
    __publicField14 = (obj, key, value) => __defNormalProp14(obj, typeof key !== "symbol" ? key + "" : key, value);
    TableDefinition = class {
      /**
       * @internal
       */
      constructor(documentType) {
        __publicField14(this, "indexes");
        __publicField14(this, "stagedDbIndexes");
        __publicField14(this, "searchIndexes");
        __publicField14(this, "stagedSearchIndexes");
        __publicField14(this, "vectorIndexes");
        __publicField14(this, "stagedVectorIndexes");
        __publicField14(this, "validator");
        this.indexes = [];
        this.stagedDbIndexes = [];
        this.searchIndexes = [];
        this.stagedSearchIndexes = [];
        this.vectorIndexes = [];
        this.stagedVectorIndexes = [];
        this.validator = documentType;
      }
      /**
       * This API is experimental: it may change or disappear.
       *
       * Returns indexes defined on this table.
       * Intended for the advanced use cases of dynamically deciding which index to use for a query.
       * If you think you need this, please chime in on ths issue in the Convex JS GitHub repo.
       * https://github.com/get-convex/convex-js/issues/49
       */
      " indexes"() {
        return this.indexes;
      }
      index(name, indexConfig) {
        if (Array.isArray(indexConfig)) {
          this.indexes.push({
            indexDescriptor: name,
            fields: indexConfig
          });
        } else if (indexConfig.staged) {
          this.stagedDbIndexes.push({
            indexDescriptor: name,
            fields: indexConfig.fields
          });
        } else {
          this.indexes.push({
            indexDescriptor: name,
            fields: indexConfig.fields
          });
        }
        return this;
      }
      searchIndex(name, indexConfig) {
        if (indexConfig.staged) {
          this.stagedSearchIndexes.push({
            indexDescriptor: name,
            searchField: indexConfig.searchField,
            filterFields: indexConfig.filterFields || []
          });
        } else {
          this.searchIndexes.push({
            indexDescriptor: name,
            searchField: indexConfig.searchField,
            filterFields: indexConfig.filterFields || []
          });
        }
        return this;
      }
      vectorIndex(name, indexConfig) {
        if (indexConfig.staged) {
          this.stagedVectorIndexes.push({
            indexDescriptor: name,
            vectorField: indexConfig.vectorField,
            dimensions: indexConfig.dimensions,
            filterFields: indexConfig.filterFields || []
          });
        } else {
          this.vectorIndexes.push({
            indexDescriptor: name,
            vectorField: indexConfig.vectorField,
            dimensions: indexConfig.dimensions,
            filterFields: indexConfig.filterFields || []
          });
        }
        return this;
      }
      /**
       * Work around for https://github.com/microsoft/TypeScript/issues/57035
       */
      self() {
        return this;
      }
      /**
       * Export the contents of this definition.
       *
       * This is called internally by the Convex framework.
       * @internal
       */
      export() {
        const documentType = this.validator.json;
        if (typeof documentType !== "object") {
          throw new Error(
            "Invalid validator: please make sure that the parameter of `defineTable` is valid (see https://docs.convex.dev/database/schemas)"
          );
        }
        return {
          indexes: this.indexes,
          stagedDbIndexes: this.stagedDbIndexes,
          searchIndexes: this.searchIndexes,
          stagedSearchIndexes: this.stagedSearchIndexes,
          vectorIndexes: this.vectorIndexes,
          stagedVectorIndexes: this.stagedVectorIndexes,
          documentType
        };
      }
    };
    SchemaDefinition = class {
      /**
       * @internal
       */
      constructor(tables, options) {
        __publicField14(this, "tables");
        __publicField14(this, "strictTableNameTypes");
        __publicField14(this, "schemaValidation");
        this.tables = tables;
        this.schemaValidation = options?.schemaValidation === void 0 ? true : options.schemaValidation;
      }
      /**
       * Export the contents of this definition.
       *
       * This is called internally by the Convex framework.
       * @internal
       */
      export() {
        return JSON.stringify({
          tables: Object.entries(this.tables).map(([tableName, definition]) => {
            const {
              indexes,
              stagedDbIndexes,
              searchIndexes,
              stagedSearchIndexes,
              vectorIndexes,
              stagedVectorIndexes,
              documentType
            } = definition.export();
            return {
              tableName,
              indexes,
              stagedDbIndexes,
              searchIndexes,
              stagedSearchIndexes,
              vectorIndexes,
              stagedVectorIndexes,
              documentType
            };
          }),
          schemaValidation: this.schemaValidation
        });
      }
    };
    _systemSchema = defineSchema({
      _scheduled_functions: defineTable({
        name: v.string(),
        args: v.array(v.any()),
        scheduledTime: v.float64(),
        completedTime: v.optional(v.float64()),
        state: v.union(
          v.object({ kind: v.literal("pending") }),
          v.object({ kind: v.literal("inProgress") }),
          v.object({ kind: v.literal("success") }),
          v.object({ kind: v.literal("failed"), error: v.string() }),
          v.object({ kind: v.literal("canceled") })
        )
      }),
      _storage: defineTable({
        sha256: v.string(),
        size: v.float64(),
        contentType: v.optional(v.string())
      })
    });
  }
});

// node_modules/convex/dist/esm/server/index.js
var init_server = __esm({
  "node_modules/convex/dist/esm/server/index.js"() {
    "use strict";
    init_database();
    init_registration_impl();
    init_pagination2();
    init_search_filter_builder();
    init_storage();
    init_cron();
    init_router();
    init_api();
    init_components();
    init_components();
    init_components();
    init_log();
    init_schema();
  }
});

// src/lib/physics/convexSource.ts
var TRAJ_FULL_SET_QUERY, TRAJ_BATCHES_QUERY, TRAJ_META_QUERY, TRAJ_CLOCK_QUERY, RESUBSCRIBE_AFTER_BATCHES, SEED_RETRY_MIN_MS, SEED_RETRY_MAX_MS, SEED_WAIT_TIMEOUT_MS, ConvexTrajectorySource;
var init_convexSource = __esm({
  "src/lib/physics/convexSource.ts"() {
    "use strict";
    init_index_node();
    init_server();
    TRAJ_FULL_SET_QUERY = makeFunctionReference("trajectories:fullSet");
    TRAJ_BATCHES_QUERY = makeFunctionReference("trajectories:batchesSince");
    TRAJ_META_QUERY = makeFunctionReference("trajectories:meta");
    TRAJ_CLOCK_QUERY = makeFunctionReference("clock:now");
    RESUBSCRIBE_AFTER_BATCHES = 8;
    SEED_RETRY_MIN_MS = 2e3;
    SEED_RETRY_MAX_MS = 3e4;
    SEED_WAIT_TIMEOUT_MS = 15e3;
    ConvexTrajectorySource = class {
      constructor(sink, options) {
        this.sink = sink;
        this.options = options;
        this.createClient = options.createClient ?? ((url) => new ConvexClient(url));
      }
      createClient;
      client = null;
      unsubscribeBatches = null;
      unsubscribeMeta = null;
      generation = 0;
      running = false;
      lastSeq = -1;
      batchesAtCursor = 0;
      seedRetryTimer = null;
      seedRetryMs = SEED_RETRY_MIN_MS;
      seedWaitTimer = null;
      clockTimer = null;
      clockRequest = 0;
      subscriptionGeneration = 0;
      seeding = false;
      lastPublicationMs = 0;
      start() {
        if (this.running) return;
        this.running = true;
        this.generation += 1;
        this.client = this.createClient(this.options.url);
        this.subscribeMeta();
        void this.sampleClock();
        void this.seed();
      }
      stop() {
        if (!this.running && this.client === null) return;
        this.running = false;
        this.generation += 1;
        this.seeding = false;
        if (this.seedWaitTimer) clearTimeout(this.seedWaitTimer);
        this.seedWaitTimer = null;
        if (this.clockTimer) clearTimeout(this.clockTimer);
        this.clockTimer = null;
        if (this.seedRetryTimer) {
          clearTimeout(this.seedRetryTimer);
          this.seedRetryTimer = null;
        }
        this.unsubscribeBatches?.();
        this.unsubscribeBatches = null;
        this.unsubscribeMeta?.();
        this.unsubscribeMeta = null;
        const client = this.client;
        this.client = null;
        if (client) void client.close().catch(() => void 0);
      }
      get isRunning() {
        return this.running;
      }
      async sampleClock() {
        const gen = this.generation;
        const client = this.client;
        if (!client) return;
        const sentAtMs = Date.now();
        try {
          const result = await client.query(TRAJ_CLOCK_QUERY, {
            nonce: `${sentAtMs}-${++this.clockRequest}-${Math.random().toString(36).slice(2)}`
          });
          if (gen !== this.generation) return;
          this.sink.noteConvexClock(result.serverNowMs, sentAtMs, Date.now());
        } catch {
        }
        if (gen === this.generation)
          this.clockTimer = setTimeout(() => {
            this.clockTimer = null;
            void this.sampleClock();
          }, 6e4);
      }
      async seed() {
        const gen = this.generation;
        const client = this.client;
        if (!client || this.seeding) return;
        this.seeding = true;
        const waitTimer = setTimeout(() => {
          if (gen === this.generation && this.seeding)
            this.sink.noteConvexFailure("Trajectory seed timed out waiting for the server");
          if (this.seedWaitTimer === waitTimer) this.seedWaitTimer = null;
        }, SEED_WAIT_TIMEOUT_MS);
        this.seedWaitTimer = waitTimer;
        try {
          const result = await client.query(TRAJ_FULL_SET_QUERY, {});
          if (gen !== this.generation) return;
          this.seeding = false;
          this.sink.seedConvex(result.vehicles, result.meta, Date.now());
          this.lastSeq = result.seq;
          this.lastPublicationMs = result.meta?.publishedAtMs ?? 0;
          this.seedRetryMs = SEED_RETRY_MIN_MS;
          this.subscribeBatches();
        } catch (e) {
          if (gen !== this.generation) return;
          this.seeding = false;
          this.sink.noteConvexFailure(e instanceof Error ? e.message : String(e));
          this.scheduleSeedRetry(gen);
        } finally {
          clearTimeout(waitTimer);
          if (this.seedWaitTimer === waitTimer) this.seedWaitTimer = null;
        }
      }
      scheduleSeedRetry(gen) {
        if (this.seedRetryTimer || gen !== this.generation) return;
        this.seedRetryTimer = setTimeout(() => {
          this.seedRetryTimer = null;
          if (gen === this.generation) void this.seed();
        }, this.seedRetryMs);
        this.seedRetryMs = Math.min(SEED_RETRY_MAX_MS, this.seedRetryMs * 2);
      }
      subscribeBatches() {
        const gen = this.generation;
        const client = this.client;
        if (!client) return;
        this.unsubscribeBatches?.();
        this.batchesAtCursor = 0;
        const subGen = ++this.subscriptionGeneration;
        const sinceSeq = this.lastSeq;
        this.unsubscribeBatches = client.onUpdate(
          TRAJ_BATCHES_QUERY,
          { sinceSeq },
          (result) => {
            if (gen !== this.generation || subGen !== this.subscriptionGeneration) return;
            this.onBatches(result);
          },
          (e) => {
            if (gen !== this.generation || subGen !== this.subscriptionGeneration) return;
            this.sink.noteConvexFailure(e.message);
            this.subscriptionGeneration += 1;
            this.unsubscribeBatches?.();
            this.unsubscribeBatches = null;
            this.scheduleSeedRetry(gen);
          }
        );
      }
      onBatches(result) {
        const fresh = result.batches.filter((b) => b.seq > this.lastSeq);
        if (fresh.length > 0 && fresh[0].seq !== this.lastSeq + 1 && result.oldestSeq !== null && result.oldestSeq > this.lastSeq + 1) {
          this.reseed();
          return;
        }
        const receivedAtMs = Date.now();
        for (const batch of fresh) {
          this.sink.foldConvex(batch, result.serverNowMs, receivedAtMs);
          this.lastSeq = batch.seq;
          this.batchesAtCursor += 1;
        }
        if (this.batchesAtCursor >= RESUBSCRIBE_AFTER_BATCHES) this.subscribeBatches();
      }
      reseed() {
        this.subscriptionGeneration += 1;
        this.unsubscribeBatches?.();
        this.unsubscribeBatches = null;
        void this.seed();
      }
      subscribeMeta() {
        const gen = this.generation;
        const client = this.client;
        if (!client) return;
        this.unsubscribeMeta = client.onUpdate(
          TRAJ_META_QUERY,
          {},
          (result) => {
            if (gen !== this.generation || result === null) return;
            if (!this.seeding && this.lastSeq >= 0 && result.lastSeq < this.lastSeq && result.publishedAtMs >= this.lastPublicationMs)
              this.reseed();
            this.lastPublicationMs = Math.max(this.lastPublicationMs, result.publishedAtMs);
            this.sink.noteConvexMeta(result, Date.now());
          },
          () => {
          }
        );
      }
    };
  }
});

// src/lib/physics/resilientSource.ts
var resilientSource_exports = {};
__export(resilientSource_exports, {
  PRIMARY_PROBE_INTERVAL_MS: () => PRIMARY_PROBE_INTERVAL_MS,
  PRIMARY_PROBE_TIMEOUT_MS: () => PRIMARY_PROBE_TIMEOUT_MS,
  PRIMARY_RECOVERY_PROGRESS_MS: () => PRIMARY_RECOVERY_PROGRESS_MS,
  ResilientTrajectorySource: () => ResilientTrajectorySource,
  SOURCE_SILENCE_MS: () => SOURCE_SILENCE_MS
});
var SOURCE_SILENCE_MS, PRIMARY_PROBE_INTERVAL_MS, PRIMARY_PROBE_TIMEOUT_MS, PRIMARY_RECOVERY_PROGRESS_MS, MAX_STAGED_VEHICLES, ResilientTrajectorySource;
var init_resilientSource = __esm({
  "src/lib/physics/resilientSource.ts"() {
    "use strict";
    init_bundle();
    init_convexSource();
    SOURCE_SILENCE_MS = 15e3;
    PRIMARY_PROBE_INTERVAL_MS = 12e4;
    PRIMARY_PROBE_TIMEOUT_MS = 2e4;
    PRIMARY_RECOVERY_PROGRESS_MS = 5e3;
    MAX_STAGED_VEHICLES = 2e3;
    ResilientTrajectorySource = class {
      constructor(sink, options) {
        this.sink = sink;
        this.options = options;
        this.fallbackUrl = options.fallbackUrl !== options.url ? options.fallbackUrl : void 0;
        this.create = options.createSource ?? ((sink2, options2) => new ConvexTrajectorySource(sink2, options2));
      }
      active = null;
      probe = null;
      running = false;
      timer = null;
      nextProbeAt = 0;
      switches = 0;
      reason = null;
      acceptedRole = null;
      fallbackUrl;
      create;
      start() {
        if (this.running) return;
        this.running = true;
        this.reason = null;
        this.active = this.endpoint("primary");
        this.publishStatus();
        this.startEndpoint(this.active);
        if (this.fallbackUrl) this.schedule();
      }
      stop() {
        this.running = false;
        if (this.timer) clearTimeout(this.timer);
        this.timer = null;
        this.close(this.probe);
        this.close(this.active);
        this.probe = this.active = null;
      }
      close(endpoint) {
        if (!endpoint) return;
        endpoint.live = false;
        endpoint.rows.clear();
        endpoint.source.stop();
      }
      startEndpoint(endpoint) {
        try {
          endpoint.source.start();
        } catch (error) {
          if (endpoint === this.active) this.sink.noteConvexFailure(`Trajectory connection failed: ${String(error)}`);
        }
      }
      publishStatus(epoch = false) {
        if (!this.active) return;
        this.sink.noteConvexSource?.({
          active: this.acceptedRole ?? this.active.role,
          url: (this.acceptedRole ?? this.active.role) === "primary" ? this.options.url : this.fallbackUrl,
          reason: this.reason,
          switches: this.switches,
          probing: this.probe !== null,
          connecting: this.active.seeded ? null : this.active.role
        }, epoch);
      }
      progress(endpoint, atMs, receivedAt) {
        if (!Number.isFinite(atMs) || atMs <= endpoint.publication) return;
        endpoint.publication = atMs;
        endpoint.progressAt = receivedAt;
        if (endpoint.firstProgressAt === null) {
          endpoint.firstProgressAt = receivedAt;
          endpoint.firstPublication = atMs;
        }
      }
      trackLag(endpoint, receivedAt) {
        if (endpoint.seeded && endpoint.advertisedSeq > endpoint.seq)
          endpoint.lagSince ??= receivedAt;
        else endpoint.lagSince = null;
      }
      endpoint(role) {
        const endpoint = {
          role,
          source: null,
          live: true,
          seeded: false,
          startedAt: Date.now(),
          progressAt: Date.now(),
          firstProgressAt: null,
          firstPublication: 0,
          publication: 0,
          seq: 0,
          failureAt: null,
          advertisedSeq: 0,
          advertisedAt: 0,
          lagSince: null,
          rows: /* @__PURE__ */ new Map(),
          meta: null,
          clock: null
        };
        const valid = () => this.running && endpoint.live;
        const active = () => endpoint === this.active;
        const stage = (rows2) => {
          for (const row of rows2) {
            const parsed = parseVehicle(row);
            if (!parsed) continue;
            const previous = endpoint.rows.get(parsed.key);
            if (previous && (parseVehicle(previous)?.emittedAtMs ?? 0) > parsed.emittedAtMs) continue;
            if (previous || endpoint.rows.size < MAX_STAGED_VEHICLES) endpoint.rows.set(parsed.key, row);
          }
        };
        endpoint.source = this.create({
          seedConvex: (rows2, meta, receivedAt) => {
            if (!valid()) return;
            const firstSeed = !endpoint.seeded;
            endpoint.seeded = true;
            endpoint.failureAt = null;
            endpoint.seq = meta?.lastSeq ?? 0;
            endpoint.meta = meta;
            endpoint.advertisedSeq = Math.max(endpoint.advertisedSeq, endpoint.seq);
            this.trackLag(endpoint, receivedAt);
            this.progress(endpoint, meta?.atMs ?? 0, receivedAt);
            if (active()) {
              this.acceptedRole = endpoint.role;
              this.publishStatus(firstSeed);
              if (firstSeed && endpoint.clock) this.sink.noteConvexClock(...endpoint.clock, receivedAt);
              this.sink.seedConvex(rows2, meta, receivedAt);
            } else {
              endpoint.rows.clear();
              stage(rows2);
            }
          },
          foldConvex: (batch, serverNowMs, receivedAt) => {
            if (!valid() || !endpoint.seeded || batch.seq <= endpoint.seq) return;
            endpoint.seq = batch.seq;
            this.trackLag(endpoint, receivedAt);
            this.progress(endpoint, batch.atMs, receivedAt);
            endpoint.failureAt = null;
            if (active()) this.sink.foldConvex(batch, serverNowMs, receivedAt);
            else {
              stage(batch.changed);
              for (const key of batch.removed ?? []) endpoint.rows.delete(key);
              endpoint.seq = batch.seq;
              if (endpoint.meta) endpoint.meta = {
                ...endpoint.meta,
                lastSeq: batch.seq,
                atMs: Math.max(batch.atMs, endpoint.meta.atMs),
                serverNowMs
              };
            }
          },
          noteConvexMeta: (meta, receivedAt) => {
            if (!valid()) return;
            this.progress(endpoint, meta.atMs, receivedAt);
            if (meta.publishedAtMs >= endpoint.advertisedAt) {
              endpoint.advertisedAt = meta.publishedAtMs;
              endpoint.advertisedSeq = meta.lastSeq;
            }
            this.trackLag(endpoint, receivedAt);
            if (!endpoint.meta || meta.atMs >= endpoint.meta.atMs)
              endpoint.meta = { ...meta, lastSeq: endpoint.seq };
            if (active() && endpoint.seeded) this.sink.noteConvexMeta(meta, receivedAt);
          },
          noteConvexFailure: (message) => {
            if (!valid()) return;
            endpoint.failureAt ??= Date.now();
            if (active()) this.sink.noteConvexFailure(message);
          },
          noteConvexClock: (serverNow, sentAt, receivedAt) => {
            if (!valid() || receivedAt < sentAt || receivedAt - sentAt > 2e3 || !Number.isFinite(serverNow)) return;
            endpoint.clock = [serverNow, sentAt, receivedAt];
            if (active() && endpoint.seeded) this.sink.noteConvexClock(serverNow, sentAt, receivedAt);
          }
        }, { url: role === "primary" ? this.options.url : this.fallbackUrl });
        return endpoint;
      }
      promote(probe) {
        this.close(this.active);
        this.active = probe;
        this.acceptedRole = "primary";
        this.probe = null;
        this.reason = "Private predictor recovered after sustained publisher progress";
        this.switches += 1;
        this.publishStatus(true);
        if (probe.clock) this.sink.noteConvexClock(...probe.clock, Date.now());
        this.sink.seedConvex([...probe.rows.values()], probe.meta, Date.now());
        probe.rows.clear();
      }
      schedule() {
        this.timer = setTimeout(() => {
          this.timer = null;
          if (!this.running || !this.active) return;
          const now = Date.now();
          const active = this.active;
          if (active.role === "primary" && (now - (active.seeded ? active.progressAt : active.startedAt) >= SOURCE_SILENCE_MS || active.failureAt !== null && now - active.failureAt >= SOURCE_SILENCE_MS || active.lagSince !== null && now - active.lagSince >= SOURCE_SILENCE_MS)) {
            this.close(active);
            this.reason = active.lagSince !== null ? "Private vehicle rows lagged behind the advertised publisher head" : active.failureAt !== null ? "Private trajectory delivery failed persistently" : active.seeded ? "Private predictor stopped publishing" : "Private predictor did not provide a seed within 15 seconds";
            this.switches += 1;
            this.active = this.endpoint("fallback");
            this.nextProbeAt = now + PRIMARY_PROBE_INTERVAL_MS;
            this.publishStatus();
            this.startEndpoint(this.active);
          }
          if (this.active.role === "fallback" && !this.probe && now >= this.nextProbeAt) {
            this.probe = this.endpoint("primary");
            this.nextProbeAt = now + PRIMARY_PROBE_INTERVAL_MS;
            this.publishStatus();
            this.startEndpoint(this.probe);
          }
          const probe = this.probe;
          if (probe) {
            const offset = probe.clock ? probe.clock[0] - (probe.clock[1] + probe.clock[2]) / 2 : 0;
            const publicationAge = now + offset - probe.publication;
            const progressing = probe.seeded && probe.failureAt === null && probe.lagSince === null && probe.meta && probe.firstProgressAt !== null && probe.progressAt - probe.firstProgressAt >= PRIMARY_RECOVERY_PROGRESS_MS && probe.publication - probe.firstPublication >= PRIMARY_RECOVERY_PROGRESS_MS && now - probe.progressAt < SOURCE_SILENCE_MS && publicationAge >= -3e4 && publicationAge < 45e3;
            if (progressing) this.promote(probe);
            else if (now - probe.startedAt >= PRIMARY_PROBE_TIMEOUT_MS) {
              this.close(probe);
              this.probe = null;
              this.publishStatus();
            }
          }
          this.schedule();
        }, 1e3);
      }
    };
  }
});

// bench/src/replay-wire.ts
var import_node_fs = require("node:fs");
var import_node_perf_hooks = require("node:perf_hooks");
var import_node_zlib = require("node:zlib");

// src/lib/geo/polyline.ts
var EARTH_RADIUS_M = 63710088e-1;
var DEG2RAD = Math.PI / 180;
var M_PER_DEG_LAT = Math.PI / 180 * EARTH_RADIUS_M;
function haversineM(a, b) {
  const dLat = (b[1] - a[1]) * DEG2RAD;
  const dLng = (b[0] - a[0]) * DEG2RAD;
  const lat1 = a[1] * DEG2RAD;
  const lat2 = b[1] * DEG2RAD;
  const sinLat = Math.sin(dLat / 2);
  const sinLng = Math.sin(dLng / 2);
  const h = sinLat * sinLat + Math.cos(lat1) * Math.cos(lat2) * sinLng * sinLng;
  return 2 * EARTH_RADIUS_M * Math.asin(Math.min(1, Math.sqrt(h)));
}
function segmentIndexAt(cumDistM, distM) {
  const n = cumDistM.length;
  if (n <= 1) return 0;
  const d = Math.min(Math.max(distM, cumDistM[0]), cumDistM[n - 1]);
  let lo = 0;
  let hi = n - 2;
  while (lo < hi) {
    const mid = lo + hi + 1 >> 1;
    if (cumDistM[mid] <= d) lo = mid;
    else hi = mid - 1;
  }
  return lo;
}
function pointAt(coords, cumDistM, distM) {
  const n = coords.length;
  if (n === 0) return [0, 0];
  if (n === 1) return [coords[0][0], coords[0][1]];
  const total = cumDistM[n - 1];
  const d = Math.min(Math.max(distM, 0), total);
  const i = segmentIndexAt(cumDistM, d);
  const segLen = cumDistM[i + 1] - cumDistM[i];
  if (segLen <= 1e-9) return [coords[i][0], coords[i][1]];
  const t = (d - cumDistM[i]) / segLen;
  const a = coords[i];
  const b = coords[i + 1];
  return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t];
}
function bearingBetween(a, b) {
  const cosLat = Math.cos((a[1] + b[1]) / 2 * DEG2RAD);
  const dxEast = (b[0] - a[0]) * cosLat;
  const dyNorth = b[1] - a[1];
  if (Math.abs(dxEast) < 1e-15 && Math.abs(dyNorth) < 1e-15) return 0;
  const deg = Math.atan2(dxEast, dyNorth) / DEG2RAD;
  return (deg + 360) % 360;
}
var BEARING_FOLD_CHORD_RATIO = 0.9;
function bearingAt(coords, cumDistM, distM) {
  const n = coords.length;
  if (n < 2) return 0;
  const total = cumDistM[n - 1];
  const d = Math.min(Math.max(distM, 0), total);
  const d0 = Math.max(0, d - 2);
  const d1 = Math.min(total, d + 2);
  const p0 = pointAt(coords, cumDistM, d0);
  const p1 = pointAt(coords, cumDistM, d1);
  const chord = haversineM(p0, p1);
  if (chord > 1e-3 && chord >= BEARING_FOLD_CHORD_RATIO * (d1 - d0)) {
    return bearingBetween(p0, p1);
  }
  const i = segmentIndexAt(cumDistM, d);
  for (let step = 0; step < n; step++) {
    const fwd = i + step;
    const back = i - step;
    if (fwd < n - 1 && haversineM(coords[fwd], coords[fwd + 1]) > 1e-3) {
      return bearingBetween(coords[fwd], coords[fwd + 1]);
    }
    if (back >= 0 && back < n - 1 && haversineM(coords[back], coords[back + 1]) > 1e-3) {
      return bearingBetween(coords[back], coords[back + 1]);
    }
  }
  return 0;
}

// src/lib/physics/geometryCoherence.ts
var GEOMETRY_AXIS_CONTRADICTION_M = 500;
function assessGeometryCoherence(fix, geometry) {
  if (!geometry) return { status: "unknown", reason: "missing-geometry", axisCoordinateErrorM: null };
  if (!Array.isArray(geometry.coordinates) || !Array.isArray(geometry.cumDistM) || geometry.coordinates.length < 2 || geometry.cumDistM.length !== geometry.coordinates.length)
    return { status: "invalid", reason: "malformed-geometry", axisCoordinateErrorM: null };
  if (!Number.isFinite(fix.shapeDistM) || !Array.isArray(fix.coordinates) || fix.coordinates.length !== 2 || !fix.coordinates.every(Number.isFinite))
    return { status: "unknown", reason: "nonfinite-position", axisCoordinateErrorM: null };
  const axisCoordinateErrorM = haversineM(
    fix.coordinates,
    pointAt(geometry.coordinates, geometry.cumDistM, fix.shapeDistM)
  );
  if (!Number.isFinite(axisCoordinateErrorM))
    return { status: "unknown", reason: "nonfinite-position", axisCoordinateErrorM: null };
  if (!fix.lastStopId || !fix.nextStopId || geometry.stops.length === 0)
    return { status: "unknown", reason: "missing-stop-ids", axisCoordinateErrorM };
  if (geometry.provisional) {
    let lastSeen = false;
    const ordered = geometry.stops.some((stop) => {
      if (stop.stopId === fix.lastStopId) lastSeen = true;
      return lastSeen && stop.stopId === fix.nextStopId;
    });
    if (!ordered) return {
      status: "invalid",
      reason: "provisional-stop-order-disagrees",
      axisCoordinateErrorM
    };
  }
  const eitherStopPresent = geometry.stops.some(
    (stop) => stop.stopId === fix.lastStopId || stop.stopId === fix.nextStopId
  );
  return axisCoordinateErrorM > GEOMETRY_AXIS_CONTRADICTION_M && !eitherStopPresent ? { status: "invalid", reason: "axis-and-stop-ids-disagree", axisCoordinateErrorM } : { status: "valid", axisCoordinateErrorM };
}

// src/lib/time/prague.ts
function pragueOffsetSeconds(utcMs) {
  const year = new Date(utcMs).getUTCFullYear();
  const lastSundayUtc1am = (monthZeroBased) => {
    const lastDay = new Date(Date.UTC(year, monthZeroBased + 1, 0));
    const date = lastDay.getUTCDate() - lastDay.getUTCDay();
    return Date.UTC(year, monthZeroBased, date, 1, 0, 0);
  };
  const dstStart = lastSundayUtc1am(2);
  const dstEnd = lastSundayUtc1am(9);
  return utcMs >= dstStart && utcMs < dstEnd ? 7200 : 3600;
}

// src/lib/golemio/gtfs.ts
var DAY_MS = 864e5;
function pragueMidnightEpoch(instantMs) {
  const off = pragueOffsetSeconds(instantMs) * 1e3;
  const local = new Date(instantMs + off);
  const midnightUtcGuess = Date.UTC(
    local.getUTCFullYear(),
    local.getUTCMonth(),
    local.getUTCDate()
  );
  const offAtMidnight = pragueOffsetSeconds(midnightUtcGuess) * 1e3;
  return midnightUtcGuess - offAtMidnight;
}
function pragueLocalToEpoch(year, month, day, hours, minutes, seconds) {
  const localAsUtc = Date.UTC(year, month, day, hours, minutes, seconds);
  let fallback = localAsUtc;
  for (const offSec of [7200, 3600]) {
    const utc = localAsUtc - offSec * 1e3;
    if (pragueOffsetSeconds(utc) === offSec) return utc;
    fallback = utc;
  }
  return fallback;
}
function gtfsSecondsToEpoch(serviceMidnightMs, sec) {
  const dayOffset = Math.floor(sec / 86400);
  const rem = sec - dayOffset * 86400;
  const h = Math.floor(rem / 3600);
  const mi = Math.floor(rem % 3600 / 60);
  const s = rem % 60;
  const midLocal = new Date(
    serviceMidnightMs + pragueOffsetSeconds(serviceMidnightMs) * 1e3
  );
  return pragueLocalToEpoch(
    midLocal.getUTCFullYear(),
    midLocal.getUTCMonth(),
    midLocal.getUTCDate() + dayOffset,
    h,
    mi,
    s
  );
}
function computeServiceMidnightMs(firstDepSec, lastArrSec, nowMs) {
  let best = pragueMidnightEpoch(nowMs);
  let bestDist = Number.POSITIVE_INFINITY;
  for (const dayDelta of [-1, 0, 1]) {
    const mid = pragueMidnightEpoch(nowMs + dayDelta * DAY_MS);
    const start = gtfsSecondsToEpoch(mid, firstDepSec);
    const end = gtfsSecondsToEpoch(mid, lastArrSec);
    const dist = nowMs < start ? start - nowMs : nowMs > end ? nowMs - end : 0;
    if (dist < bestDist) {
      bestDist = dist;
      best = mid;
    }
  }
  return best;
}
function serviceDayShiftMs(geometry, storedServiceMidnightMs, nowMs) {
  const stops = geometry.stops;
  if (stops.length === 0) return 0;
  const firstDepSec = Math.round(
    (stops[0].departureMs - storedServiceMidnightMs) / 1e3
  );
  const lastArrSec = Math.round(
    (stops[stops.length - 1].arrivalMs - storedServiceMidnightMs) / 1e3
  );
  const newMid = computeServiceMidnightMs(firstDepSec, lastArrSec, nowMs);
  return newMid - storedServiceMidnightMs;
}
var PROJECTION_BACK_TOL_M = 5;
function projectDistanceOnPolyline(coord, coordinates, cumDistM, minDistM = 0) {
  if (coordinates.length === 0) return Math.max(0, minDistM);
  if (coordinates.length === 1) return Math.max(cumDistM[0] ?? 0, minDistM);
  const lat0 = coord[1] * Math.PI / 180;
  const kx = Math.cos(lat0) * 111320;
  const ky = 110540;
  const px = coord[0] * kx;
  const py = coord[1] * ky;
  let bestDistM = cumDistM[0] ?? 0;
  let bestSq = Number.POSITIVE_INFINITY;
  let fallbackDistM = cumDistM[0] ?? 0;
  let fallbackSq = Number.POSITIVE_INFINITY;
  const lowerBound = minDistM - PROJECTION_BACK_TOL_M;
  for (let i = 0; i < coordinates.length - 1; i++) {
    const ax = coordinates[i][0] * kx;
    const ay = coordinates[i][1] * ky;
    const bx = coordinates[i + 1][0] * kx;
    const by = coordinates[i + 1][1] * ky;
    const dx = bx - ax;
    const dy = by - ay;
    const segLenSq = dx * dx + dy * dy;
    let t = segLenSq > 0 ? ((px - ax) * dx + (py - ay) * dy) / segLenSq : 0;
    if (t < 0) t = 0;
    else if (t > 1) t = 1;
    const cx = ax + t * dx;
    const cy = ay + t * dy;
    const distSq = (px - cx) * (px - cx) + (py - cy) * (py - cy);
    const a = cumDistM[i] ?? 0;
    const b = cumDistM[i + 1] ?? a;
    const projDistM = a + t * (b - a);
    if (distSq < fallbackSq) {
      fallbackSq = distSq;
      fallbackDistM = projDistM;
    }
    if (projDistM >= lowerBound && distSq < bestSq) {
      bestSq = distSq;
      bestDistM = projDistM;
    }
  }
  if (bestSq === Number.POSITIVE_INFINITY) {
    return Math.max(fallbackDistM, minDistM);
  }
  return Math.max(bestDistM, minDistM);
}
function servedToRouteGeometry(served, nowMs) {
  const geometry = {
    shapeId: served.shapeId,
    tripId: served.tripId,
    routeId: served.routeId,
    line: served.line,
    headsign: served.headsign,
    coordinates: served.coordinates.map((c) => [c[0], c[1]]),
    cumDistM: served.cumDistM,
    totalM: served.totalM,
    stops: served.stops.map((s) => ({
      ...s,
      coordinates: [s.coordinates[0], s.coordinates[1]]
    }))
  };
  const shift = serviceDayShiftMs(geometry, served.serviceMidnightMs, nowMs);
  if (shift === 0) return geometry;
  return {
    ...geometry,
    stops: geometry.stops.map((s) => ({
      ...s,
      arrivalMs: s.arrivalMs + shift,
      departureMs: s.departureMs + shift
    }))
  };
}

// src/lib/physics/adapter.ts
init_evaluator();

// src/lib/physics/fixForward.ts
init_evaluator();
var SMOOTH_CATCHUP_V_MS = 2;
var COAST_DECAY_MS = 2e4;
function fixForwardTauMs(track, fixS, fixAtMs, anchorMs) {
  if (track.length === 0) return 0;
  if (Number.isFinite(anchorMs) && !(fixAtMs > anchorMs)) return 0;
  if (!(fixS > evalTrajectory(track, fixAtMs))) return 0;
  const reach = crossingTimeMs(track, fixS);
  if (!Number.isFinite(reach)) return Number.POSITIVE_INFINITY;
  const tau = reach - fixAtMs;
  return tau > 0 ? tau : 0;
}
function trackEndSpeedMs(track) {
  const n = track.length >> 1;
  if (n < 2) return 0;
  const b = n - 1 << 1;
  const a = b - 2;
  const dtMs = track[b] - track[a];
  if (!(dtMs > 0)) return 0;
  const h = track.hermite;
  const j = (n - 2) * 3;
  const v2 = h && Number.isFinite(h[j]) ? (h[j] + 2 * h[j + 1] + 3 * h[j + 2]) * 1e3 / dtMs : (track[b + 1] - track[a + 1]) * 1e3 / dtMs;
  return v2 > 0 ? v2 : 0;
}
function coastDistM(vEndMs, sinceEndMs) {
  if (!(vEndMs > 0) || !(sinceEndMs > 0)) return 0;
  const decayS = COAST_DECAY_MS / 1e3;
  const tS = sinceEndMs < COAST_DECAY_MS ? sinceEndMs / 1e3 : decayS;
  return vEndMs * tS - vEndMs / (2 * decayS) * tS * tS;
}

// src/lib/physics/render.ts
init_evaluator();
init_bundle();
function trackFor(v2, mode) {
  if (mode === "smooth") return v2.smooth.length > 0 ? v2.smooth : v2.opinion;
  return v2.opinion.length > 0 ? v2.opinion : v2.smooth;
}
function catchupVMsFor(mode) {
  return mode === "fixed" ? Number.POSITIVE_INFINITY : SMOOTH_CATCHUP_V_MS;
}
function curveWithCoast(track, tMs, endMs) {
  const s = evalTrajectory(track, tMs);
  return tMs > endMs ? s + coastDistM(trackEndSpeedMs(track), tMs - endMs) : s;
}
function renderedDistM(track, tMs, catchupVMs, fixS, fixAtMs, anchorMs) {
  const endMs = trackEndMs(track);
  const tau = fixForwardTauMs(track, fixS, fixAtMs, anchorMs);
  if (tau === 0) return curveWithCoast(track, tMs, endMs);
  if (tau === Number.POSITIVE_INFINITY) {
    const raw = curveWithCoast(track, tMs, endMs);
    if (raw >= fixS) return raw;
    if (catchupVMs === Number.POSITIVE_INFINITY) return fixS;
    const walked = raw + catchupVMs * Math.max(0, (tMs - allowanceDatumMs(track, fixAtMs)) / 1e3);
    return walked < fixS ? walked : fixS;
  }
  const shifted = curveWithCoast(track, tMs + tau, endMs);
  if (catchupVMs === Number.POSITIVE_INFINITY) return shifted;
  const capped = curveWithCoast(track, tMs, endMs) + catchupVMs * Math.max(0, (tMs - allowanceDatumMs(track, fixAtMs)) / 1e3);
  return capped < shifted ? capped : shifted;
}
function allowanceDatumMs(track, fixAtMs) {
  const start = trackStartMs(track);
  return Number.isFinite(fixAtMs) && fixAtMs > start ? fixAtMs : start;
}
function fixForwardAppliedM(track, tMs, catchupVMs, fixS, fixAtMs, anchorMs) {
  return renderedDistM(track, tMs, catchupVMs, fixS, fixAtMs, anchorMs) - curveWithCoast(track, tMs, trackEndMs(track));
}
function renderTram(v2, serverNowMs, mode, fixS = Number.NaN, fixAtMs = Number.NaN) {
  if (mode === "smooth" && v2.motionPolicy === "continuous-v1") fixS = Number.NaN;
  const track = trackFor(v2, mode);
  const tau = fixForwardTauMs(track, fixS, fixAtMs, v2.anchorMs);
  return {
    s: renderedDistM(track, serverNowMs, catchupVMsFor(mode), fixS, fixAtMs, v2.anchorMs),
    pastHorizon: tau === Number.POSITIVE_INFINITY || serverNowMs + tau > trackEndMs(track)
  };
}
function renderDistM(v2, serverNowMs, mode, fixS = Number.NaN, fixAtMs = Number.NaN) {
  if (v2 === void 0) return Number.NaN;
  if (mode === "smooth" && v2.motionPolicy === "continuous-v1") fixS = Number.NaN;
  return renderedDistM(
    trackFor(v2, mode),
    serverNowMs,
    catchupVMsFor(mode),
    fixS,
    fixAtMs,
    v2.anchorMs
  );
}
function renderSpeedMs(v2, serverNowMs, mode, fixS = Number.NaN, fixAtMs = Number.NaN, halfWindowMs = SPEED_HALF_WINDOW_MS) {
  const track = trackFor(v2, mode);
  if (track.length === 0) return 0;
  if (mode === "smooth" && v2.motionPolicy === "continuous-v1") fixS = Number.NaN;
  const catchup = catchupVMsFor(mode);
  const a = v2.anchorMs;
  const before = renderedDistM(track, serverNowMs - halfWindowMs, catchup, fixS, fixAtMs, a);
  const after = renderedDistM(track, serverNowMs + halfWindowMs, catchup, fixS, fixAtMs, a);
  const speed = (after - before) * 500 / halfWindowMs;
  return speed > 0 ? speed : 0;
}
function smoothFixedDeltaM(v2, serverNowMs) {
  if (v2.smooth.length === 0 || v2.opinion.length === 0) return Number.NaN;
  return Math.abs(
    evalTrajectory(v2.smooth, serverNowMs) - evalTrajectory(v2.opinion, serverNowMs)
  );
}

// src/lib/physics/adapter.ts
var DWELL_SPEED_KMH = 1;
var DWELL_NEAR_STOP_M = 30;
function nearestStopIndex(stops, s) {
  const n = stops.length;
  if (n === 0) return -1;
  let lo = 0;
  let hi = n;
  while (lo < hi) {
    const mid = lo + hi >> 1;
    if (stops[mid].distM < s) lo = mid + 1;
    else hi = mid;
  }
  if (lo === 0) return 0;
  if (lo === n) return n - 1;
  return stops[lo].distM - s < s - stops[lo - 1].distM ? lo : lo - 1;
}
function nextStopIndex(stops, s) {
  const n = stops.length;
  let lo = 0;
  let hi = n;
  while (lo < hi) {
    const mid = lo + hi >> 1;
    if (stops[mid].distM <= s) lo = mid + 1;
    else hi = mid;
  }
  return lo < n ? lo : -1;
}
function clampToShape(s, geometry) {
  if (!Number.isFinite(s)) return 0;
  if (!geometry) return s;
  return s < 0 ? 0 : s > geometry.totalM ? geometry.totalM : s;
}
var SLEW_MAX_MS = 25;
var SLEW_CATCHUP_ACCEL_MS2 = 2.5;
var SLEW_MAX_FRAME_GAP_MS = 5e3;
var NAIVE_HORIZON_S = 60;
function guardedDistM(s, nowMs, prevS, prevAtMs, allowJump, prevSpeedMs = 0) {
  if (allowJump) return s;
  const dtMs = nowMs - prevAtMs;
  if (dtMs < 0 || dtMs > SLEW_MAX_FRAME_GAP_MS) return s;
  const dtS = dtMs / 1e3;
  const previousSpeed = Number.isFinite(prevSpeedMs) ? Math.max(0, prevSpeedMs) : 0;
  const reachableSpeed = Math.min(
    SLEW_MAX_MS,
    previousSpeed + SLEW_CATCHUP_ACCEL_MS2 * dtS
  );
  return Math.max(prevS, Math.min(s, prevS + reachableSpeed * dtS));
}
function naiveDistM(fixS, fixAtMs, nowMs, paceMs) {
  return fixS + Math.max(0, paceMs) * Math.max(0, Math.min(NAIVE_HORIZON_S, (nowMs - fixAtMs) / 1e3));
}
function adaptTram(input) {
  const { snapshot, model, geometry, serverNowMs, mode } = input;
  const vehicle = input.vehicle !== void 0 && input.vehicle.tripId === snapshot.tripId ? input.vehicle : void 0;
  const hasGeometry = geometry !== void 0;
  const fixS = snapshot.shapeDistM;
  const fixAtMs = snapshot.observedAtMs;
  const observedDist = clampToShape(fixS, geometry);
  const observedPosition = geometry ? pointAt(geometry.coordinates, geometry.cumDistM, observedDist) : [snapshot.coordinates[0], snapshot.coordinates[1]];
  const observedBearing = geometry ? bearingAt(geometry.coordinates, geometry.cumDistM, observedDist) : snapshot.bearing ?? 0;
  let simDistM;
  let pastHorizon;
  let simSpeedKmh = 0;
  let fixedDistM = null;
  let deviationM = null;
  if (vehicle) {
    const rendered = renderTram(vehicle, serverNowMs, mode, fixS, fixAtMs);
    simDistM = clampToShape(rendered.s, geometry);
    pastHorizon = rendered.pastHorizon;
    simSpeedKmh = renderSpeedMs(vehicle, serverNowMs, mode, fixS, fixAtMs) * 3.6;
    fixedDistM = vehicle.opinion.length > 0 ? clampToShape(evalTrajectory(vehicle.opinion, serverNowMs), geometry) : null;
    const delta = smoothFixedDeltaM(vehicle, serverNowMs);
    deviationM = Number.isFinite(delta) ? delta : null;
  } else {
    const paceMs = input.observedPaceMs ?? 0;
    const aheadS = (serverNowMs - fixAtMs) / 1e3;
    const advanceM = paceMs > 0 && aheadS > 0 && hasGeometry ? paceMs * (aheadS < NAIVE_HORIZON_S ? aheadS : NAIVE_HORIZON_S) : 0;
    simDistM = clampToShape(
      (input.fallbackFixDistM ?? fixS) + advanceM,
      geometry
    );
    if (advanceM > 0 && aheadS < NAIVE_HORIZON_S && simDistM < (geometry?.totalM ?? Infinity)) {
      simSpeedKmh = paceMs * 3.6;
    }
    pastHorizon = true;
  }
  const renderTargetDistM = simDistM;
  const guard = mode === "smooth" ? input.guard : void 0;
  const presentationNowMs = input.presentationNowMs ?? serverNowMs;
  if (guard)
    simDistM = clampToShape(
      guardedDistM(
        simDistM,
        presentationNowMs,
        guard.prevS,
        guard.prevAtMs,
        guard.allowJump,
        (guard.prevSpeedKmh ?? 0) / 3.6
      ),
      geometry
    );
  const renderGuardActive = Math.abs(simDistM - renderTargetDistM) > 1e-6;
  if (guard && !guard.allowJump && presentationNowMs >= guard.prevAtMs && presentationNowMs - guard.prevAtMs <= SLEW_MAX_FRAME_GAP_MS) {
    const dtMs = presentationNowMs - guard.prevAtMs;
    simSpeedKmh = dtMs > 0 ? Math.max(0, (simDistM - guard.prevS) * 3600 / dtMs) : guard.prevSpeedKmh ?? 0;
  }
  if (!geometry || simDistM >= geometry.totalM) simSpeedKmh = 0;
  const presented = input.present?.(simDistM, simSpeedKmh);
  if (presented) {
    simDistM = presented.s;
    simSpeedKmh = presented.v * 3.6;
  }
  const position = presented?.position ?? (geometry ? pointAt(geometry.coordinates, geometry.cumDistM, simDistM) : [snapshot.coordinates[0], snapshot.coordinates[1]]);
  const bearing = presented?.bearing ?? (geometry ? bearingAt(geometry.coordinates, geometry.cumDistM, simDistM) : snapshot.bearing ?? 0);
  let phase = "unknown";
  let nextStopName = null;
  let nextStopEtaS = null;
  if (geometry && geometry.stops.length > 0 && vehicle) {
    const nearIdx = nearestStopIndex(geometry.stops, simDistM);
    const near = nearIdx >= 0 ? geometry.stops[nearIdx] : null;
    const standing = simSpeedKmh <= DWELL_SPEED_KMH;
    if (standing && near && Math.abs(near.distM - simDistM) <= DWELL_NEAR_STOP_M) {
      phase = near.isTerminal ? "terminal" : "dwell";
    } else {
      phase = "cruise";
    }
    const aheadIdx = nextStopIndex(geometry.stops, simDistM);
    if (aheadIdx >= 0) {
      const stop = geometry.stops[aheadIdx];
      nextStopName = stop.name;
      const smoothTrack = vehicle.smooth.length > 0 ? vehicle.smooth : vehicle.opinion;
      const smoothRenderedS = renderedDistM(
        smoothTrack,
        serverNowMs,
        SMOOTH_CATCHUP_V_MS,
        vehicle.motionPolicy === "continuous-v1" ? Number.NaN : fixS,
        fixAtMs,
        vehicle.anchorMs
      );
      const leadMs = crossingTimeMs(smoothTrack, smoothRenderedS) - serverNowMs;
      const tauEffMs = Number.isFinite(leadMs) && leadMs > 0 ? leadMs : 0;
      const crossMs = crossingTimeMs(smoothTrack, stop.distM) - tauEffMs;
      if (Number.isFinite(crossMs)) {
        const etaS = (crossMs - serverNowMs) / 1e3;
        nextStopEtaS = etaS > 0 ? etaS : 0;
      }
    }
  } else if (geometry && geometry.stops.length > 0) {
    const aheadIdx = nextStopIndex(geometry.stops, simDistM);
    if (aheadIdx >= 0) nextStopName = geometry.stops[aheadIdx].name;
  }
  return {
    renderTargetDistM,
    renderGuardActive: presented ? Math.abs(simDistM - renderTargetDistM) > 1e-6 : renderGuardActive,
    key: snapshot.key,
    snapshot,
    model,
    simDistM,
    simSpeedKmh,
    position,
    bearing,
    phase,
    observedPosition,
    observedBearing,
    deviationM,
    fixedDistM,
    pastHorizon,
    nextStopName,
    nextStopEtaS,
    hasGeometry
  };
}

// src/lib/physics/fleet.ts
init_evaluator();

// src/lib/physics/observationProjection.ts
function observationCorridor(fix, geometry) {
  if (!fix.lastStopId || !fix.nextStopId || !Number.isFinite(fix.lastStopSequence) || !Number.isFinite(fix.nextStopSequence))
    return null;
  const current = geometry.stops.filter(
    (s) => s.stopId === fix.lastStopId && s.sequence === fix.lastStopSequence
  );
  const next = geometry.stops.filter(
    (s) => s.stopId === fix.nextStopId && s.sequence === fix.nextStopSequence
  );
  if (current.length !== 1 || next.length !== 1 || next[0].sequence <= current[0].sequence || next[0].distM <= current[0].distM)
    return null;
  const currentIndex = geometry.stops.indexOf(current[0]);
  const previous = currentIndex > 0 ? geometry.stops[currentIndex - 1].distM : 0;
  return {
    lo: Math.max(previous, current[0].distM - 150),
    hi: Math.min(geometry.totalM, next[0].distM)
  };
}
function projectInCorridor(point, geometry, corridor, maxOffsetM) {
  if (!Array.isArray(point) || point.length !== 2 || !point.every(Number.isFinite) || geometry.coordinates.length < 2 || geometry.cumDistM.length !== geometry.coordinates.length || !(corridor.hi > corridor.lo))
    return null;
  const kx = 111320 * Math.cos(point[1] * Math.PI / 180), ky = 111320;
  const lo = Math.max(0, corridor.lo), hi = Math.min(geometry.totalM, corridor.hi);
  if (!(hi > lo)) return null;
  const first = segmentIndexAt(geometry.cumDistM, lo), last = segmentIndexAt(geometry.cumDistM, hi);
  const candidates = [];
  let bestS = 0, bestD = Infinity;
  for (let i = first; i <= last && i < geometry.coordinates.length - 1; i++) {
    const ds = geometry.cumDistM[i + 1] - geometry.cumDistM[i];
    if (!(ds > 0)) continue;
    const a = geometry.coordinates[i], b = geometry.coordinates[i + 1];
    const ax = (a[0] - point[0]) * kx, ay = (a[1] - point[1]) * ky;
    const dx = (b[0] - a[0]) * kx, dy = (b[1] - a[1]) * ky;
    const len = dx * dx + dy * dy;
    if (!(len > 0)) continue;
    const t = Math.max(
      Math.max(0, (lo - geometry.cumDistM[i]) / ds),
      Math.min(
        Math.min(1, (hi - geometry.cumDistM[i]) / ds),
        -(ax * dx + ay * dy) / len
      )
    );
    const d = Math.hypot(ax + t * dx, ay + t * dy), s = geometry.cumDistM[i] + t * ds;
    candidates.push({ s, d });
    if (d < bestD) {
      bestD = d;
      bestS = s;
    }
  }
  if (!Number.isFinite(bestD) || bestD > maxOffsetM) return null;
  if (candidates.some((c) => Math.abs(c.s - bestS) > 30 && c.d <= bestD + 3))
    return null;
  return { s: bestS, offsetM: bestD, corridorLoM: lo, corridorHiM: hi };
}
function projectObservation(fix, geometry) {
  if (!geometry) return null;
  const corridor = observationCorridor(fix, geometry);
  return corridor ? projectInCorridor(fix.coordinates, geometry, corridor, 30) : null;
}
function sameGeometryAxis(a, b) {
  if (a === b) return true;
  if (a.totalM !== b.totalM || a.coordinates.length !== b.coordinates.length || a.cumDistM.length !== b.cumDistM.length)
    return false;
  for (let i = 0; i < a.coordinates.length; i++)
    if (a.cumDistM[i] !== b.cumDistM[i] || a.coordinates[i][0] !== b.coordinates[i][0] || a.coordinates[i][1] !== b.coordinates[i][1])
      return false;
  return true;
}

// src/lib/physics/presentation.ts
var PRESENTATION_LIMITS = Object.freeze({
  speed: 25,
  acceleration: 2.5,
  braking: 2.5,
  jerk: 4
});
var clamp = (n, lo, hi) => Math.max(lo, Math.min(hi, n));
function presentationBrakingDistance(v2, a, b = PRESENTATION_LIMITS.braking, j = PRESENTATION_LIMITS.jerk) {
  if (v2 <= 0) return 0;
  let s = 0, speed = v2, acceleration = a;
  const step = (t, jerk) => {
    s += speed * t + acceleration * t * t / 2 + jerk * t * t * t / 6;
    speed += acceleration * t + jerk * t * t / 2;
    acceleration += jerk * t;
  };
  const peak = Math.sqrt(Math.max(0, j * v2 + a * a / 2));
  const p = Math.min(b, peak);
  step(Math.max(0, (a + p) / j), -j);
  if (peak > b) step(Math.max(0, (speed - p * p / (2 * j)) / p), 0);
  step(p / j, j);
  return Math.max(0, s);
}
function advancePresentation(p, dt, targetS, targetV, targetA, stopS) {
  if (!(dt > 0) || dt > 5 || !Number.isFinite(targetS)) return;
  const limits = PRESENTATION_LIMITS;
  const count = Math.ceil(dt / 0.05);
  const h = dt / count;
  for (let n = 0; n < count; n++) {
    const target = targetS - Math.max(0, targetV) * (dt - (n + 1) * h);
    let desired = clamp(
      targetA + 0.1 * (target - p.s) + 0.65 * (targetV - p.v),
      -limits.braking,
      limits.acceleration
    );
    if (stopS !== null && stopS - p.s <= presentationBrakingDistance(p.v, p.a) + p.v * h + 0.05)
      desired = -limits.braking;
    const lower = Math.max(-limits.braking, p.a - limits.jerk * h);
    const upper = Math.min(limits.acceleration, p.a + limits.jerk * h);
    let nextA = clamp(desired, lower, upper);
    const lowRoom = (a) => p.v + (p.a + a) * h / 2 - Math.min(0, a) ** 2 / (2 * limits.jerk);
    if (lowRoom(nextA) < 0) {
      let lo = nextA, hi = upper;
      for (let i = 0; i < 24; i++) {
        const mid = (lo + hi) / 2;
        if (lowRoom(mid) < 0) lo = mid;
        else hi = mid;
      }
      nextA = hi;
    }
    const highRoom = (a) => limits.speed - p.v - (p.a + a) * h / 2 - Math.max(0, a) ** 2 / (2 * limits.jerk);
    if (highRoom(nextA) < 0) {
      let lo = lower, hi = nextA;
      for (let i = 0; i < 24; i++) {
        const mid = (lo + hi) / 2;
        if (highRoom(mid) < 0) hi = mid;
        else lo = mid;
      }
      nextA = lo;
    }
    p.s += Math.max(
      0,
      p.v * h + p.a * h * h / 2 + (nextA - p.a) * h * h / 6
    );
    p.v = clamp(p.v + (p.a + nextA) * h / 2, 0, limits.speed);
    p.a = nextA;
  }
}
function advanceTransition(t, now, nextToken) {
  if (t.stage === "out") {
    const opacity2 = (t.startOpacity ?? 1) * Math.max(0, 1 - (now - t.atMs) / 300);
    if (opacity2 === 0) {
      t.stage = "old-zero";
      t.hiddenFrameId = nextToken();
      t.acknowledged = false;
    }
    return { opacity: opacity2, rebase: false, done: false };
  }
  if (t.stage === "old-zero") {
    if (!t.acknowledged) return { opacity: 0, rebase: false, done: false };
    t.stage = "new-zero";
    t.hiddenFrameId = nextToken();
    t.acknowledged = false;
    return { opacity: 0, rebase: true, done: false };
  }
  if (t.stage === "new-zero") {
    if (t.acknowledged) {
      t.stage = "in";
      t.atMs = now;
      t.hiddenFrameId = void 0;
    }
    return { opacity: 0, rebase: false, done: false };
  }
  const opacity = Math.min(1, Math.max(0, (now - t.atMs) / 400));
  return { opacity, rebase: false, done: opacity === 1 };
}

// src/lib/physics/fleet.ts
function worldDistance(a, b) {
  return Math.hypot(
    (a[0] - b[0]) * 111320 * Math.cos((a[1] + b[1]) * Math.PI / 360),
    (a[1] - b[1]) * 111320
  );
}
function distInBbox(geometry, d, bbox) {
  const { coordinates, cumDistM } = geometry;
  const n = coordinates.length;
  if (n === 0) return false;
  const total = cumDistM[n - 1];
  const clamped = d < 0 ? 0 : d > total ? total : d;
  const i = segmentIndexAt(cumDistM, clamped);
  const a = coordinates[i];
  let lng = a[0];
  let lat = a[1];
  if (i + 1 < n) {
    const segLen = cumDistM[i + 1] - cumDistM[i];
    if (segLen > 1e-9) {
      const t = (clamped - cumDistM[i]) / segLen;
      const b = coordinates[i + 1];
      lng = a[0] + (b[0] - a[0]) * t;
      lat = a[1] + (b[1] - a[1]) * t;
    }
  }
  return lng >= bbox[0] && lng <= bbox[2] && lat >= bbox[1] && lat <= bbox[3];
}
var TramFleet = class {
  resolveModel;
  trajectories;
  /** Live fleet, rebuilt each ingest — departed vehicles drop out by construction. */
  snapshots = /* @__PURE__ */ new Map();
  geometries = /* @__PURE__ */ new Map();
  coherence = /* @__PURE__ */ new Map();
  models = /* @__PURE__ */ new Map();
  /**
   * Observed pace per vehicle, from consecutive AVL fixes — the input of the
   * client's NAIVE fallback (adapter.ts): when a tram has no curves at all,
   * it dead-reckons from its last fix at this speed instead of freezing.
   * Bookkeeping only (fix pairs, like the old calibration fold) — not physics.
   */
  paces = /* @__PURE__ */ new Map();
  fallbackFixes = /* @__PURE__ */ new Map();
  inputAvailability = /* @__PURE__ */ new Map();
  displays = /* @__PURE__ */ new Map();
  transitionSerial = 0;
  hiddenFrameSerial = 0;
  modeChanges = 0;
  /**
   * Teleport watch: last rendered position per vehicle (in the active render
   * mode) + the last jump that no plausible motion explains. Updated in-place
   * only for explicit displayed frames. UI/diagnostics reads do not advance it.
   * Mode switches and trip changes legitimately move the marker, so both
   * reset the tracking instead of recording a phantom teleport.
   */
  jumps = /* @__PURE__ */ new Map();
  /**
   * Profile-emission log per vehicle (devtools): which source produced each
   * adopted emission and when. The naive→ml switch lives ~1–3 s — far too
   * brief for a human watching a 10 Hz readout — so the overlay renders this
   * ring instead of the instantaneous value alone.
   */
  profileLog = /* @__PURE__ */ new Map();
  /**
   * ЖУРНАЛ (девтулсы): состояние переходов + кольцо событий на трамвай.
   * Живёт только для ключей, которые читают через getDiagnostics; ключи, не
   * читанные 5 минут, выметаются на ingest.
   */
  eventLogs = /* @__PURE__ */ new Map();
  /** Render mode mirrored from the settings store by the runtime. */
  mode = "smooth";
  constructor(opts) {
    this.resolveModel = opts.resolveModel;
    this.trajectories = opts.trajectories;
  }
  /** Selected render mode (settings). Affects every getter that omits one. */
  setMode(mode) {
    if (this.mode !== mode) {
      this.modeChanges++;
      this.jumps.clear();
      this.displays.clear();
    }
    this.mode = mode;
  }
  get renderMode() {
    return this.mode;
  }
  /** Map cadence hook; the bounded transition state is integrated below. */
  hasPresentationTransitions(keys) {
    if (keys) {
      for (const key of keys) if (this.displays.get(key)?.transition) return true;
      return false;
    }
    for (const state of this.displays.values())
      if (state.transition) return true;
    return false;
  }
  acknowledgePresentationHidden(key, hiddenFrameId) {
    const t = this.displays.get(key)?.transition;
    if (t && t.hiddenFrameId === hiddenFrameId && (t.stage === "old-zero" || t.stage === "new-zero"))
      t.acknowledged = true;
  }
  /** Live vehicle count (status tile). */
  get size() {
    return this.snapshots.size;
  }
  /**
   * One fresh snapshot batch. Pure bookkeeping: identity, model and the trip
   * geometry currently resolvable for each key. No physics happens here — the
   * curves arrive on their own 5 s cadence and are read at render time.
   */
  ingest(snapshots, getGeometry, receivedAtMs = Date.now()) {
    const nextSnapshots = /* @__PURE__ */ new Map();
    const nextGeometries = /* @__PURE__ */ new Map();
    const nextCoherence = /* @__PURE__ */ new Map();
    const nextModels = /* @__PURE__ */ new Map();
    const nextPaces = /* @__PURE__ */ new Map();
    const nextFallbackFixes = /* @__PURE__ */ new Map();
    for (const incoming of snapshots) {
      const prior = this.snapshots.get(incoming.key);
      const s = prior && prior.tripId === incoming.tripId && incoming.observedAtMs < prior.observedAtMs ? prior : incoming;
      nextSnapshots.set(s.key, s);
      const geometry = getGeometry(s.tripId);
      const cached = this.coherence.get(s.key);
      const old = cached?.fix;
      const unchanged = old && cached?.geometry === geometry && old.tripId === s.tripId && old.observedAtMs === s.observedAtMs && old.shapeDistM === s.shapeDistM && old.coordinates[0] === s.coordinates[0] && old.coordinates[1] === s.coordinates[1] && old.lastStopId === s.lastStopId && old.nextStopId === s.nextStopId && old.lastStopSequence === s.lastStopSequence && old.nextStopSequence === s.nextStopSequence;
      const coherence = unchanged ? cached.result : assessGeometryCoherence(s, geometry);
      const available = this.inputAvailability.get(s.key);
      this.inputAvailability.set(s.key, {
        fixAtMs: unchanged && available ? available.fixAtMs : receivedAtMs,
        geometryAtMs: cached?.geometry === geometry && available ? available.geometryAtMs : receivedAtMs
      });
      nextCoherence.set(s.key, { fix: s, geometry, result: coherence });
      if (geometry && coherence.status !== "invalid")
        nextGeometries.set(s.key, geometry);
      const displayed = this.jumps.get(s.key);
      if (displayed?.geometry && geometry && displayed.tripId === s.tripId && coherence.status !== "invalid" && displayed.geometry !== geometry && sameGeometryAxis(displayed.geometry, geometry)) {
        displayed.geometry = geometry;
      }
      const priorFallback = this.fallbackFixes.get(s.key);
      const reuseProjection = unchanged && old?.lastStopSequence === s.lastStopSequence && old?.nextStopSequence === s.nextStopSequence && priorFallback;
      const projection = reuseProjection ? null : coherence.status !== "invalid" ? projectObservation(s, geometry) : null;
      const fallback = reuseProjection || {
        s: projection?.s ?? s.shapeDistM,
        projected: projection !== null
      };
      nextFallbackFixes.set(s.key, fallback);
      const known = this.models.get(s.key);
      nextModels.set(s.key, known ?? this.resolveModel(s));
      const prevPace = this.paces.get(s.key);
      if (!prevPace || prevPace.tripId !== s.tripId || !!prevPace.projected !== fallback.projected || coherence.status === "invalid" || cached?.result.status === "invalid") {
        nextPaces.set(s.key, {
          tripId: s.tripId,
          s: fallback.s,
          atMs: s.observedAtMs,
          vMs: 0,
          projected: fallback.projected
        });
      } else if (s.observedAtMs > prevPace.atMs) {
        const dtS = (s.observedAtMs - prevPace.atMs) / 1e3;
        const dsM = fallback.s - prevPace.s;
        if (dtS < 4 && dsM >= 0) {
          nextPaces.set(s.key, prevPace);
        } else {
          const vMs = dtS <= 300 && dsM >= 0 && !(fallback.projected && dsM < 1.5) ? Math.min(16.7, dsM / dtS) : 0;
          nextPaces.set(s.key, {
            tripId: s.tripId,
            s: fallback.s,
            atMs: s.observedAtMs,
            vMs,
            projected: fallback.projected
          });
        }
      } else {
        nextPaces.set(s.key, prevPace);
      }
    }
    this.snapshots = nextSnapshots;
    this.geometries = nextGeometries;
    this.coherence = nextCoherence;
    this.models = nextModels;
    this.paces = nextPaces;
    this.fallbackFixes = nextFallbackFixes;
    for (const key of this.inputAvailability.keys()) if (!nextSnapshots.has(key)) this.inputAvailability.delete(key);
    for (const key of this.jumps.keys()) {
      if (!nextSnapshots.has(key)) this.jumps.delete(key);
    }
    for (const key of this.displays.keys())
      if (!nextSnapshots.has(key)) this.displays.delete(key);
    for (const key of this.profileLog.keys()) {
      if (!nextSnapshots.has(key)) this.profileLog.delete(key);
    }
    const staleLogMs = Date.now() - 5 * 6e4;
    for (const [key, log2] of this.eventLogs) {
      if (!nextSnapshots.has(key) || log2.lastQueryMs < staleLogMs)
        this.eventLogs.delete(key);
    }
  }
  /** Trip geometry currently driving a tram's rendering. */
  getGeometry(key) {
    if (this.mode === "smooth" && this.displays.has(key))
      return this.displays.get(key).geometry;
    return this.geometries.get(key);
  }
  /** Raw snapshot for a key (identity/AVL context without building a state). */
  getSnapshot(key) {
    return this.snapshots.get(key);
  }
  /** Current source geometry, independent of an outgoing displayed axis. */
  getPredictionGeometry(key) {
    return this.geometries.get(key);
  }
  /** Pure source prediction for recording while the map is hidden. A record
   * timestamp must never be paired with an old, no-longer-visible frame. */
  getPredictionState(key, localNowMs = Date.now(), mode = this.mode) {
    const snapshot = this.snapshots.get(key);
    return snapshot ? this.prediction(snapshot, this.trajectories.nowMs(localNowMs), mode, localNowMs) : void 0;
  }
  getPredictionStates(localNowMs = Date.now(), mode = this.mode) {
    const serverNow = this.trajectories.nowMs(localNowMs);
    const out = [];
    for (const snapshot of this.snapshots.values())
      out.push(this.prediction(snapshot, serverNow, mode, localNowMs));
    return out;
  }
  prediction(snapshot, serverNowMs, mode, localNowMs) {
    const vehicle = this.vehicleFor(snapshot);
    const state = adaptTram({
      snapshot,
      model: this.models.get(snapshot.key) ?? this.resolveModel(snapshot),
      geometry: this.geometries.get(snapshot.key),
      vehicle,
      serverNowMs,
      mode,
      observedPaceMs: this.paces.get(snapshot.key)?.vMs ?? 0,
      fallbackFixDistM: this.fallbackFixes.get(snapshot.key)?.s
    });
    const inputs = this.inputAvailability.get(snapshot.key);
    const receipt = this.trajectories.getVehicleReceivedAtMs(snapshot.key);
    const needsFix = !vehicle || mode !== "smooth" || vehicle.motionPolicy !== "continuous-v1";
    state.predictionEvaluatedAtMs = localNowMs;
    state.predictionInputsAvailableAtMs = inputs && (!vehicle || Number.isFinite(receipt)) ? Math.max(this.trajectories.clock.inputsAvailableAtMs, inputs.geometryAtMs, needsFix ? inputs.fixAtMs : -Infinity, vehicle ? receipt : -Infinity) : null;
    return state;
  }
  /**
   * One tram's public state at `localNowMs` (device clock in, server-corrected
   * inside). Undefined when the key is not in the live fleet.
   */
  getState(key, localNowMs = Date.now(), mode = this.mode, recordFrame = false) {
    const snapshot = this.snapshots.get(key);
    if (!snapshot) return void 0;
    return this.build(
      snapshot,
      this.trajectories.nowMs(localNowMs),
      mode,
      recordFrame,
      localNowMs
    );
  }
  /** The whole fleet. Only Mapbox/bench frame producers pass recordFrame=true;
   * UI, calibration and future probes keep the default read-only behavior. */
  getStates(localNowMs = Date.now(), mode = this.mode, recordFrame = false) {
    const serverNow = this.trajectories.nowMs(localNowMs);
    const out = [];
    for (const snapshot of this.snapshots.values()) {
      out.push(this.build(snapshot, serverNow, mode, recordFrame, localNowMs));
    }
    return out;
  }
  /**
   * Viewport-culled states for close-zoom pushes: every tram is evaluated
   * (arithmetic only) but only those inside `bbox` — plus the selected and
   * followed trams, which overlays need wherever they are — become full public
   * state objects. This is the "cull before you allocate" rule of perf #5.
   */
  getStatesInBounds(localNowMs, bbox, selectedKey, followKey, mode = this.mode) {
    const serverNow = this.trajectories.nowMs(localNowMs);
    const out = [];
    for (const snapshot of this.snapshots.values()) {
      const key = snapshot.key;
      if (key !== selectedKey && key !== followKey) {
        const displayed = mode === this.mode && mode === "smooth" ? this.displays.get(key) : void 0;
        if (displayed) {
          const c = displayed.position;
          if (c[0] >= bbox[0] && c[0] <= bbox[2] && c[1] >= bbox[1] && c[1] <= bbox[3]) {
            out.push(this.build(snapshot, serverNow, mode, true, localNowMs));
            continue;
          }
        }
        const geometry = this.geometries.get(key);
        if (geometry) {
          const vehicle = this.vehicleFor(snapshot);
          const target = vehicle ? renderDistM(
            vehicle,
            serverNow,
            mode,
            snapshot.shapeDistM,
            snapshot.observedAtMs
          ) : naiveDistM(
            this.fallbackFixes.get(key)?.s ?? snapshot.shapeDistM,
            snapshot.observedAtMs,
            serverNow,
            this.paces.get(key)?.vMs ?? 0
          );
          const d = displayed ? target : this.guardedDistance(snapshot, mode, localNowMs, target);
          if (!distInBbox(geometry, d, bbox)) continue;
        } else {
          const c = snapshot.coordinates;
          if (c[0] < bbox[0] || c[0] > bbox[2] || c[1] < bbox[1] || c[1] > bbox[3])
            continue;
        }
      }
      out.push(this.build(snapshot, serverNow, mode, true, localNowMs));
    }
    return out;
  }
  /** Curves for a snapshot, or undefined when none apply to its current trip. */
  vehicleFor(snapshot) {
    if (this.coherence.get(snapshot.key)?.result.status === "invalid")
      return void 0;
    const v2 = this.trajectories.getVehicle(snapshot.key);
    return v2 !== void 0 && v2.tripId === snapshot.tripId ? v2 : void 0;
  }
  /** Culling follows the committed world position, even while an old axis is
   * fading out. It must never advance presentation just to test visibility. */
  guardedDistance(snapshot, mode, _nowMs, target) {
    const p = mode === this.mode && mode === "smooth" ? this.displays.get(snapshot.key) : void 0;
    return p?.comparable ? p.s : target;
  }
  present(snapshot, now, serverNow, target, targetSpeedKmh, record) {
    const geometry = this.geometries.get(snapshot.key);
    const vehicle = this.vehicleFor(snapshot);
    const position = () => geometry ? pointAt(geometry.coordinates, geometry.cumDistM, target) : [...snapshot.coordinates];
    const velocity = Math.max(
      0,
      Math.min(PRESENTATION_LIMITS.speed, targetSpeedKmh / 3.6)
    );
    const existing = this.displays.get(snapshot.key);
    if (!existing) {
      const p2 = {
        s: target,
        v: velocity,
        a: 0,
        atMs: now,
        tripId: snapshot.tripId,
        geometry,
        position: position(),
        bearing: geometry ? bearingAt(geometry.coordinates, geometry.cumDistM, target) : snapshot.bearing ?? 0,
        comparable: true,
        transition: null,
        opacity: 1,
        lookAtMs: -Infinity,
        lookEmissionMs: -1,
        stopS: null,
        rebaseCount: 0,
        lastWorldJumpM: null,
        lastRebaseAtMs: null
      };
      if (record) this.displays.set(snapshot.key, p2);
      return p2;
    }
    const p = record ? existing : { ...existing };
    const dt = (now - p.atMs) / 1e3;
    if (dt <= 0) return p;
    let forced = p.tripId !== snapshot.tripId ? "trip-change" : dt > 5 ? "resume-gap" : null;
    if (p.tripId === snapshot.tripId && p.geometry !== geometry) {
      if (p.geometry && geometry && sameGeometryAxis(p.geometry, geometry)) {
        p.geometry = geometry;
      } else if (record && p.geometry && geometry && !p.transition) {
        const corridor = observationCorridor(snapshot, geometry);
        const projection = corridor ? projectInCorridor(p.position, geometry, corridor, 10) : null;
        if (projection && projection.offsetM < 0.25) {
          p.s = projection.s;
          p.geometry = geometry;
        } else forced = "incompatible-geometry";
      } else forced = "incompatible-geometry";
    }
    p.comparable = p.tripId === snapshot.tripId && p.geometry === geometry;
    if (forced && (!p.transition || p.transition.stage === "in") && record)
      p.transition = {
        id: ++this.transitionSerial,
        reason: forced,
        stage: "out",
        atMs: now,
        hiddenFrameId: void 0,
        acknowledged: false,
        startOpacity: p.opacity
      };
    if (!p.comparable && p.transition?.stage === "new-zero" && record) {
      const nextPosition = position();
      p.lastWorldJumpM = worldDistance(p.position, nextPosition);
      p.lastRebaseAtMs = now;
      p.rebaseCount++;
      p.s = target;
      p.v = velocity;
      p.a = 0;
      p.position = nextPosition;
      p.tripId = snapshot.tripId;
      p.geometry = geometry;
      p.comparable = true;
      p.lookAtMs = -Infinity;
      p.transition.hiddenFrameId = ++this.hiddenFrameSerial;
      p.transition.acknowledged = false;
    }
    let rebase = false;
    if (p.transition) {
      if (!record) return p;
      const phase = advanceTransition(
        p.transition,
        now,
        () => ++this.hiddenFrameSerial
      );
      p.opacity = phase.opacity;
      rebase = phase.rebase;
      if (rebase) {
        const nextPosition = position();
        p.lastWorldJumpM = worldDistance(p.position, nextPosition);
        p.lastRebaseAtMs = now;
        p.rebaseCount++;
        p.s = target;
        p.v = velocity;
        p.a = 0;
        p.position = nextPosition;
        p.tripId = snapshot.tripId;
        p.geometry = geometry;
        p.comparable = true;
        p.lookAtMs = -Infinity;
      }
      if (phase.done) p.transition = null;
    }
    const sample = (at) => vehicle ? renderDistM(
      vehicle,
      at,
      "smooth",
      snapshot.shapeDistM,
      snapshot.observedAtMs
    ) : naiveDistM(
      this.fallbackFixes.get(snapshot.key)?.s ?? snapshot.shapeDistM,
      snapshot.observedAtMs,
      at,
      this.paces.get(snapshot.key)?.vMs ?? 0
    );
    if (p.comparable && !rebase && dt <= 5 && (!p.transition || p.transition.stage === "in")) {
      if (now - p.lookAtMs >= 1e3 || p.lookEmissionMs !== (vehicle?.emittedAtMs ?? 0)) {
        p.lookAtMs = now;
        p.lookEmissionMs = vehicle?.emittedAtMs ?? 0;
        p.stopS = geometry?.totalM ?? null;
        let before = target;
        for (let second = 1; second <= 16; second++) {
          const next = sample(serverNow + second * 1e3);
          if (Math.abs(next - before) < 0.03) {
            p.stopS = Math.min(p.stopS ?? Infinity, next);
            break;
          }
          before = next;
        }
      }
      const acceleration = vehicle ? (renderSpeedMs(
        vehicle,
        serverNow + 500,
        "smooth",
        snapshot.shapeDistM,
        snapshot.observedAtMs
      ) - velocity) * 2 : 0;
      advancePresentation(p, dt, target, velocity, acceleration, p.stopS);
    } else if (dt <= 5 && p.transition?.stage === "out" && p.geometry) {
      advancePresentation(p, dt, p.s + p.v * dt, p.v, 0, p.geometry.totalM);
    }
    p.atMs = now;
    if (p.geometry && (!p.transition || p.transition.stage === "in" || p.transition.stage === "out" || rebase)) {
      p.position = pointAt(p.geometry.coordinates, p.geometry.cumDistM, p.s);
      p.bearing = bearingAt(p.geometry.coordinates, p.geometry.cumDistM, p.s);
    } else if (!p.geometry && !p.transition && worldDistance(p.position, snapshot.coordinates) > 0.25 && record) {
      p.transition = {
        id: ++this.transitionSerial,
        reason: "incompatible-geometry",
        stage: "out",
        atMs: now,
        hiddenFrameId: void 0,
        acknowledged: false
      };
    }
    return p;
  }
  build(snapshot, serverNowMs, mode, recordFrame = false, localNowMs = serverNowMs) {
    const vehicle = this.vehicleFor(snapshot);
    let display;
    const state = adaptTram({
      snapshot,
      model: this.models.get(snapshot.key) ?? this.resolveModel(snapshot),
      geometry: this.geometries.get(snapshot.key),
      vehicle,
      serverNowMs,
      presentationNowMs: localNowMs,
      mode,
      observedPaceMs: this.paces.get(snapshot.key)?.vMs ?? 0,
      fallbackFixDistM: this.fallbackFixes.get(snapshot.key)?.s,
      present: mode === this.mode && mode === "smooth" ? (s, v2) => {
        display = this.present(
          snapshot,
          localNowMs,
          serverNowMs,
          s,
          v2,
          recordFrame
        );
        return display;
      } : void 0
    });
    if (recordFrame && mode === this.mode)
      this.watchJump(
        snapshot,
        state.simDistM,
        state.simSpeedKmh,
        serverNowMs,
        localNowMs,
        false
      );
    if (display) {
      state.presentationOpacity = display.opacity;
      state.presentationTransitionId = display.transition?.id;
      state.presentationHiddenFrameId = display.transition?.hiddenFrameId;
      state.presentationTransitionReason = display.transition?.reason ?? null;
      state.presentationCorrectionComparable = display.comparable;
      state.presentationCorrectionM = display.comparable ? state.renderTargetDistM - display.s : null;
      if (!display.comparable) {
        state.phase = "unknown";
        state.nextStopEtaS = null;
      }
    }
    if (vehicle && Number.isFinite(vehicle.emittedAtMs)) {
      const entry = this.profileLog.get(snapshot.key);
      if (!entry) {
        this.profileLog.set(snapshot.key, {
          lastEmittedAtMs: vehicle.emittedAtMs,
          log: [{ source: vehicle.source ?? "ml", atMs: vehicle.emittedAtMs }]
        });
      } else if (entry.lastEmittedAtMs !== vehicle.emittedAtMs) {
        entry.lastEmittedAtMs = vehicle.emittedAtMs;
        entry.log.push({
          source: vehicle.source ?? "ml",
          atMs: vehicle.emittedAtMs
        });
        if (entry.log.length > 5) entry.log.shift();
      }
    }
    return state;
  }
  /**
   * Record a frame-over-frame displacement no plausible motion explains.
   * Forward allowance: 20 m/s (above V_MAX pace) plus 25 m of slack for the
   * licensed fixed-mode re-anchor jitter; backward allowance 10 m (rendering
   * is monotone by construction — anything bigger IS the backward-teleport
   * bug class). Gaps over 5 s (background, culled stretch) reset instead of
   * judging — across a long gap any displacement is legitimate motion.
   */
  watchJump(snapshot, s, speedKmh, atMs, frameAtMs, allowJump = false) {
    const j = this.jumps.get(snapshot.key);
    const geometry = this.geometries.get(snapshot.key);
    const emissionMs = this.vehicleFor(snapshot)?.emittedAtMs ?? 0;
    if (!j || j.tripId !== snapshot.tripId || j.geometry !== geometry) {
      this.jumps.set(snapshot.key, {
        tripId: snapshot.tripId,
        geometry,
        emissionMs,
        speedKmh,
        s,
        atMs,
        frameAtMs,
        jumpM: 0,
        jumpAtMs: 0
      });
      return;
    }
    j.emissionMs = emissionMs;
    j.speedKmh = speedKmh;
    if (allowJump) {
      j.s = s;
      j.atMs = atMs;
      j.frameAtMs = frameAtMs;
      return;
    }
    const dtMs = frameAtMs - j.frameAtMs;
    if (dtMs <= 0) return;
    if (dtMs <= 5e3) {
      const ds = s - j.s;
      if (ds > 25 + 0.02 * dtMs || ds < -10) {
        j.jumpM = ds;
        j.jumpAtMs = atMs;
      }
    }
    j.s = s;
    j.atMs = atMs;
    j.frameAtMs = frameAtMs;
  }
  /**
   * Additive, on-demand devtools view of ONE tram (debug overlay only). Nothing
   * here feeds rendering. Replaces the old SimDebugInfo's 30 controller
   * internals with what a trajectory client can actually be wrong about:
   * which curve, how far apart the two curves are, how much horizon is left,
   * and how stale everything is.
   */
  getDiagnostics(key, localNowMs = Date.now(), mode = this.mode) {
    const snapshot = this.snapshots.get(key);
    if (!snapshot) return void 0;
    const serverNowMs = this.trajectories.nowMs(localNowMs);
    const vehicle = this.vehicleFor(snapshot);
    const state = this.build(snapshot, serverNowMs, mode, false, localNowMs);
    const health = this.trajectories.health(localNowMs);
    let smoothDistM = null;
    let fixedDistM = null;
    let horizonLeftS = null;
    let effectiveHorizonLeftS = null;
    let fixForwardM = null;
    let shimBranch = "off";
    let tauS = null;
    let fixVsCurveM = null;
    let walkRemainingM = null;
    if (vehicle) {
      if (vehicle.smooth.length > 0)
        smoothDistM = evalTrajectory(vehicle.smooth, serverNowMs);
      if (vehicle.opinion.length > 0)
        fixedDistM = evalTrajectory(vehicle.opinion, serverNowMs);
      const track = trackFor(vehicle, mode);
      const shimFixS = mode === "smooth" && vehicle.motionPolicy === "continuous-v1" ? Number.NaN : snapshot.shapeDistM;
      horizonLeftS = (trackEndMs(track) - serverNowMs) / 1e3;
      effectiveHorizonLeftS = horizonLeftS - fixForwardTauMs(
        track,
        shimFixS,
        snapshot.observedAtMs,
        vehicle.anchorMs
      ) / 1e3;
      fixForwardM = fixForwardAppliedM(
        track,
        serverNowMs,
        catchupVMsFor(mode),
        shimFixS,
        snapshot.observedAtMs,
        vehicle.anchorMs
      );
      const fixS = shimFixS;
      const fixAtMs = snapshot.observedAtMs;
      const newerFix = !Number.isFinite(vehicle.anchorMs) || fixAtMs > vehicle.anchorMs;
      if (track.length > 0 && newerFix && Number.isFinite(fixS)) {
        fixVsCurveM = fixS - evalTrajectory(track, fixAtMs);
        const tau = fixForwardTauMs(track, fixS, fixAtMs, vehicle.anchorMs);
        if (tau === 0) {
          shimBranch = fixVsCurveM <= 0 ? "ahead" : "off";
        } else if (tau === Number.POSITIVE_INFINITY) {
          shimBranch = "walk";
          tauS = Number.POSITIVE_INFINITY;
          walkRemainingM = Math.max(0, fixS - state.simDistM);
        } else {
          shimBranch = "wind";
          tauS = tau / 1e3;
        }
      }
    }
    const observedPaceMs = this.paces.get(key)?.vMs ?? 0;
    const fixAheadS = (serverNowMs - snapshot.observedAtMs) / 1e3;
    const renderSource = vehicle ? vehicle.source === "naive" ? "curve-naive" : "curve-ml" : observedPaceMs > 0 && state.hasGeometry && fixAheadS < NAIVE_HORIZON_S ? "client-naive" : "raw-fix";
    const jump = this.jumps.get(key);
    const hasJump = jump !== void 0 && jump.jumpAtMs > 0;
    const geometry = this.geometries.get(key);
    const fixCoordVsAxisM = geometry ? projectDistanceOnPolyline(
      [snapshot.coordinates[0], snapshot.coordinates[1]],
      geometry.coordinates,
      geometry.cumDistM
    ) - snapshot.shapeDistM : null;
    const profileLog = this.profileLog.get(key)?.log ?? [];
    const profileHistory = profileLog.map((e) => ({ source: e.source, ageS: (serverNowMs - e.atMs) / 1e3 })).reverse();
    let elog = this.eventLogs.get(key);
    if (!elog) {
      elog = {
        lastQueryMs: 0,
        ring: [],
        prevSource: renderSource,
        sourceSinceMs: serverNowMs,
        prevShim: shimBranch,
        shimSinceMs: serverNowMs,
        prevEmittedAtMs: vehicle?.emittedAtMs ?? 0,
        prevObsAtMs: snapshot.observedAtMs,
        prevObsS: snapshot.shapeDistM,
        prevTripId: snapshot.tripId,
        standSinceMs: 0,
        standAtM: 0,
        lastJumpSeenAtMs: 0
      };
      this.eventLogs.set(key, elog);
    }
    elog.lastQueryMs = Date.now();
    const push = (kind, text, warn = false) => {
      elog.ring.push({ atMs: serverNowMs, kind, text, warn });
      if (elog.ring.length > 40) elog.ring.shift();
    };
    const SRC_RU = {
      "curve-ml": "ML-\u043F\u0440\u043E\u0444\u0438\u043B\u044C",
      "curve-naive": "\u043D\u0430\u0438\u0432\u043D\u044B\u0439 \u043F\u0440\u043E\u0444\u0438\u043B\u044C",
      "client-naive": "\u043A\u043B\u0438\u0435\u043D\u0442\u0441\u043A\u0430\u044F \u043F\u0440\u043E\u0442\u044F\u0436\u043A\u0430",
      "raw-fix": "\u0437\u0430\u043C\u0435\u0440 \u043D\u0430 \u0444\u0438\u043A\u0441\u0435"
    };
    const SHIM_RU = {
      off: "\u0441\u043F\u0438\u0442",
      ahead: "\u043F\u0440\u043E\u0444\u0438\u043B\u044C\u2A7E\u0444\u0438\u043A\u0441\u0430",
      wind: "\u043F\u0440\u043E\u043C\u043E\u0442\u043A\u0430",
      walk: "\u0424\u0418\u041A\u0421 \u0417\u0410 \u0413\u041E\u0420\u0418\u0417\u041E\u041D\u0422\u041E\u041C"
    };
    if (hasJump && jump.jumpAtMs !== elog.lastJumpSeenAtMs) {
      elog.lastJumpSeenAtMs = jump.jumpAtMs;
      push(
        "\u0422\u0415\u041B\u0415\u041F\u041E\u0420\u0422",
        `${jump.jumpM >= 0 ? "+" : ""}${jump.jumpM.toFixed(0)}\u043C (\u043F\u043E\u043F\u0440\u0430\u0432\u043A\u0430: ${SHIM_RU[shimBranch]}, \u0435\u0445\u0430\u043B \u043F\u043E: ${SRC_RU[renderSource]})`,
        true
      );
    }
    if (snapshot.tripId !== elog.prevTripId) {
      push(
        "\u0440\u0435\u0439\u0441",
        `\u043D\u043E\u0432\u044B\u0439 \u0440\u0435\u0439\u0441 (${elog.prevTripId.slice(0, 12)}\u2026 \u2192 ${snapshot.tripId.slice(0, 12)}\u2026)`
      );
      elog.prevTripId = snapshot.tripId;
    }
    if (vehicle && Number.isFinite(vehicle.emittedAtMs) && vehicle.emittedAtMs !== elog.prevEmittedAtMs) {
      elog.prevEmittedAtMs = vehicle.emittedAtMs;
      const anchorAge = Number.isFinite(vehicle.anchorMs) ? ((serverNowMs - vehicle.anchorMs) / 1e3).toFixed(0) : "?";
      push(
        "\u043F\u0435\u0440\u0435\u0441\u0447\u0451\u0442",
        `${vehicle.source === "naive" ? "\u043D\u0430\u0438\u0432\u043D\u044B\u0439" : "ml"} \xB7 \u043E\u043F\u043E\u0440\u0435 ${anchorAge}\u0441${vehicle.discontinuity ? " \xB7 \u0421\u041A\u0410\u0427\u041E\u041A \u0420\u0410\u0417\u0420\u0415\u0428\u0401\u041D" : ""}`,
        vehicle.discontinuity
      );
    }
    if (snapshot.observedAtMs !== elog.prevObsAtMs) {
      const dS = snapshot.shapeDistM - elog.prevObsS;
      const lagS = ((serverNowMs - snapshot.observedAtMs) / 1e3).toFixed(0);
      push(
        "\u0444\u0438\u043A\u0441",
        `${dS >= 0 ? "+" : ""}${dS.toFixed(0)}\u043C \u043F\u043E \u043E\u0441\u0438 \xB7 \u043B\u0430\u0433 ${lagS}\u0441${fixCoordVsAxisM != null && Math.abs(fixCoordVsAxisM) > 30 ? ` \xB7 \u043A\u043E\u043E\u0440\u0434\u2212\u043E\u0441\u044C ${fixCoordVsAxisM >= 0 ? "+" : ""}${fixCoordVsAxisM.toFixed(0)}\u043C` : ""}`,
        fixCoordVsAxisM != null && Math.abs(fixCoordVsAxisM) > 60
      );
      elog.prevObsAtMs = snapshot.observedAtMs;
      elog.prevObsS = snapshot.shapeDistM;
    }
    if (renderSource !== elog.prevSource) {
      const durS = ((serverNowMs - elog.sourceSinceMs) / 1e3).toFixed(1);
      push(
        "\u0438\u0441\u0442\u043E\u0447\u043D\u0438\u043A",
        `${SRC_RU[elog.prevSource ?? renderSource]} \u2192 ${SRC_RU[renderSource]} (\u0431\u044B\u043B\u043E ${durS}\u0441)`,
        renderSource !== "curve-ml"
      );
      elog.prevSource = renderSource;
      elog.sourceSinceMs = serverNowMs;
    }
    if (shimBranch !== elog.prevShim) {
      const durS = ((serverNowMs - elog.shimSinceMs) / 1e3).toFixed(1);
      push(
        "\u043F\u043E\u043F\u0440\u0430\u0432\u043A\u0430",
        `${SHIM_RU[elog.prevShim ?? shimBranch]} \u2192 ${SHIM_RU[shimBranch]} (${SHIM_RU[elog.prevShim ?? shimBranch]} \u0434\u043B\u0438\u043B\u0441\u044F ${durS}\u0441)`,
        shimBranch === "walk" || elog.prevShim === "walk"
      );
      elog.prevShim = shimBranch;
      elog.shimSinceMs = serverNowMs;
    }
    const standingNow = state.simSpeedKmh <= 1;
    if (standingNow && elog.standSinceMs === 0) {
      elog.standSinceMs = serverNowMs;
      elog.standAtM = state.simDistM;
    } else if (!standingNow && elog.standSinceMs > 0) {
      const durS = (serverNowMs - elog.standSinceMs) / 1e3;
      if (durS >= 3) {
        let nearest = Infinity;
        let nearestName = "";
        for (const st of geometry?.stops ?? []) {
          const d = Math.abs(st.distM - elog.standAtM);
          if (d < nearest) {
            nearest = d;
            nearestName = st.name;
          }
        }
        const where = nearest <= 40 ? `\u0443 ${nearestName}` : `\u043F\u043E\u0441\u0440\u0435\u0434\u0438 \u043F\u0435\u0440\u0435\u0433\u043E\u043D\u0430 (${nearest.toFixed(0)}\u043C \u043E\u0442 \u043E\u0441\u0442\u0430\u043D\u043E\u0432\u043A\u0438)`;
        push(
          "\u0441\u0442\u043E\u044F\u043D\u043A\u0430",
          `\u0441\u0442\u043E\u044F\u043B ${durS.toFixed(0)}\u0441 ${where}`,
          nearest > 40 && durS >= 10
        );
      }
      elog.standSinceMs = 0;
    }
    const events = elog.ring.slice(-30).reverse().map((e) => ({ ...e, ageS: (serverNowMs - e.atMs) / 1e3 }));
    return {
      events,
      motionPolicy: vehicle ? vehicle.motionPolicy ?? "legacy" : null,
      presentationModeChanges: this.modeChanges,
      presentationRebaseCount: this.displays.get(key)?.rebaseCount ?? 0,
      presentationLastWorldJumpM: this.displays.get(key)?.lastWorldJumpM ?? null,
      presentationLastRebaseAtMs: this.displays.get(key)?.lastRebaseAtMs ?? null,
      presentationAccelerationMs2: this.displays.get(key)?.a ?? null,
      profileHistory,
      fixCoordVsAxisM,
      geometryCoherence: this.coherence.get(key)?.result.status ?? "unknown",
      geometryCoherenceReason: this.coherence.get(key)?.result.reason ?? null,
      geometryAxisCoordinateErrorM: this.coherence.get(key)?.result.axisCoordinateErrorM ?? null,
      hasTrajectory: vehicle !== void 0,
      hasGeometry: state.hasGeometry,
      mode,
      renderSource,
      lastJumpM: hasJump ? jump.jumpM : null,
      lastJumpAgoS: hasJump ? (serverNowMs - jump.jumpAtMs) / 1e3 : null,
      anchorFixS: vehicle && Number.isFinite(vehicle.anchorS) ? vehicle.anchorS : null,
      anchorLagS: vehicle && Number.isFinite(vehicle.anchorMs) ? (snapshot.observedAtMs - vehicle.anchorMs) / 1e3 : null,
      observedPaceMs,
      shimBranch,
      tauS,
      fixVsCurveM,
      walkRemainingM,
      simDistM: state.simDistM,
      smoothDistM,
      fixedDistM,
      deltaM: smoothDistM !== null && fixedDistM !== null ? smoothDistM - fixedDistM : null,
      fixForwardM,
      simSpeedKmh: state.simSpeedKmh,
      smoothSpeedKmh: vehicle && vehicle.smooth.length > 0 ? evalSpeedMs(vehicle.smooth, serverNowMs) * 3.6 : null,
      phase: state.phase,
      pastHorizon: state.pastHorizon,
      horizonLeftS,
      effectiveHorizonLeftS,
      renderTargetDistM: state.renderTargetDistM,
      renderGuardGapM: state.renderTargetDistM - state.simDistM,
      renderGuardActive: state.renderGuardActive,
      anchorAgeS: vehicle && Number.isFinite(vehicle.anchorMs) ? (serverNowMs - vehicle.anchorMs) / 1e3 : null,
      emissionAgeS: vehicle && Number.isFinite(vehicle.emittedAtMs) ? (serverNowMs - vehicle.emittedAtMs) / 1e3 : null,
      discontinuity: vehicle?.discontinuity ?? false,
      obsDistM: snapshot.shapeDistM,
      obsAtMs: snapshot.observedAtMs,
      fixAgeS: (serverNowMs - snapshot.observedAtMs) / 1e3,
      nextStopName: state.nextStopName,
      nextStopEtaS: state.nextStopEtaS,
      delaySeconds: snapshot.delaySeconds,
      statePosition: snapshot.statePosition,
      bundleAgeS: health.bundleAgeS,
      feedSeq: health.lastSeq,
      serverGen: health.serverGen,
      clockOffsetMs: health.clockOffsetMs,
      connection: health.connection,
      discontinuitiesTotal: health.discontinuities
    };
  }
};

// src/lib/physics/trajectoryStore.ts
init_bundle();

// src/lib/physics/clock.ts
var CLOCK_WINDOW = 3;
var CLOCK_DECAY = 0.5;
var CLOCK_IMPLAUSIBLE_MS = 60 * 60 * 1e3;
var ClockSync = class {
  /** Most recent samples, newest last; at most CLOCK_WINDOW entries. */
  samples = [];
  cached = 0;
  hasEstimate = false;
  fromOffsetMs = 0;
  correctionAtMs = 0;
  correctionDurationMs = 0;
  /** Estimate against the request midpoint, but start applying a correction
   * only when its reply actually arrives. A midpoint-started ramp is already
   * partway through at receipt and creates an immediate jump. */
  sample(serverNowMs, receivedAtMs, appliedAtMs = receivedAtMs) {
    if (!Number.isFinite(serverNowMs) || !Number.isFinite(receivedAtMs) || !Number.isFinite(appliedAtMs))
      return;
    const hadEstimate = this.hasEstimate;
    const applied = this.offsetAt(appliedAtMs);
    this.samples.push(serverNowMs - receivedAtMs);
    if (this.samples.length > CLOCK_WINDOW) this.samples.shift();
    this.cached = weightedOffset(this.samples);
    this.fromOffsetMs = hadEstimate ? applied : this.cached;
    this.hasEstimate = true;
    this.correctionAtMs = appliedAtMs;
    this.correctionDurationMs = Math.abs(this.cached - this.fromOffsetMs) / 0.05;
  }
  /** New endpoint: invalidate confidence, preserve render time until its nonce
   * reply arrives. The first replacement estimate is slewed like later ones. */
  beginEpoch(localNowMs) {
    this.cached = this.offsetAt(localNowMs);
    this.fromOffsetMs = this.cached;
    this.samples = [];
    this.correctionAtMs = localNowMs;
    this.correctionDurationMs = 0;
  }
  /** Drop all samples (feed restart / teardown) — next fetch re-seeds. */
  reset() {
    this.samples = [];
    this.hasEstimate = false;
    this.cached = 0;
    this.fromOffsetMs = 0;
    this.correctionAtMs = 0;
    this.correctionDurationMs = 0;
  }
  /** Latest local application time needed to reproduce the current clock mapping. */
  get inputsAvailableAtMs() {
    return this.correctionAtMs;
  }
  /** True once at least one fetch has been sampled. */
  get synced() {
    return this.samples.length > 0;
  }
  /** Current smoothed offset, ms (0 before the first sample). */
  get offsetMs() {
    return this.cached;
  }
  /** True when the offset is large enough to suspect a wrong device clock. */
  get implausible() {
    return this.samples.length > 0 && Math.abs(this.cached) > CLOCK_IMPLAUSIBLE_MS;
  }
  /**
   * Server-corrected wall clock — the ONLY time any trajectory is evaluated
   * at. `localNowMs` is injectable for tests; production passes Date.now().
   */
  offsetAt(localNowMs) {
    if (this.correctionDurationMs === 0) return this.cached;
    const progress = Math.max(
      0,
      Math.min(1, (localNowMs - this.correctionAtMs) / this.correctionDurationMs)
    );
    return this.fromOffsetMs + (this.cached - this.fromOffsetMs) * progress;
  }
  now(localNowMs) {
    return localNowMs + this.offsetAt(localNowMs);
  }
};
function weightedOffset(samples2) {
  const n = samples2.length;
  if (n === 0) return 0;
  let acc = 0;
  let wsum = 0;
  let w = 1;
  for (let i = n - 1; i >= 0; i--) {
    acc += samples2[i] * w;
    wsum += w;
    w *= CLOCK_DECAY;
  }
  return acc / wsum;
}

// src/lib/physics/connection.ts
var DEGRADED_AFTER_S = 15;
var OFFLINE_AFTER_S = 45;
var OFFLINE_AFTER_FAILURES = 3;
function connectionState(input) {
  const { bundleAgeS, consecutiveFailures } = input;
  if (bundleAgeS === null) return consecutiveFailures > 0 ? "offline" : "degraded";
  if (consecutiveFailures >= OFFLINE_AFTER_FAILURES) return "offline";
  if (bundleAgeS > OFFLINE_AFTER_S) return "offline";
  if (bundleAgeS >= DEGRADED_AFTER_S) return "degraded";
  return "live";
}

// src/lib/physics/trajectoryStore.ts
var TrajectoryStore = class {
  /**
   * `options.convex` opts the store into the Convex push transport — set by
   * the app runtime only, so tests and bare environments construct a store
   * that holds data (via `ingest`/the sink methods) without a WebSocket stack.
   */
  constructor(options = {}) {
    this.options = options;
  }
  running = false;
  generation = 0;
  /** Convex push transport, created lazily on the first start. */
  convexSource = null;
  sourceStatus = null;
  current = null;
  /** First local receipt of the current revision, scoped to its source epoch. */
  vehicleReceivedAtMs = /* @__PURE__ */ new Map();
  lastSeqSeen = 0;
  failures = 0;
  lastError = null;
  lastBundleAtMs = 0;
  discontinuities = 0;
  listeners = /* @__PURE__ */ new Set();
  clock = new ClockSync();
  /** Start the transport (when opted in). Idempotent. */
  start() {
    if (this.running) return;
    this.running = true;
    this.generation += 1;
    if (this.options.convex === true) this.tryStartConvex();
  }
  /**
   * Stop the transport and abort in-flight work. The decoded bundle is KEPT:
   * there is no simulation to drift, so on resume the curves are either still
   * valid (a short backgrounding lands inside the same 120 s horizon) or
   * visibly stale, which the connection state reports honestly.
   */
  stop() {
    if (!this.running && this.convexSource === null) return;
    this.running = false;
    this.generation += 1;
    this.convexSource?.stop();
  }
  tryStartConvex() {
    try {
      if (!this.convexSource) {
        const { ResilientTrajectorySource: ResilientTrajectorySource2 } = (init_resilientSource(), __toCommonJS(resilientSource_exports));
        const trajectoryEnv = process.env.EXPO_PUBLIC_TRAJECTORY_CONVEX_URL;
        const env = trajectoryEnv || process.env.EXPO_PUBLIC_CONVEX_URL;
        const url = typeof env === "string" && env.length > 0 ? env : "https://tram-api.acex.sh";
        const fallbackUrl = process.env.EXPO_PUBLIC_CONVEX_URL || "https://tram-api.acex.sh";
        this.convexSource = new ResilientTrajectorySource2(this, {
          url,
          fallbackUrl: trajectoryEnv ? fallbackUrl : void 0
        });
      }
      this.convexSource.start();
      return true;
    } catch (e) {
      this.convexSource = null;
      this.noteFailure(`convex source failed to start: ${String(e)}`);
      return false;
    }
  }
  /** Notified after each successfully adopted publication (runtime → UI bump). */
  subscribe(listener) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }
  get bundle() {
    return this.current;
  }
  getVehicle(key) {
    return this.current?.vehicles.get(key);
  }
  getVehicleReceivedAtMs(key) {
    return this.vehicleReceivedAtMs.get(key);
  }
  noteVehicleReceipt(vehicle, previous, atMs) {
    if (!this.vehicleReceivedAtMs.has(vehicle.key) || !previous || previous.tripId !== vehicle.tripId || previous.emittedAtMs !== vehicle.emittedAtMs) {
      this.vehicleReceivedAtMs.set(vehicle.key, atMs);
    }
  }
  noteSnapshotReceipts(vehicles, atMs) {
    for (const vehicle of vehicles.values()) {
      this.noteVehicleReceipt(vehicle, this.current?.vehicles.get(vehicle.key), atMs);
    }
    for (const key of this.vehicleReceivedAtMs.keys()) {
      if (!vehicles.has(key)) this.vehicleReceivedAtMs.delete(key);
    }
  }
  /** Server-corrected wall clock — the instant ALL evaluation happens at. */
  nowMs(localNowMs = Date.now()) {
    return this.clock.now(localNowMs);
  }
  /** Age of the newest publication in seconds, or null when none decoded. */
  bundleAgeS(localNowMs = Date.now()) {
    if (!this.current) return null;
    return (this.clock.now(localNowMs) - this.current.atMs) / 1e3;
  }
  connection(localNowMs = Date.now()) {
    return connectionState({
      bundleAgeS: this.bundleAgeS(localNowMs),
      consecutiveFailures: this.failures
    });
  }
  health(localNowMs = Date.now()) {
    return {
      source: this.sourceStatus,
      connection: this.connection(localNowMs),
      bundleAgeS: this.bundleAgeS(localNowMs),
      clockOffsetMs: this.clock.offsetAt(localNowMs),
      clockSynced: this.clock.synced,
      clockImplausible: this.clock.implausible,
      consecutiveFailures: this.failures,
      lastError: this.lastError,
      vehicleCount: this.current?.vehicles.size ?? 0,
      serverGen: this.current?.generator ?? null,
      lastSeq: this.lastSeqSeen,
      discontinuities: this.discontinuities,
      lastBundleAtMs: this.lastBundleAtMs
    };
  }
  /**
   * Adopt a decoded HTTP-shaped bundle body. The direct payload path for
   * tests/tooling. Returns false when the payload was unusable — the previous
   * bundle then keeps rendering and simply ages.
   */
  ingest(payload, receivedAtMs = Date.now()) {
    const next = parseBundle(payload, receivedAtMs);
    if (!next) {
      this.noteFailure("malformed bundle");
      return false;
    }
    const prev2 = this.current;
    for (const v2 of next.vehicles.values()) {
      if (!v2.discontinuity) continue;
      const before = prev2?.vehicles.get(v2.key);
      if (!before || before.emittedAtMs !== v2.emittedAtMs) this.discontinuities += 1;
    }
    this.noteSnapshotReceipts(next.vehicles, receivedAtMs);
    this.current = next;
    this.clock.sample(next.serverNowMs, receivedAtMs);
    this.failures = 0;
    this.lastError = null;
    this.lastBundleAtMs = receivedAtMs;
    this.listeners.forEach((l) => l());
    return true;
  }
  noteFailure(message) {
    this.failures += 1;
    this.lastError = message;
  }
  // ── TrajectorySink (the Convex push transport feeds the store here) ────────
  /** Adopt a full `trajectories:fullSet` result (seed / reseed). */
  seedConvex(vehiclesRaw, meta, receivedAtMs) {
    const vehicles = /* @__PURE__ */ new Map();
    for (const raw of vehiclesRaw) {
      const parsed = parseVehicle(raw);
      if (parsed) vehicles.set(parsed.key, parsed);
    }
    const serverNowMs = meta?.serverNowMs ?? receivedAtMs;
    const prev2 = this.current;
    for (const v2 of vehicles.values()) {
      if (!v2.discontinuity) continue;
      const before = prev2?.vehicles.get(v2.key);
      if (!before || before.emittedAtMs !== v2.emittedAtMs) this.discontinuities += 1;
    }
    this.noteSnapshotReceipts(vehicles, receivedAtMs);
    this.current = {
      protocolVersion: PROTOCOL_VERSION,
      serverNowMs,
      atMs: meta?.atMs ?? serverNowMs,
      horizonS: meta?.horizonS ?? 0,
      vehicles,
      generator: meta?.generator ?? null,
      receivedAtMs
    };
    this.lastSeqSeen = meta?.lastSeq ?? this.lastSeqSeen;
    this.failures = 0;
    this.lastError = null;
    this.lastBundleAtMs = receivedAtMs;
    this.listeners.forEach((l) => l());
  }
  /** Fold one diff batch into the live bundle (mutates the vehicle map). */
  foldConvex(batch, serverNowMs, receivedAtMs) {
    const cur = this.current;
    if (!cur || batch.seq <= this.lastSeqSeen) return;
    for (const raw of batch.changed) {
      const parsed = parseVehicle(raw);
      if (!parsed) continue;
      const before = cur.vehicles.get(parsed.key);
      if (before && parsed.emittedAtMs < before.emittedAtMs) continue;
      if (parsed.discontinuity && (!before || before.emittedAtMs !== parsed.emittedAtMs)) {
        this.discontinuities += 1;
      }
      this.noteVehicleReceipt(parsed, before, receivedAtMs);
      cur.vehicles.set(parsed.key, parsed);
    }
    if (batch.removed) {
      for (const key of batch.removed) {
        cur.vehicles.delete(key);
        this.vehicleReceivedAtMs.delete(key);
      }
    }
    if (batch.atMs > cur.atMs) cur.atMs = batch.atMs;
    if (serverNowMs > cur.serverNowMs) cur.serverNowMs = serverNowMs;
    if (batch.seq > this.lastSeqSeen) this.lastSeqSeen = batch.seq;
    this.failures = 0;
    this.lastError = null;
    this.lastBundleAtMs = receivedAtMs;
    this.listeners.forEach((l) => l());
  }
  /**
   * Publisher heartbeat: advances bundle age only after its advertised head is
   * applied, even when no vehicle
   * changed, so a quiet fleet does not decay into a false 'offline' banner.
   * Deliberately does NOT reset the failure counter — a live heartbeat with a
   * failing seed must keep reporting the seed failure.
   */
  noteConvexMeta(meta, receivedAtMs) {
    const cur = this.current;
    if (cur && meta.lastSeq === this.lastSeqSeen) {
      if (meta.atMs > cur.atMs) cur.atMs = meta.atMs;
      if (meta.serverNowMs > cur.serverNowMs) cur.serverNowMs = meta.serverNowMs;
      cur.generator = meta.generator;
      this.listeners.forEach((l) => l());
    }
  }
  /** Only a nonce query is a clock sample: reactive query results may be cached. */
  noteConvexClock(serverNowMs, sentAtMs, receivedAtMs, appliedAtMs = receivedAtMs) {
    const rttMs = receivedAtMs - sentAtMs;
    if (rttMs < 0 || rttMs > 2e3) return;
    this.clock.sample(serverNowMs, sentAtMs + rttMs / 2, appliedAtMs);
  }
  noteConvexSource(status, newEpoch) {
    this.sourceStatus = status;
    if (newEpoch) {
      this.lastSeqSeen = 0;
      this.vehicleReceivedAtMs.clear();
      this.clock.beginEpoch(Date.now());
    }
    this.listeners.forEach((l) => l());
  }
  noteConvexFailure(message) {
    this.noteFailure(message);
  }
};

// bench/src/displayAudit.ts
var DisplayAudit = class {
  previous = /* @__PURE__ */ new Map();
  counts = {};
  worst = [];
  stopCrossings = [];
  maxWorldStepM = 0;
  maxBackwardStepM = 0;
  maxPositiveSpeedStepMs = 0;
  maxNegativeSpeedStepMs = 0;
  accelerationBuckets = /* @__PURE__ */ new Map();
  jerkBuckets = /* @__PURE__ */ new Map();
  jerkExamples = [];
  accelerationOver25 = 0;
  brakingOver25 = 0;
  jerkOver4 = 0;
  hiddenSeconds = 0;
  fadingSeconds = 0;
  histogram(map, value) {
    const bucket = Math.round(Math.min(1e4, Math.abs(value)) * 100);
    map.set(bucket, (map.get(bucket) ?? 0) + 1);
  }
  quantiles(map) {
    const sorted = [...map].sort((a, b) => a[0] - b[0]), total = sorted.reduce((a, b) => a + b[1], 0);
    return Object.fromEntries(
      [0.5, 0.9, 0.99, 1].map((q) => {
        let count = 0;
        for (const [v2, n] of sorted) {
          count += n;
          if (count >= q * total) return [String(q), v2 / 100];
        }
        return [String(q), 0];
      })
    );
  }
  intervals = 0;
  stationCrossings = 0;
  crossingsAbove5Ms = 0;
  maxFullyVisibleWorldStepM = 0;
  maxUnbrokenNegativeSpeedStepMs = 0;
  physicalBraking = [];
  finishFrame(at, keys) {
    for (const [key, p] of this.previous) {
      if (!keys.has(key)) {
        p.active = false;
        if (at - p.at > 9e4) this.previous.delete(key);
      }
    }
  }
  count(k) {
    this.counts[k] = (this.counts[k] ?? 0) + 1;
  }
  sample(state, at, geometry, vehicle, measured) {
    const old = this.previous.get(state.key);
    let v2 = null, heldS = 0, reset = false, acceleration = null;
    const opacity = state.presentationOpacity ?? 1;
    if (old) {
      const dt = (at - old.at) / 1e3;
      const dx = (state.position[0] - old.position[0]) * 111320 * Math.cos((state.position[1] + old.position[1]) * Math.PI / 360);
      const dy = (state.position[1] - old.position[1]) * 111320;
      const worldM = Math.hypot(dx, dy);
      const sameAxis = old.active && old.geometry !== void 0 && geometry !== void 0 && (old.geometry === geometry || sameGeometryAxis(old.geometry, geometry));
      const ds = sameAxis ? state.simDistM - old.s : null;
      if (dt > 0) {
        v2 = old.active ? (ds ?? worldM) / dt : null;
        heldS = worldM / dt < 0.1 ? old.heldS + dt : 0;
      }
      if (measured && dt > 0) {
        this.intervals++;
        const reason = !old.active ? "reappeared-identity" : old.trip !== state.snapshot.tripId ? "trip-change" : old.geometry !== geometry ? "geometry-change" : old.curve !== !!vehicle ? vehicle ? "curve-restored" : "curve-lost" : vehicle?.discontinuity && old.emission !== vehicle.emittedAtMs ? "server-discontinuity" : dt > 5 ? "frame-gap" : "ordinary";
        if (reason !== "ordinary") this.count(reason);
        this.maxWorldStepM = Math.max(this.maxWorldStepM, worldM);
        if (ds !== null)
          this.maxBackwardStepM = Math.min(this.maxBackwardStepM, ds);
        const dv = v2 !== null && old.v !== null ? v2 - old.v : null;
        acceleration = dv !== null ? dv / dt : null;
        if (opacity < 1) this.fadingSeconds += dt;
        if (opacity <= 1e-3) this.hiddenSeconds += dt;
        if (old.active && opacity >= 0.99 && old.opacity >= 0.99 && acceleration !== null) {
          this.histogram(this.accelerationBuckets, acceleration);
          if (acceleration > 2.5001) this.accelerationOver25++;
          if (acceleration < -2.5001) this.brakingOver25++;
          if (old.acceleration !== null) {
            const jerk = (acceleration - old.acceleration) / dt;
            this.histogram(this.jerkBuckets, jerk);
            if (Math.abs(jerk) > 4.001) {
              this.jerkOver4++;
              if (this.jerkExamples.length < 30)
                this.jerkExamples.push({
                  key: state.key,
                  atMs: at,
                  jerkMs3: jerk,
                  accelerationMs2: acceleration,
                  previousAccelerationMs2: old.acceleration,
                  reason,
                  opacity,
                  previousOpacity: old.opacity,
                  axisStepM: ds,
                  speedMs: v2,
                  previousSpeedMs: old.v
                });
            }
          }
        }
        if (dv !== null) {
          this.maxPositiveSpeedStepMs = Math.max(
            this.maxPositiveSpeedStepMs,
            dv
          );
          this.maxNegativeSpeedStepMs = Math.max(
            this.maxNegativeSpeedStepMs,
            -dv
          );
        }
        const teleport = old.active && worldM > Math.max(3, 25 * dt + 0.05);
        const reversal = ds !== null && ds < -0.5;
        reset = teleport || reversal || reason !== "ordinary";
        const hidden = opacity <= 1e-3 && old.opacity <= 1e-3;
        if (old.active && opacity >= 0.99 && old.opacity >= 0.99)
          this.maxFullyVisibleWorldStepM = Math.max(
            this.maxFullyVisibleWorldStepM,
            worldM
          );
        if (teleport)
          this.count(
            hidden ? "hidden-rebase-over-budget" : "visible-or-partially-visible-over-budget"
          );
        if (!reset && !old.reset && dv !== null && dv < 0) {
          this.maxUnbrokenNegativeSpeedStepMs = Math.max(
            this.maxUnbrokenNegativeSpeedStepMs,
            -dv
          );
          if (dv < -1) {
            this.physicalBraking.push({
              key: state.key,
              atMs: at,
              speedStepMs: dv,
              previousSpeedMs: old.v,
              intervalSpeedMs: v2,
              fixAtMs: state.snapshot.observedAtMs,
              emittedAtMs: vehicle?.emittedAtMs
            });
            this.physicalBraking.sort((a, b) => a.speedStepMs - b.speedStepMs);
            if (this.physicalBraking.length > 30)
              this.physicalBraking.length = 30;
          }
        }
        if (teleport) this.count("raw-displacement-over-budget/" + reason);
        if (reversal) this.count("raw-backward/" + reason);
        if (dv !== null && dv < -1)
          this.count("negative-speed-step-over1/" + reason);
        if (dv !== null && dv > 1)
          this.count("positive-speed-step-over1/" + reason);
        if (teleport || reversal || dv !== null && Math.abs(dv) > 2) {
          const event = {
            key: state.key,
            atMs: at,
            reason,
            presentationReason: state.presentationTransitionReason ?? null,
            hasPresentationGeometry: !!geometry,
            opacity,
            previousOpacity: old.opacity,
            hidden,
            dtS: dt,
            worldStepM: worldM,
            axisStepM: ds,
            previousSpeedMs: old.v,
            intervalSpeedMs: v2,
            speedStepMs: dv,
            reportedSpeedMs: state.simSpeedKmh / 3.6,
            previousHeldS: old.heldS,
            previousDistM: old.s,
            distM: state.simDistM,
            targetDistM: state.renderTargetDistM,
            fixDistM: state.snapshot.shapeDistM,
            fixAtMs: state.snapshot.observedAtMs,
            fixState: state.snapshot.statePosition,
            lastStopId: state.snapshot.lastStopId,
            tripId: state.snapshot.tripId,
            emittedAtMs: vehicle?.emittedAtMs,
            previousEmissionMs: old.emission
          };
          this.worst.push(event);
          this.worst.sort(
            (a, b) => Math.max(b.worldStepM, Math.abs(b.speedStepMs ?? 0) / 30) - Math.max(a.worldStepM, Math.abs(a.speedStepMs ?? 0) / 30)
          );
          if (this.worst.length > 80) this.worst.length = 80;
        }
        if (sameAxis && geometry && ds !== null && ds > 0)
          for (const stop of geometry.stops) {
            if (stop.distM <= old.s || stop.distM > state.simDistM) continue;
            this.stationCrossings++;
            if ((v2 ?? 0) > 5) {
              this.crossingsAbove5Ms++;
              if (this.stopCrossings.length < 80)
                this.stopCrossings.push({
                  key: state.key,
                  atMs: at,
                  stopId: stop.stopId,
                  stopSequence: stop.sequence,
                  stopName: stop.name,
                  stopDistM: stop.distM,
                  intervalSpeedMs: v2,
                  reason,
                  fixState: state.snapshot.statePosition,
                  lastStopId: state.snapshot.lastStopId,
                  fixAgeS: (at - state.snapshot.observedAtMs) / 1e3,
                  precedingHeldS: old.heldS
                });
            }
          }
      }
    }
    this.previous.set(state.key, {
      at,
      s: state.simDistM,
      position: state.position,
      trip: state.snapshot.tripId,
      geometry,
      emission: vehicle?.emittedAtMs ?? 0,
      curve: !!vehicle,
      v: v2,
      heldS,
      opacity,
      reset,
      acceleration,
      active: true
    });
  }
  report() {
    return {
      note: "Every submitted replay state counted, including server-sanctioned resets. Displacement-derived speed around a reset describes visible teleport, not physical tram speed. Crossings are descriptive, not proof that a source-designated served/express/terminal stop should have held.",
      intervals: this.intervals,
      fullyVisibleAbsoluteAccelerationMs2: this.quantiles(
        this.accelerationBuckets
      ),
      fullyVisibleAbsoluteJerkMs3: this.quantiles(this.jerkBuckets),
      fullyVisibleAccelerationOver2_5: this.accelerationOver25,
      fullyVisibleBrakingOver2_5: this.brakingOver25,
      fullyVisibleJerkOver4: this.jerkOver4,
      fullyVisibleJerkExamples: this.jerkExamples,
      hiddenVehicleSeconds: this.hiddenSeconds,
      fadingVehicleSeconds: this.fadingSeconds,
      counts: this.counts,
      maxWorldStepM: this.maxWorldStepM,
      maxFullyVisibleWorldStepM: this.maxFullyVisibleWorldStepM,
      maxUnbrokenNegativeSpeedStepMs: this.maxUnbrokenNegativeSpeedStepMs,
      physicalBrakingExamples: this.physicalBraking,
      maxBackwardStepM: this.maxBackwardStepM,
      maxPositiveSpeedStepMs: this.maxPositiveSpeedStepMs,
      maxNegativeSpeedStepMs: this.maxNegativeSpeedStepMs,
      stationCrossings: this.stationCrossings,
      crossingsAbove5Ms: this.crossingsAbove5Ms,
      worst: this.worst,
      stopCrossingExamples: this.stopCrossings
    };
  }
};

// bench/src/geometryReplay.ts
function applyGeometryEvent(geometries2, path, value, receivedAtMs) {
  if (path === "geometry:trip") {
    if (!value?.tripId || !value?.geometry) return 0;
    try {
      geometries2.set(value.tripId, { ...servedToRouteGeometry(value.geometry, receivedAtMs), tripId: value.tripId, provisional: false });
      return 1;
    } catch {
      return 0;
    }
  }
  if (path !== "geometry:pack" || !Array.isArray(value?.shapes) || !value?.trips) return 0;
  const byKey = /* @__PURE__ */ new Map();
  const axis = (s) => JSON.stringify([s.coordinates, s.cumDistM, s.totalM, s.stops.map((x) => [x.stopId, x.sequence, x.distM])]);
  for (const s of value.shapes) {
    const key = s?.geometryKey ?? s?.shapeId;
    if (typeof key !== "string" || !key) continue;
    if (!byKey.has(key)) byKey.set(key, s);
    else {
      const prior = byKey.get(key);
      try {
        if (!prior || axis(prior) !== axis(s)) byKey.set(key, null);
      } catch {
        byKey.set(key, null);
      }
    }
  }
  let changed = 0;
  for (const [tripId, key] of Object.entries(value.trips)) {
    if (geometries2.has(tripId) || typeof key !== "string") continue;
    const s = byKey.get(key);
    if (!s) continue;
    try {
      geometries2.set(tripId, { ...servedToRouteGeometry(s, receivedAtMs), tripId, geometryKey: s.geometryKey, provisional: true });
      changed++;
    } catch {
    }
  }
  return changed;
}

// bench/src/presentationPrototype.ts
var clamp2 = (x, lo, hi) => Math.max(lo, Math.min(hi, x));
function brakingDistance(v2, a, b, j) {
  if (v2 <= 0) return 0;
  let s = 0, speed = v2, acc = a;
  const step = (t, jerk) => {
    s += speed * t + acc * t * t / 2 + jerk * t * t * t / 6;
    speed += acc * t + jerk * t * t / 2;
    acc += jerk * t;
  };
  const peak = Math.sqrt(Math.max(0, j * v2 + a * a / 2));
  const p = Math.min(b, peak);
  step(Math.max(0, (a + p) / j), -j);
  if (peak > b) step(Math.max(0, (speed - p * p / (2 * j)) / p), 0);
  step(p / j, j);
  return Math.max(0, s);
}
var PresentationPrototype = class {
  constructor(c) {
    this.c = c;
  }
  states = /* @__PURE__ */ new Map();
  transitions = [];
  hiddenS = 0;
  fadingS = 0;
  measuredFrames = 0;
  transform(s, now, serverNow, g, vehicle, measured) {
    const target = s.renderTargetDistM ?? s.simDistM;
    const sample = (t) => vehicle ? renderDistM(
      vehicle,
      t,
      "smooth",
      s.snapshot.shapeDistM,
      s.snapshot.observedAtMs
    ) : target;
    const rv = vehicle ? renderSpeedMs(
      vehicle,
      serverNow,
      "smooth",
      s.snapshot.shapeDistM,
      s.snapshot.observedAtMs
    ) : s.simSpeedKmh / 3.6;
    const ra = vehicle ? (renderSpeedMs(
      vehicle,
      serverNow + 500,
      "smooth",
      s.snapshot.shapeDistM,
      s.snapshot.observedAtMs
    ) - rv) * 2 : 0;
    let p = this.states.get(s.key);
    if (!p) {
      p = {
        s: target,
        v: clamp2(rv, 0, this.c.vmax),
        a: 0,
        at: now,
        trip: s.snapshot.tripId,
        geom: g,
        position: s.position,
        behindAt: null,
        badAt: null,
        fade: null,
        opacity: 1,
        lookAt: 0,
        stopS: null
      };
      this.states.set(s.key, p);
      return s;
    }
    const dt = Math.max(0, (now - p.at) / 1e3);
    const error = target - p.s;
    const forced = p.trip !== s.snapshot.tripId ? "trip-change" : p.geom !== g ? "incompatible-geometry" : dt > 5 ? "resume-gap" : null;
    if (error < -30) {
      p.behindAt ??= now;
    } else p.behindAt = null;
    if (Math.abs(error) > this.c.hardM) {
      p.badAt ??= now;
    } else p.badAt = null;
    const reason = forced ?? (p.badAt !== null && now - p.badAt > 1e3 ? "unreachable-correction" : p.behindAt !== null && now - p.behindAt > this.c.behindS * 1e3 ? "unreachable-correction" : null);
    if (reason && !p.fade) {
      p.fade = { stage: "out", at: now, reason, distance: error };
      if (measured)
        this.transitions.push({
          key: s.key,
          atMs: now,
          reason,
          distanceM: error
        });
    }
    let freeze = !!forced;
    if (p.fade) {
      const f = p.fade;
      if (f.stage === "out") {
        p.opacity = Math.max(0, 1 - (now - f.at) / 300);
        if (p.opacity === 0) f.stage = "hidden-old";
      } else if (f.stage === "hidden-old") {
        p.s = target;
        p.v = clamp2(rv, 0, this.c.vmax);
        p.a = 0;
        p.trip = s.snapshot.tripId;
        p.geom = g;
        p.badAt = null;
        p.behindAt = null;
        p.opacity = 0;
        f.stage = "hidden-new";
        freeze = true;
      } else if (f.stage === "hidden-new") {
        f.stage = "in";
        f.at = now;
        p.opacity = 0;
      } else {
        p.opacity = Math.min(1, (now - f.at) / 400);
        if (p.opacity === 1) p.fade = null;
      }
    }
    if (now - p.lookAt >= 1e3) {
      p.lookAt = now;
      p.stopS = null;
      let before = target;
      for (let i = 1; i <= 16; i++) {
        const next = sample(serverNow + i * 1e3);
        if (Math.abs(next - before) < 0.03) {
          p.stopS = next;
          break;
        }
        before = next;
      }
    }
    if (!freeze && dt > 0) {
      let desired = clamp2(
        ra + 0.1 * (target - p.s) + 0.65 * (rv - p.v),
        -this.c.brake,
        this.c.accel
      );
      if (p.stopS !== null && p.stopS - p.s <= brakingDistance(p.v, p.a, this.c.brake, this.c.jerk) + 0.3)
        desired = -this.c.brake;
      const lower = Math.max(-this.c.brake, p.a - this.c.jerk * dt), upper = Math.min(this.c.accel, p.a + this.c.jerk * dt);
      let nextA = clamp2(desired, lower, upper);
      const viable = (a) => p.v + (p.a + a) * dt / 2 - Math.min(0, a) ** 2 / (2 * this.c.jerk);
      if (viable(nextA) < 0) {
        let lo = nextA, hi = upper;
        for (let i = 0; i < 20; i++) {
          const mid = (lo + hi) / 2;
          if (viable(mid) < 0) lo = mid;
          else hi = mid;
        }
        nextA = hi;
      }
      const room = (a) => this.c.vmax - (p.v + (p.a + a) * dt / 2) - Math.max(0, a) ** 2 / (2 * this.c.jerk);
      if (room(nextA) < 0) {
        let lo = lower, hi = nextA;
        for (let i = 0; i < 20; i++) {
          const mid = (lo + hi) / 2;
          if (room(mid) < 0) hi = mid;
          else lo = mid;
        }
        nextA = lo;
      }
      const ds = p.v * dt + p.a * dt * dt / 2 + (nextA - p.a) * dt * dt / 6;
      p.s += Math.max(0, ds);
      p.v = clamp2(p.v + (p.a + nextA) * dt / 2, 0, this.c.vmax);
      p.a = nextA;
      if (g && p.s > g.totalM) {
        p.s = g.totalM;
        p.v = 0;
        p.a = 0;
      }
    }
    p.at = now;
    if (measured) {
      this.measuredFrames++;
      if (p.opacity < 1) this.fadingS += dt;
      if (p.opacity <= 1e-3) this.hiddenS += dt;
    }
    if (p.geom) p.position = pointAt(p.geom.coordinates, p.geom.cumDistM, p.s);
    else if (!p.fade) p.position = s.position;
    return {
      ...s,
      simDistM: p.s,
      simSpeedKmh: p.v * 3.6,
      renderGuardActive: Math.abs(target - p.s) > 1e-6,
      position: p.position,
      bearing: p.geom ? bearingAt(p.geom.coordinates, p.geom.cumDistM, p.s) : s.bearing,
      presentationOpacity: p.opacity,
      presentationTransitionReason: p.fade?.reason ?? null,
      presentationCorrectionM: p.fade?.distance ?? null
    };
  }
  report() {
    return {
      config: this.c,
      transitionCount: this.transitions.length,
      transitions: this.transitions,
      hiddenVehicleSeconds: this.hiddenS,
      fadingVehicleSeconds: this.fadingS,
      measuredFrames: this.measuredFrames
    };
  }
};

// bench/src/replay-wire.ts
var readText = (path) => {
  const data = (0, import_node_fs.readFileSync)(path);
  return (path.endsWith(".gz") ? (0, import_node_zlib.gunzipSync)(data) : data).toString("utf8");
};
var [
  wirePath,
  geometryPath,
  fpsArg = "30",
  secondsArg = "3600",
  startAtArg,
  warmupArg = "0"
] = process.argv.slice(2);
if (!wirePath || !geometryPath)
  throw new Error("Expected wire.jsonl and geometry.json");
var segmentWindows = process.env.REPLAY_SEGMENTS ? JSON.parse(readText(process.env.REPLAY_SEGMENTS)) : null;
var measuredKey = (key, at) => at >= minAt && (!segmentWindows || !!segmentWindows[key] && at >= segmentWindows[key].measureAtMs && at < segmentWindows[key].endAtMs);
var fps = Number(fpsArg);
var maxSeconds = Number(secondsArg);
var warmupSeconds = Number(warmupArg);
if (!Number.isFinite(warmupSeconds) || warmupSeconds < 0)
  throw new Error("warmupSeconds must be finite and nonnegative");
var rows = readText(wirePath).split("\n").flatMap((line) => {
  if (!line) return [];
  try {
    const r = JSON.parse(line);
    return r.value ? [r] : [];
  } catch {
    return [];
  }
}).sort((a, b) => a.receivedAtMs - b.receivedAtMs);
if (!rows.length) throw new Error("No complete rows");
var pack = JSON.parse(readText(geometryPath));
var geometryArrivalReplay = rows.some((r) => r.path === "geometry:pack" || r.path === "geometry:trip");
var geometryEventCounts = { packs: 0, trips: 0, applied: 0 };
var initialGeometryPackHandled = false;
var shapes = new Map(
  pack.shapes.map((s) => [
    s.shapeId,
    servedToRouteGeometry(s, rows[0].receivedAtMs)
  ])
);
var geometries = /* @__PURE__ */ new Map();
for (const [tripId, shapeId] of Object.entries(geometryArrivalReplay ? {} : pack.trips)) {
  const shape = shapes.get(String(shapeId));
  if (shape) geometries.set(tripId, { ...shape, tripId });
}
var store = new TrajectoryStore();
var fleet = new TramFleet({
  trajectories: store,
  resolveModel: () => ({ id: "15t" })
});
var fixes = /* @__PURE__ */ new Map();
var displayAudit = new DisplayAudit();
var transitionIds = /* @__PURE__ */ new Map();
var presentationTransitions = [];
var prototype = process.env.PRESENTATION_PROTOTYPE ? new PresentationPrototype(JSON.parse(process.env.PRESENTATION_PROTOTYPE)) : null;
var index = 0;
var curveCursor = -1;
var frames = 0;
var samples = 0;
var visibleSamples = 0;
var backward = 0;
var speedOver25 = 0;
var guardedHolds = 0;
var maxBackwardM = 0;
var maxForwardM = 0;
var holdSeconds = 0;
var sanctionedJumps = 0;
var speeds = [];
var steps = [];
var frameCosts = [];
var positiveSteps = [];
var brakingSteps = [];
var positiveOutliers = [];
var holdReasons = {};
var guardHoldGapBands = {};
var materialGuardHoldSeconds = 0;
var movingTargetBehindHoldSeconds = 0;
var launchesOver1 = 0;
var positiveStepsOver1 = 0;
var prev = /* @__PURE__ */ new Map();
var metrics = /* @__PURE__ */ new Map();
function group(state) {
  let g = metrics.get(state);
  if (!g) {
    g = {
      gaps: [],
      stopOvershoot: [],
      holdEpisodes: [],
      avlError: [],
      seconds: 0,
      ahead10S: 0,
      ahead30S: 0,
      accelerationHigh: 0,
      brakingHigh: 0
    };
    metrics.set(state, g);
  }
  return g;
}
var history = /* @__PURE__ */ new Map();
var scoredFix = /* @__PURE__ */ new Map();
var priorScoredObservation = /* @__PURE__ */ new Map();
var observations = [];
var projectedObservations = [];
var projectionCoverage = { eligibleHistory: 0, projected: 0, rejected: 0 };
var observationCoverage = { uniqueReceived: 0, withinMeasurement: 0, missingSameTripHistory: 0, unbracketedHistory: 0, scored: 0 };
var holds = /* @__PURE__ */ new Map();
var longHolds = [];
function finishHold(key) {
  const h = holds.get(key);
  if (h) {
    group(h.state).holdEpisodes.push((h.end - h.start) / 1e3);
    if (h.end - h.start > 3e4)
      longHolds.push({ key, ...h, durationS: (h.end - h.start) / 1e3 });
    holds.delete(key);
  }
}
function scoreFix(f) {
  if ((scoredFix.get(f.key) ?? 0) >= f.observedAtMs) return;
  scoredFix.set(f.key, f.observedAtMs);
  observationCoverage.uniqueReceived++;
  const previousObservation = priorScoredObservation.get(f.key);
  priorScoredObservation.set(f.key, f);
  if (!measuredKey(f.key, f.observedAtMs)) return;
  observationCoverage.withinMeasurement++;
  const h = history.get(f.key);
  if (!h || h.trip !== f.tripId) {
    observationCoverage.missingSameTripHistory++;
    return;
  }
  let lo = h.start, hi = h.points.length - 1;
  if (lo >= hi || f.observedAtMs < h.points[lo].t || f.observedAtMs > h.points[hi].t) {
    observationCoverage.unbracketedHistory++;
    return;
  }
  observationCoverage.scored++;
  while (hi - lo > 1) {
    const m = lo + hi >> 1;
    if (h.points[m].t <= f.observedAtMs) lo = m;
    else hi = m;
  }
  const a = h.points[lo], b = h.points[hi];
  const targetAtObservation = a.target + (b.target - a.target) * (f.observedAtMs - a.t) / (b.t - a.t);
  const errorM = a.s + (b.s - a.s) * (f.observedAtMs - a.t) / (b.t - a.t) - f.shapeDistM;
  group(f.statePosition).avlError.push(errorM);
  projectionCoverage.eligibleHistory++;
  const projection = projectObservation(f, geometries.get(f.tripId));
  if (projection) {
    projectionCoverage.projected++;
    const before = previousObservation && previousObservation.tripId === f.tripId ? projectObservation(previousObservation, geometries.get(f.tripId)) : null;
    const dt = previousObservation ? (f.observedAtMs - previousObservation.observedAtMs) / 1e3 : 0;
    const sameVisit = previousObservation?.lastStopId === f.lastStopId && previousObservation?.lastStopSequence === f.lastStopSequence && previousObservation?.nextStopId === f.nextStopId && previousObservation?.nextStopSequence === f.nextStopSequence;
    const currentStop = geometries.get(f.tripId)?.stops.find(
      (s) => s.stopId === f.lastStopId && s.sequence === f.lastStopSequence
    );
    const pairDs = before ? projection.s - before.s : 0;
    const validPair = !!before && dt >= 4 && dt <= 120;
    const motionEvidence = validPair && pairDs >= 10 ? "moving" : validPair && dt <= 45 && sameVisit && Math.abs(pairDs) <= 3 && currentStop && Math.abs(projection.s - currentStop.distM) <= 20 ? "near-platform-stationary-pair" : "unknown";
    let stationaryTravelM = null;
    let displayStationarySeconds = null;
    let displayNearPlatformSeconds = null;
    if (motionEvidence === "near-platform-stationary-pair" && previousObservation && currentStop) {
      const points = h.points.slice(h.start).filter((p) => p.t >= previousObservation.observedAtMs && p.t <= f.observedAtMs);
      if (points.length > 1 && points[0].t - previousObservation.observedAtMs <= 1e3 / fps + 1) {
        stationaryTravelM = 0;
        displayStationarySeconds = 0;
        displayNearPlatformSeconds = 0;
        for (let j = 1; j < points.length; j++) {
          const dtS = (points[j].t - points[j - 1].t) / 1e3;
          const ds = Math.abs(points[j].s - points[j - 1].s);
          stationaryTravelM += ds;
          if (dtS > 0 && ds / dtS <= 0.5) displayStationarySeconds += dtS;
          if (Math.abs(points[j].s - currentStop.distM) <= 20) displayNearPlatformSeconds += dtS;
        }
      }
    }
    projectedObservations.push({
      distanceToCurrentPlatformM: currentStop ? currentStop.distM - projection.s : null,
      pairDurationS: validPair ? dt : null,
      displayTravelDuringStationaryPairM: stationaryTravelM,
      displayStationarySeconds,
      displayNearPlatformSeconds,
      targetErrorM: targetAtObservation - projection.s,
      renderedMinusTargetM: errorM + f.shapeDistM - targetAtObservation,
      motionEvidence,
      pairSpeedMs: validPair ? pairDs / dt : null,
      key: f.key,
      tripId: f.tripId,
      state: f.statePosition,
      observedAtMs: f.observedAtMs,
      errorM: errorM + f.shapeDistM - projection.s,
      offsetM: projection.offsetM,
      anchorMinusGpsM: f.shapeDistM - projection.s
    });
  } else projectionCoverage.rejected++;
  observations.push({
    key: f.key,
    tripId: f.tripId,
    state: f.statePosition,
    observedAtMs: f.observedAtMs,
    errorM
  });
}
function recordHistory(key, trip, distanceM, frameAt, targetM = distanceM) {
  let h = history.get(key);
  if (!h || h.trip !== trip) {
    h = { trip, points: [], start: 0 };
    history.set(key, h);
  }
  h.points.push({ t: frameAt, s: distanceM, target: targetM });
  while (h.start < h.points.length && h.points[h.start].t < frameAt - 9e4)
    h.start++;
  if (h.start > 3e3) {
    h.points = h.points.slice(h.start);
    h.start = 0;
  }
}
var minAt = startAtArg === void 0 ? rows[0].receivedAtMs : Number(startAtArg);
var maxAt = Math.min(rows.at(-1).receivedAtMs, minAt + maxSeconds * 1e3);
var latestFixAt = 0;
for (let frameAt = minAt - warmupSeconds * 1e3; frameAt <= maxAt; frameAt += 1e3 / fps) {
  while (index < rows.length && rows[index].receivedAtMs <= frameAt) {
    const r = rows[index++], v2 = r.value;
    if (r.path === "geometry:pack" || r.path === "geometry:trip") {
      geometryEventCounts[r.path === "geometry:pack" ? "packs" : "trips"]++;
      const applied = r.path === "geometry:pack" && initialGeometryPackHandled ? 0 : applyGeometryEvent(geometries, r.path, v2, r.receivedAtMs);
      if (r.path === "geometry:pack") initialGeometryPackHandled = true;
      geometryEventCounts.applied += applied;
      if (applied) fleet.ingest([...fixes.values()], (trip) => geometries.get(trip), r.receivedAtMs);
    } else if (r.path === "capture:error" && v2.query === "geometry-pack") {
      initialGeometryPackHandled = true;
    } else if (r.path === "stream:fullFleet") {
      fixes.clear();
      for (const s of v2.vehicles) {
        scoreFix(s);
        fixes.set(s.key, s);
      }
      latestFixAt = r.receivedAtMs;
      fleet.ingest([...fixes.values()], (trip) => geometries.get(trip), r.receivedAtMs);
    } else if (r.path === "stream:batchesSince") {
      for (const batch of v2.batches) {
        for (const s of batch.changed) {
          scoreFix(s);
          fixes.set(s.key, s);
        }
        for (const key of batch.removed ?? []) fixes.delete(key);
      }
      latestFixAt = r.receivedAtMs;
      fleet.ingest([...fixes.values()], (trip) => geometries.get(trip), r.receivedAtMs);
    } else if (r.path === "trajectories:fullSet") {
      store.seedConvex(v2.vehicles, v2.meta, r.receivedAtMs);
      curveCursor = v2.seq;
    } else if (r.path === "trajectories:batchesSince") {
      for (const batch of v2.batches)
        if (batch.seq > curveCursor) {
          store.foldConvex(batch, v2.serverNowMs, r.receivedAtMs);
          curveCursor = batch.seq;
        }
    } else if (r.path === "trajectories:meta")
      store.noteConvexMeta(v2, r.receivedAtMs);
    else if (r.path === "clock:now" && typeof r.sentAtMs === "number")
      store.noteConvexClock(v2.serverNowMs, r.sentAtMs, r.receivedAtMs);
  }
  const start = import_node_perf_hooks.performance.now();
  let states = fleet.getStates(frameAt, "smooth", true);
  const runtimeCost = import_node_perf_hooks.performance.now() - start;
  for (const s of states) {
    if (s.presentationTransitionId !== void 0 && transitionIds.get(s.key) !== s.presentationTransitionId) {
      transitionIds.set(s.key, s.presentationTransitionId);
      if (measuredKey(s.key, frameAt)) {
        const current = fleet.getPredictionGeometry(s.key), old = fleet.getGeometry(s.key);
        const corridor = current ? observationCorridor(s.snapshot, current) : null;
        const projected = current && corridor ? projectInCorridor(s.position, current, corridor, 10) : null;
        presentationTransitions.push({
          key: s.key,
          tripId: s.snapshot.tripId,
          atMs: frameAt,
          reason: s.presentationTransitionReason,
          currentGeometry: !!current,
          oldGeometry: !!old,
          currentProvisional: current?.provisional ?? false,
          currentShapeId: current?.shapeId ?? null,
          oldShapeId: old?.shapeId ?? null,
          projectedWithin10m: projected,
          fixAtMs: s.snapshot.observedAtMs,
          renderTargetDistM: s.renderTargetDistM,
          renderedDistM: s.simDistM
        });
      }
    }
  }
  for (const state of states)
    if (state.presentationOpacity === 0 && state.presentationHiddenFrameId !== void 0)
      fleet.acknowledgePresentationHidden(
        state.key,
        state.presentationHiddenFrameId
      );
  if (prototype)
    states = states.map(
      (s) => prototype.transform(
        s,
        frameAt,
        store.nowMs(frameAt),
        fleet.getGeometry(s.key),
        store.getVehicle(s.key),
        frameAt >= minAt
      )
    );
  for (const state of states)
    displayAudit.sample(
      state,
      frameAt,
      fleet.getGeometry(state.key),
      store.getVehicle(state.key),
      measuredKey(state.key, frameAt)
    );
  displayAudit.finishFrame(frameAt, new Set(states.map((s) => s.key)));
  for (const key of history.keys()) if (!fixes.has(key)) history.delete(key);
  if (frameAt < minAt) {
    for (const s of states)
      if (s.hasGeometry && s.presentationCorrectionComparable !== false)
        recordHistory(
          s.key,
          s.snapshot.tripId,
          s.simDistM,
          frameAt,
          s.renderTargetDistM ?? s.simDistM
        );
    continue;
  }
  frameCosts.push(runtimeCost);
  frames++;
  for (const s of states) {
    if (!measuredKey(s.key, frameAt)) {
      if (s.hasGeometry && s.presentationCorrectionComparable !== false)
        recordHistory(
          s.key,
          s.snapshot.tripId,
          s.simDistM,
          frameAt,
          s.renderTargetDistM ?? s.simDistM
        );
      continue;
    }
    samples++;
    if (!s.hasGeometry) {
      history.delete(s.key);
      continue;
    }
    visibleSamples++;
    const vehicle = store.getVehicle(s.key);
    const emission = vehicle?.emittedAtMs ?? 0;
    const p = prev.get(s.key);
    if (p && p.trip === s.snapshot.tripId && frameAt - p.t < 1500 / fps && !(vehicle?.discontinuity && emission !== p.emission)) {
      const ds = s.simDistM - p.s, dt = (frameAt - p.t) / 1e3, v2 = ds / dt;
      if (ds < -0.01) {
        backward++;
        maxBackwardM = Math.min(maxBackwardM, ds);
      }
      maxForwardM = Math.max(maxForwardM, ds);
      if (v2 > 25.1) speedOver25++;
      speeds.push(v2);
      const g = group(s.snapshot.statePosition);
      if (p.v !== void 0) {
        steps.push(Math.abs(v2 - p.v));
        positiveSteps.push(Math.max(0, v2 - p.v));
        brakingSteps.push(Math.max(0, p.v - v2));
        if (v2 - p.v > 1) {
          positiveStepsOver1++;
          if (positiveOutliers.length < 30)
            positiveOutliers.push({
              key: s.key,
              frameAt,
              dt,
              ds,
              v: v2,
              previous: p,
              reportedSpeed: s.simSpeedKmh,
              target: s.renderTargetDistM,
              discontinuity: vehicle?.discontinuity,
              emission
            });
        }
        if (p.v < 0.1 && v2 > 1) launchesOver1++;
        const a = (v2 - p.v) / dt;
        if (a > 1.301) g.accelerationHigh++;
        if (a < -1.401) g.brakingHigh++;
      }
      g.seconds += dt;
      const gap = (s.renderTargetDistM ?? s.simDistM) - s.simDistM;
      g.gaps.push(gap);
      if (gap < -10) g.ahead10S += dt;
      if (gap < -30) g.ahead30S += dt;
      if (s.snapshot.statePosition === "at_stop" && frameAt - s.snapshot.observedAtMs < 45e3)
        g.stopOvershoot.push(Math.max(0, s.simDistM - s.snapshot.shapeDistM));
      if (s.renderGuardActive && v2 < 0.1) {
        let h = holds.get(s.key);
        if (h && h.state !== s.snapshot.statePosition) {
          finishHold(s.key);
          h = void 0;
        }
        if (!h) {
          h = {
            state: s.snapshot.statePosition,
            start: p.t,
            end: frameAt,
            position: s.simDistM,
            target: s.renderTargetDistM,
            fix: s.snapshot.shapeDistM,
            fixAt: s.snapshot.observedAtMs
          };
          holds.set(s.key, h);
        } else h.end = frameAt;
      } else finishHold(s.key);
      if (s.renderGuardActive && v2 < 0.1) {
        guardedHolds++;
        holdSeconds += dt;
        const rawSpeed = ((s.renderTargetDistM ?? s.simDistM) - p.target) / dt;
        const absGap = Math.abs(gap);
        const gapBand = absGap < 0.5 ? "under0.5m" : absGap < 10 ? "0.5to10m" : absGap < 30 ? "10to30m" : "over30m";
        guardHoldGapBands[gapBand] = (guardHoldGapBands[gapBand] ?? 0) + dt;
        if (absGap >= 0.5) materialGuardHoldSeconds += dt;
        if (gap <= -0.5 && rawSpeed > 0.1) movingTargetBehindHoldSeconds += dt;
        const fixAgeS = (frameAt - s.snapshot.observedAtMs) / 1e3;
        const reason = fixAgeS > 45 ? "old-avl-over45s" : s.pastHorizon ? "past-effective-horizon" : rawSpeed < -0.1 ? "target-revised-backward" : rawSpeed <= 0.1 ? "flat-target" : gap < -0.5 ? "moving-target-behind-rendered-floor" : "low-speed-catchup";
        const label = `${s.snapshot.statePosition}/${reason}`;
        holdReasons[label] = (holdReasons[label] ?? 0) + dt;
      }
      prev.set(s.key, {
        s: s.simDistM,
        t: frameAt,
        v: v2,
        trip: s.snapshot.tripId,
        emission,
        target: s.renderTargetDistM ?? s.simDistM
      });
    } else {
      finishHold(s.key);
      if (p && p.trip === s.snapshot.tripId && vehicle?.discontinuity)
        sanctionedJumps++;
      prev.set(s.key, {
        s: s.simDistM,
        t: frameAt,
        v: void 0,
        trip: s.snapshot.tripId,
        emission,
        target: s.renderTargetDistM ?? s.simDistM
      });
    }
    if (s.presentationCorrectionComparable !== false)
      recordHistory(
        s.key,
        s.snapshot.tripId,
        s.simDistM,
        frameAt,
        s.renderTargetDistM ?? s.simDistM
      );
    else history.delete(s.key);
  }
}
for (const key of holds.keys()) finishHold(key);
var quantiles = (values) => {
  values.sort((a, b) => a - b);
  return Object.fromEntries(
    [0.5, 0.9, 0.99, 1].map((q) => [
      String(q),
      values[Math.min(values.length - 1, Math.floor(q * values.length))] ?? 0
    ])
  );
};
console.log(
  JSON.stringify(
    {
      wirePath,
      geometryArrivalReplay,
      geometryEventCounts,
      geometryCaveat: geometryArrivalReplay ? "Actual captured geometry receipts; provisional seeds and pertrip refinement. Harness loader concurrency differs from native scheduler." : "Static sampled geometry pack; not the native cache/refinement timeline. Bare provider IDs may alias cached GTFS generations. Treat axis/fade results as static geometry sensitivity.",
      researchNoSmoothShim: process.env.RESEARCH_NO_SMOOTH_SHIM === "1",
      legacyMetricCaveat: "Legacy top-level slew/hold counters retain the historical discontinuity filter for comparison only. Use completeDisplayAudit for every actual frame, correction, both acceleration signs and visibility.",
      fps,
      warmupSeconds,
      segmentWindows,
      completeDisplayAudit: displayAudit.report(),
      presentationTransitions,
      presentationPrototype: prototype?.report(),
      durationS: (maxAt - minAt) / 1e3,
      frames,
      samples,
      visibleSamples,
      lastFixAgeS: (maxAt - latestFixAt) / 1e3,
      sanctionedJumps,
      backward,
      speedOver25,
      maxBackwardM,
      maxForwardM,
      guardedHolds,
      holdSeconds,
      materialGuardHoldSeconds,
      movingTargetBehindHoldSeconds,
      guardHoldSecondsByAbsoluteGap: guardHoldGapBands,
      observations,
      projectedObservations,
      projectionCoverage,
      observationCoverage,
      projectedGpsByMotionEvidence: Object.fromEntries(
        ["moving", "near-platform-stationary-pair", "unknown"].map(
          (evidence) => {
            const errors = projectedObservations.filter((o) => o.motionEvidence === evidence).map((o) => o.errorM);
            return [
              evidence,
              {
                count: errors.length,
                maeM: errors.reduce((a, b) => a + Math.abs(b), 0) / (errors.length || 1),
                biasM: errors.reduce((a, b) => a + b, 0) / (errors.length || 1),
                ahead30: errors.filter((v2) => v2 > 30).length,
                absErrorM: quantiles(errors.map(Math.abs))
              }
            ];
          }
        )
      ),
      projectedGpsMaeM: projectedObservations.reduce((a, b) => a + Math.abs(b.errorM), 0) / (projectedObservations.length || 1),
      projectedGpsAbsErrorM: quantiles(
        projectedObservations.map((x) => Math.abs(x.errorM))
      ),
      longHolds,
      guardHeldSecondsByReason: holdReasons,
      byReportedFixState: Object.fromEntries(
        [...metrics].map(([state, g]) => [
          state,
          {
            vehicleSeconds: g.seconds,
            aheadTarget10Seconds: g.ahead10S,
            aheadTarget30Seconds: g.ahead30S,
            targetMinusDisplayM: quantiles(g.gaps),
            aheadOfRecentReportedStopFixM: quantiles(g.stopOvershoot),
            guardHoldEpisodes: g.holdEpisodes.length,
            guardHoldDurationS: quantiles(g.holdEpisodes),
            accelerationOver1_3: g.accelerationHigh,
            brakingOver1_4: g.brakingHigh,
            historicalAvlCount: g.avlError.length,
            historicalAvlBiasM: g.avlError.reduce((a, b) => a + b, 0) / (g.avlError.length || 1),
            historicalAvlMaeM: g.avlError.reduce((a, b) => a + Math.abs(b), 0) / (g.avlError.length || 1),
            historicalAvlAbsErrorM: quantiles(g.avlError.map(Math.abs))
          }
        ])
      ),
      positiveOutliers,
      positiveSpeedStepMs: quantiles(positiveSteps),
      brakingSpeedStepMs: quantiles(brakingSteps),
      launchesOver1,
      positiveStepsOver1,
      actualSpeedMs: quantiles(speeds),
      speedStepMs: quantiles(steps),
      fullFleetFrameCpuMs: quantiles(frameCosts),
      clockOffsetMs: store.clock.offsetMs,
      clockSynced: store.clock.synced,
      caveat: "Sampled captured inputs, known geometry-pack trips only. No rider ground truth; source timestamps and delivery timing preserved. CPU is Node on host, not Hermes/native rendering."
    },
    null,
    2
  )
);
